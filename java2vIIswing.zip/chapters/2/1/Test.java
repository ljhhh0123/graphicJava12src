import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();

		Icon icon = new ImageIcon("swing.gif", 
						"An animated GIF of Duke on a swing");

		JLabel label = new JLabel("Swing!", icon,
						SwingConstants.CENTER);

		contentPane.add(label, BorderLayout.CENTER);
	}
}
