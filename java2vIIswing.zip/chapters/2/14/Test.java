import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	JProgressBar pb = new JProgressBar();

	public void init() {
		Container contentPane = getContentPane();
		final JButton startButton = new JButton("start");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(startButton);
		contentPane.add(pb);

		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetInfoThread t = new GetInfoThread(Test.this);
				t.start();

				// this is ok, because actionPerformed
				// is called on the event dispatch thread
				startButton.setEnabled(false);
			}
		});
	}
	public JProgressBar getProgressBar() {
		return pb;
	}
}
class GetInfoThread extends Thread {
	Runnable runnable;
	int value;

	public GetInfoThread(final Test applet) {
		runnable = new Runnable() {
			public void run() {
				JProgressBar pb = applet.getProgressBar();
				pb.setValue(value);
			}
		};
	}
	public void run() {
		while(true) {
			try {
				Thread.currentThread().sleep(500);

				// This is okay because the runnable�s run()
				// is invoked on the event dispatch thread
				value = (int)(Math.random() * 100);
				SwingUtilities.invokeLater(runnable);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
