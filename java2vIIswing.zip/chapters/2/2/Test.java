import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JFrame {
	public Test() {
		super("An Application");

		Container contentPane = getContentPane();

		Icon icon = new ImageIcon("swing.gif", 
						"An animated GIF of Duke on a swing");

		JLabel label = new JLabel("Swing!", icon,
						SwingConstants.CENTER);

		contentPane.add(label, BorderLayout.CENTER);
	}
	public static void main(String args[]) {
		final JFrame f = new Test();

		f.setBounds(100,100,300,250);
		f.setVisible(true);
		f.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
