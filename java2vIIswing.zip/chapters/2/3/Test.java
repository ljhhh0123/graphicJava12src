import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		Icon icon = new ImageIcon("swing.gif");
		JLabel label = new JLabel(icon);

		contentPane.setLayout(new FlowLayout());	
		contentPane.add(label = new JLabel(icon));

		contentPane.add(label);
	}
	public static void main(String args[]) {
		final JFrame f = new JFrame();
		JApplet applet = new Test();

		applet.init();

		f.setContentPane(applet.getContentPane());
		f.setBounds(100,100,308,199);
		f.setTitle("An Application");
		f.setVisible(true);

		f.setDefaultCloseOperation(
			WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
