import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class InternalFrameTest extends JApplet {
	JDesktopPane dtp = new JDesktopPane();

	public void init() {
		JPanel  controlPanel = new ControlPanel(dtp);
		Container contentPane = getContentPane();
		JPanel	centerPanel = new JPanel();

		contentPane.setLayout(new BorderLayout());
		contentPane.add(controlPanel, BorderLayout.NORTH);
		contentPane.add(dtp, BorderLayout.CENTER);
	}
}
class ControlPanel extends JPanel {
	private static int cnt=0;

	public ControlPanel(final JDesktopPane dtp) {
		JButton b = new JButton("make frame");

		add(b);

		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				JInternalFrame jif = new JInternalFrame();
				Container contentPane = jif.getContentPane();

				jif.setLocation(10,50);
				jif.setTitle("Internal Frame" + cnt++);
				jif.setResizable(true);
				jif.setMaximizable(true);
				jif.setClosable(true);
				jif.setVisible(true);
				jif.setIconifiable(true);

				contentPane.setLayout(new FlowLayout());
				contentPane.add(new ColoredCanvas(), "Center");
				jif.pack();

				dtp.add(jif, 2);  // add at layer 2
			}
		});
	}
}
class ColoredCanvas extends Canvas {
	public void paint(Graphics g) {
		Dimension sz = getSize();
		g.setColor(Color.blue);
		g.fillRect(0,0,sz.width,sz.height);
	}
	public Dimension getPreferredSize() {
		return new Dimension(200,200);
	}
}
