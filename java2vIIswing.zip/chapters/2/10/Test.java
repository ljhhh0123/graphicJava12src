import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		JPanel panel = new JPanel();

		panel.add(new JButton("Swing Button ..."));
		panel.add(new Button("AWT Button ..."));

		Container 	contentPane = getContentPane();
		JScrollPane scrollPane = new JScrollPane(panel);

		scrollPane.setPreferredSize(new Dimension(125,50));
		contentPane.setLayout(new FlowLayout(FlowLayout.LEFT));
		contentPane.add(scrollPane);
	}
}
