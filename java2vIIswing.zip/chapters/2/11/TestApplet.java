import com.sun.java.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public Test() {
		JPanel panel = new JPanel();

		panel.add(new JButton("Swing Button ..."));
		panel.add(new Button("AWT Button ..."));

		Container 	contentPane = getContentPane();
		SizedScrollPane scrollPane = new SizedScrollPane();

		scrollPane.add(panel);

		contentPane.setLayout(new FlowLayout(FlowLayout.LEFT));
		contentPane.add(scrollPane);
	}
}
class SizedScrollPane extends ScrollPane {
	public Dimension getPreferredSize() {
		return new Dimension(125,50);
	}
}
