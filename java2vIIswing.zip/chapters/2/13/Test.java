import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	JProgressBar pb = new JProgressBar();

	public void init() {
		Container contentPane = getContentPane();
		final JButton startButton = new JButton("start");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(startButton);
		contentPane.add(pb);

		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GetInfoThread t = new GetInfoThread(Test.this);
				t.start();

				// this is ok, because actionPerformed
				// is called on the event dispatch thread
				startButton.setEnabled(false);
			}
		});
	}
	public JProgressBar getProgressBar() {
		return pb;
	}
}
class GetInfoThread extends Thread {
	Test applet;

	public GetInfoThread(Test applet) {
		this.applet = applet;
	}
	public void run() {
		while(true) {
			try {
				// simulate "lengthy" information retrieval
				Thread.currentThread().sleep(500);

System.out.println(".");
				// this is not ok, because it is not called
				// on the event dispatch thread
				applet.getProgressBar().setValue(
					(int)Math.random()*100);
			}
			catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
