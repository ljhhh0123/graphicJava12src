import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		JPopupMenu.setDefaultLightWeightPopupEnabled(false);

		Container contentPane = getContentPane();
		JMenuBar menubar = new JMenuBar();
		JMenu menu = new JMenu("File");

		menu.add("New ...");
		menu.add("Open ...");
		menu.add("Save As ...");
		menu.add("Save");
		menu.add("Exit");

		contentPane.setLayout(new FlowLayout(FlowLayout.LEFT));
		contentPane.add(new Button("An AWT Button ............"));

		menubar.add(menu);
		setJMenuBar(menubar);
	}
}
