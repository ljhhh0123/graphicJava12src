import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {

	public void init() {
		Container contentPane = getContentPane();
		final JSeparator s = 
						new JSeparator(JSeparator.VERTICAL);
		final Dimension ps = s.getPreferredSize();

		contentPane.setLayout(new FlowLayout());

		contentPane.add(new JButton("left"));
		contentPane.add(s);
		contentPane.add(new JButton("right"));

		addComponentListener(new ComponentAdapter() {
			public void componentShown(ComponentEvent e) {
			System.out.println("shown");
				adjustSeparatorPreferredSize();
			}
			public void componentResized(ComponentEvent e) {
			System.out.println("resized");
				adjustSeparatorPreferredSize();
			}
			private void adjustSeparatorPreferredSize() {
				s.setPreferredSize(new Dimension(ps.width, 
										getSize().height));
				s.revalidate();
			}
		});
	}
}
