import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JSlider slider = new JSlider();
		JPanel controlPanel = new ControlPanel(slider);

		contentPane.setLayout(new BorderLayout(0,40));
		contentPane.add(controlPanel, BorderLayout.NORTH);
		contentPane.add(slider, BorderLayout.CENTER);
	}
	class ControlPanel extends JPanel {
		public ControlPanel(final JSlider slider) {
		JCheckBox paintTicks = new JCheckBox("Paint Ticks");
		JComboBox minorSpacing = new JComboBox(),
					majorSpacing = new JComboBox();

		minorSpacing.addItem("0");
		minorSpacing.addItem("3");
		minorSpacing.addItem("5");
		minorSpacing.addItem("10");
		minorSpacing.addItem("20");

		majorSpacing.addItem("0");
		majorSpacing.addItem("3");
		majorSpacing.addItem("5");
		majorSpacing.addItem("10");
		majorSpacing.addItem("20");

		add(paintTicks);
		add(new JLabel("Minor Tick Spacing:"));
		add(minorSpacing);
		add(new JLabel("Major Tick Spacing:"));
		add(majorSpacing);

		paintTicks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JCheckBox cb = (JCheckBox)e.getSource();
				slider.setPaintTicks(cb.isSelected());
				slider.repaint();
			}
		});
		minorSpacing.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				JComboBox cb = (JComboBox)e.getSource();
				int spacing = Integer.parseInt(
									(String)cb.getSelectedItem());

				slider.setMinorTickSpacing(spacing);
				slider.revalidate();
			}
		});
		majorSpacing.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				JComboBox cb = (JComboBox)e.getSource();
				int spacing = Integer.parseInt(
									(String)cb.getSelectedItem());

				slider.setMajorTickSpacing(spacing);
				slider.revalidate();
			}
		});
	}
	}
}
