import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JSlider slider = new JSlider();

		contentPane.add(slider, BorderLayout.NORTH);
	}
}
