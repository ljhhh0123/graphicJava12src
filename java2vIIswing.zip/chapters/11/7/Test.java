import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JSlider slider = new JSlider();

		slider.setPaintLabels(true);
		slider.setMajorTickSpacing(20);
		contentPane.add(slider, BorderLayout.NORTH);
	}
}
