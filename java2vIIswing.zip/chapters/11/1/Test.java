import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private JProgressBar[] progressBars = {
			new JProgressBar(),
			new JProgressBar(),
			new JProgressBar(),
			new JProgressBar()
	};

	public void init() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());

		for(int i=0; i < progressBars.length; ++i) {
			JProgressBar pb = progressBars[i];

			if(i == 0) {
				pb.setStringPainted(true);
				pb.setString("Custom String");
			}
			if(i == 1) {
				pb.setOrientation(JProgressBar.VERTICAL);
				pb.setForeground(Color.yellow);
				pb.setMaximum(1000);
				pb.setValue(50);
				pb.setBorder(
					BorderFactory.createRaisedBevelBorder());
			}
			if(i == 2) {
				pb.setForeground(Color.blue);
				pb.setBorderPainted(false);
				pb.setValue(50);
				pb.setStringPainted(true);
			}
			if(i == 3) {
				pb.setOrientation(JProgressBar.VERTICAL);
				pb.setForeground(Color.red);
				pb.setValue(90);
				pb.setStringPainted(true);
				pb.setBorder(
					BorderFactory.createEtchedBorder());
			}
			contentPane.add(pb);
		}
	}
}
