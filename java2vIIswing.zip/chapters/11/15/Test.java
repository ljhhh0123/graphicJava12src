import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JPanel left, rightTop, rightBottom;

	private Box box = new Box(BoxLayout.X_AXIS),
				rightBox = new Box(BoxLayout.Y_AXIS);

	private JSeparator vs, hs;  // vs = vertical separator
						        // hs = horizontal separator
	public void init() {
		createBoxes();
		setPanelBorders();
		//setSeparatorPreferredSizes();

		left.setPreferredSize(new Dimension(150,0));

		getContentPane().add(box, BorderLayout.CENTER);
	}
	private void createBoxes() {

		Component vStrut = box.createVerticalStrut(10),
				  hStrut = box.createHorizontalStrut(10);

		rightBox.add(rightTop = new JPanel());
		rightBox.add(box.createVerticalStrut(10));
		rightBox.add(hs = new JSeparator());
		rightBox.add(box.createVerticalStrut(10));
		rightBox.add(rightBottom = new JPanel());

		box.add(left = new JPanel());
		box.add(box.createHorizontalStrut(10));
		box.add(vs = new JSeparator(JSeparator.VERTICAL));
		box.add(box.createHorizontalStrut(10));
		box.add(rightBox);
	}
	private void setSeparatorPreferredSizes() {
		vs.setMaximumSize( 
			new Dimension(vs.getPreferredSize().width, 
						  Integer.MAX_VALUE));

		hs.setMaximumSize(
			new Dimension(Integer.MAX_VALUE,
						  hs.getPreferredSize().height));
	}
	private void setPanelBorders() {
		left.setBorder(
			BorderFactory.createTitledBorder("Left"));
		rightTop.setBorder(
			BorderFactory.createTitledBorder("Right Top"));
		rightBottom.setBorder(
		   BorderFactory.createTitledBorder("Right Bottom"));
	}
}
