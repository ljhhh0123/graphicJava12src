import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JCheckBox checkBox = new JCheckBox("Invert");
	private JSlider[] sliders = { new JSlider(), 
						  		  new JSlider(JSlider.VERTICAL) };

	public Test() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(checkBox);

		for(int i=0; i < sliders.length; ++i) {
			sliders[i].setPaintLabels(true);
			sliders[i].setMajorTickSpacing(20);
			contentPane.add(sliders[i]);
		}

		checkBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0; i < sliders.length; ++i)
					sliders[i].setInverted(checkBox.isSelected());
			}
		});
	}
}
