import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JSlider slider = new JSlider();

		slider.putClientProperty("JSlider.isFilled",Boolean.TRUE);

		contentPane.add(slider, BorderLayout.NORTH);
	}
}
