import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JSlider slider = new JSlider();
		Icon[] icons = {
			new ImageIcon("basketball.gif"),				
			new ImageIcon("baseball.gif"),				
			new ImageIcon("soccer.gif"),				
			new ImageIcon("clipboard.gif"),				
			new ImageIcon("filmstrip.gif"),				
			new ImageIcon("crab.gif"),				
		};
		Hashtable table = new Hashtable();

		for(int i=0, loc=0; i < icons.length; i++, loc += 20) {
			table.put(new Integer(loc), 
					new JLabel(Integer.toString(loc), 
								icons[i],
								JLabel.LEFT)); 
		}

		slider.setLabelTable(table);
		slider.setPaintLabels(true);
		slider.setMajorTickSpacing(20);

		contentPane.add(slider, BorderLayout.NORTH);
	}
}
