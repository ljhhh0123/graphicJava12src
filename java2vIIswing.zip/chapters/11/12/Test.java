import java.awt.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JSeparator s = new JSeparator(JSeparator.VERTICAL);

		contentPane.setLayout(new FlowLayout());

		contentPane.add(new JButton("left"));
		contentPane.add(s);
		contentPane.add(new JButton("right"));
	}
}
