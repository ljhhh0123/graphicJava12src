import java.awt.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JSeparator s = new JSeparator(JSeparator.VERTICAL);
		Dimension ps = s.getPreferredSize();

		contentPane.setLayout(new FlowLayout());

		contentPane.add(new JButton("left"));
		contentPane.add(s);
		contentPane.add(new JButton("right"));

		s.setPreferredSize(new Dimension(ps.width, 50));
	}
}
