import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JSlider slider = new JSlider();

		contentPane.add(slider, BorderLayout.NORTH);

		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				JSlider s = (JSlider)e.getSource();
				showStatus("Min: " + s.getMinimum() + 
							", Max: " + s.getMaximum() +
							", Extent: " + s.getExtent() +
							", Value: " + s.getValue() +
							", Value Is Adjusting: " +
							s.getValueIsAdjusting());
			}
		});
	}
}
