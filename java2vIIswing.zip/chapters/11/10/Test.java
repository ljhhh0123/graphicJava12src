import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JSlider slider = new JSlider();
		JPanel controlPanel = new ControlPanel(slider);

		contentPane.add(controlPanel, BorderLayout.NORTH);
		contentPane.add(slider, BorderLayout.SOUTH);

		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				JSlider s = (JSlider)e.getSource();
				showStatus("Min: " + s.getMinimum() + 
							", Max: " + s.getMaximum() +
							", Extent: " + s.getExtent() +
							", Value: " + s.getValue());
			}
		});
	}
}
class ControlPanel extends JPanel {
	public ControlPanel(final JSlider slider) {
		JComboBox extent = new JComboBox();

		extent.addItem("0");
		extent.addItem("10");
		extent.addItem("20");
		extent.addItem("30");
		extent.addItem("40");

		add(new JLabel("Extent:"));
		add(extent);

		extent.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				JComboBox cb = (JComboBox)e.getSource();
				int ext = Integer.parseInt(
									(String)cb.getSelectedItem());

				slider.setExtent(ext);
				slider.revalidate();
			}
		});
	}
}
