import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {

	public Test() {
		Container contentPane = getContentPane();
		JTabbedPane tp = new JTabbedPane();
		JPanel panelOne = new JPanel();
		JPanel panelTwo = new JPanel();

		tp.add(panelOne, "Panel One");
		tp.addTab("Panel Two", 
					new ImageIcon("document.gif"),
					panelTwo, 
					"tooltip text");

		contentPane.setLayout(new BorderLayout());
		contentPane.add(tp);

		tp.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				JTabbedPane tabbedPane = 
									(JTabbedPane)e.getSource();

				int index = tabbedPane.getSelectedIndex();
				String s = tabbedPane.getTitleAt(index);

				showStatus(s + " selected");
			}
		});
	}
}
