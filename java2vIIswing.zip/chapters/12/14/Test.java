import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JSplitPane sp = new JSplitPane();

		contentPane.add(sp, BorderLayout.CENTER);
		sp.addPropertyChangeListener(
									new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent e) {
				if(e.getPropertyName().equals(
					 JSplitPane.LAST_DIVIDER_LOCATION_PROPERTY)) {
					JSplitPane jsp = (JSplitPane)e.getSource();

					int dl = jsp.getDividerLocation();

					JButton lb = (JButton)jsp.getLeftComponent();
					JButton rb = (JButton)jsp.getRightComponent();

					showStatus("Divider Location: " + dl + " / " +
					  lb.getText() + ": " + lb.getSize() + " / " +
					  rb.getText() + ": " + rb.getSize()); 
				}
			}
		});
	}
}
