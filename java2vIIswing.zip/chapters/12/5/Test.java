import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	Container cp = getContentPane();

	private final Component[] comps = {
		new JButton(), new JButton(), 
		new JButton(), new JButton(), 	
		new JButton(), new JButton(), 
	};
	public void init() {
		cp.setLayout(null);

		for(int i=0; i < comps.length; ++i) {
			AbstractButton button = (AbstractButton)comps[i];
			cp.add(button);

			String t = "Button #";

			t += i + "  Index:  " + getIndexOf(button);

			button.setText(t);
			button.setBounds(i*50, i*50, 350, 75);
			System.out.println("Adding: " + button.getText());
		}
	}
	private int getIndexOf(Component button) {
		int ncomponents = cp.getComponentCount();

		for(int i=0; i < ncomponents; ++i) {
			Component c = cp.getComponent(i);
			if(button == c)
				return i;
		}
		return -1;
	}
}
