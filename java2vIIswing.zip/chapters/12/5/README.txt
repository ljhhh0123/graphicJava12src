This applet works as advertised, but clicking on a button changes
it's zorder, which is a bug.
