import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JButton left, right;
		JSplitPane sp = new JSplitPane();
		ControlPanel cp = new ControlPanel(sp);

		contentPane.setLayout(new BorderLayout());
		contentPane.add(sp, BorderLayout.CENTER);
		contentPane.add(cp, BorderLayout.NORTH);

		left = (JButton)sp.getTopComponent();
		right = (JButton)sp.getBottomComponent();

		System.out.println("left button minimum size: " + 
					left.getMinimumSize());
		System.out.println("right button minimum size: " + 
					right.getMinimumSize());

	}
}

class ControlPanel extends JPanel {
	private JSplitPane sp;

	public ControlPanel(JSplitPane splitPane) {
		sp = splitPane;

		JComboBox dividerSize = new JComboBox();
		JComboBox orientation = new JComboBox();

		JCheckBox continuous = new JCheckBox(
									"Continuous Layout");
		JCheckBox oneTouch = new JCheckBox(
									"One Touch Expandable");

		Integer initialSize = new Integer(sp.getDividerSize());
		dividerSize.addItem(initialSize.toString());
		dividerSize.addItem("10");
		dividerSize.addItem("20");
		dividerSize.addItem("30");
		dividerSize.addItem("40");

		orientation.addItem("horizontal");
		orientation.addItem("vertical");

		int initialOrientation = sp.getOrientation();
		if(initialOrientation == JSplitPane.HORIZONTAL_SPLIT)
			orientation.setSelectedItem("horizontal");
		else
			orientation.setSelectedItem("vertical");

		boolean initialContinuousLayout = sp.isContinuousLayout();
		if(initialContinuousLayout)
			continuous.setSelected(true);

		add(oneTouch);
		add(continuous);
		add(new JLabel("Divider Size:"));
		add(dividerSize);
		add(new JLabel("Orientation:"));
		add(orientation);

		oneTouch.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED)
					sp.setOneTouchExpandable(true);
				else
					sp.setOneTouchExpandable(false);
			}
		});
		continuous.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED)
					sp.setContinuousLayout(true);
				else
					sp.setContinuousLayout(false);
			}
		});
		dividerSize.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				JComboBox combo = (JComboBox)e.getSource();
				String s = (String)combo.getSelectedItem();

				sp.setDividerSize(Integer.parseInt(s));
			}
		});
		orientation.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				JComboBox combo = (JComboBox)e.getSource();
				String s = (String)combo.getSelectedItem();

				if(s.equals("horizontal"))
					sp.setOrientation(
							JSplitPane.HORIZONTAL_SPLIT);
				else
					sp.setOrientation(JSplitPane.VERTICAL_SPLIT);
			}
		});
	}
}
