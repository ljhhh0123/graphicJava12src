import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.text.*;

public class Test extends JApplet {
	Component glassPane = new AnnotationPane();
	JCheckBox annotations = new JCheckBox("annotations");

	public void init() {
		createContainerHierarchy();
		setupGlassPane();
	}
	private void createContainerHierarchy() {
		Container contentPane = getContentPane();

		JPanel controlPanel = new JPanel();
		JTextArea textArea = new JTextArea();
		JScrollPane scrollPane = new JScrollPane(textArea);

		readFile(textArea.getDocument());

		controlPanel.add(annotations);

		contentPane.add(scrollPane, "Center"); // scroll pane
		contentPane.add(controlPanel, "South"); // panel

		textArea.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				System.out.println("enter");
			}
		});
	}
	private void setupGlassPane() {
		setGlassPane(glassPane);
	
		annotations.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED)
					glassPane.setVisible(true);
				else
					glassPane.setVisible(false);
			}
		});
	}
	private void readFile(Document doc) {
		try {
			Reader in = new FileReader("Test.java");
			char[] buff = new char[4096];
			int next;

			while ((next = in.read(buff, 0, buff.length)) != -1)
		    	doc.insertString(
				doc.getLength(), new String(buff, 0, next), null);
		}
		catch(Exception e) {
			System.out.println("interruption");
		}
	}
}
class AnnotationPane extends JPanel {
	private Icon annotations[] = {
		new ImageIcon("annotation.gif"),
		new ImageIcon("annotation_1.gif"),
		new ImageIcon("annotation_2.gif")
	};
	public void paintComponent(Graphics g) {
		annotations[0].paintIcon(this, g, 400, 50);
		annotations[1].paintIcon(this, g, 10, 150);
		annotations[2].paintIcon(this, g, 10, 265);
	}
}
