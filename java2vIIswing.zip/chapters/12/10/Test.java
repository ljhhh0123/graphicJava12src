import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JTabbedPane tp = new JTabbedPane();
		JPanel panelOne = new JPanel();
		JPanel panelTwo = new JPanel();

		panelOne.add(new JButton("button in panel 1"));
		panelTwo.add(new JButton("button in panel 2"));

		tp.add(panelOne, "Panel One");
		tp.addTab("Panel Two", 
					new ImageIcon("document.gif"),
					panelTwo, 
					"tooltip text");

		contentPane.setLayout(new BorderLayout());
		contentPane.add(tp);
	}
}
