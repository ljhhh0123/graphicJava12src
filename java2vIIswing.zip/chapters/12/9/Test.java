import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		setContentPane(new CustomContentPane());
	}
}
class CustomContentPane extends JLayeredPane {
	private ImageIcon rain = new ImageIcon("rain.gif");
	private ImageIcon punch = new ImageIcon("punch.gif");
	private ImageIcon skelly = new ImageIcon("skelly.gif");
	private int rainw = rain.getIconWidth();
	private int rainh = rain.getIconHeight();

	private JLabel[] labels = { 
		new JLabel("I stay put", punch, SwingConstants.RIGHT),
		new JLabel("Drag me around!", 
					skelly, SwingConstants.RIGHT),
	};

	public CustomContentPane() {
		Dragger listener = new Dragger();
		JCheckBox onDragLayer = new JCheckBox("Drag Layer");

		// JLayeredPane has a null layout by default
		setLayout(new FlowLayout());

		onDragLayer.setOpaque(false);

		add(onDragLayer);
		add(labels[0]);
		add(labels[1]);

		labels[1].addMouseMotionListener(listener);
		labels[1].addMouseListener(listener);

		setLabelText();

		onDragLayer.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					setLayer(labels[1], 
						JLayeredPane.DRAG_LAYER.intValue());
				}
				else {
					setLayer(labels[1], 
						JLayeredPane.DEFAULT_LAYER.intValue());
					
				}
				setLabelText();
				validate();
			}
		});
	}
	public void paintComponent(Graphics g) {
		Dimension size = getSize();

		for(int row=0; row < size.height; row += rainh)
			for(int col=0; col < size.width; col += rainw)
				rain.paintIcon(this,g,col,row);
	}
	private void setLabelText() {
		for(int i=0; i < labels.length; ++i) {
			JLabel label = labels[i];
			String t = new String("Layer:  ");

			t += "(" + getLayer(label) + "),";
			t += "  Index:  " + getIndexOf(label);

			label.setText(t);
		}
	}
}
class Dragger extends MouseAdapter 
								implements MouseMotionListener {
	Point	press	 = new Point();
	boolean dragging = false;

	public void mousePressed(MouseEvent event) {
		press.x = event.getX();
		press.y = event.getY();
		dragging = true;
	}
	public boolean isDragging() {
		return dragging;
	}
	public void mouseReleased(MouseEvent event) {
		dragging = false;
	}
	public void mouseClicked(MouseEvent event) {
		dragging = false;
	}
	public void mouseMoved(MouseEvent event) {
		// don't care
	}
	public void mouseDragged(MouseEvent event) {
		Component c = (Component)event.getSource();

		if(dragging) {
			Point loc = c.getLocation();
			Point pt  = new Point();
			pt.x = event.getX() + loc.x - press.x;
			pt.y = event.getY() + loc.y - press.y;
			c.setLocation(pt.x, pt.y);
			c.getParent().repaint();
		}
	}
}
