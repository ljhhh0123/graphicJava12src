import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JPanel panel = new JPanel(new BorderLayout());
		JPanel controlPanel = new JPanel();
		JPanel canvas = new Canvas();

		canvas.setBorder(
			BorderFactory.createLineBorder(Color.black));

		controlPanel.add(new JLabel("Name:"));
		controlPanel.add(new JTextField(20));

		panel.add(controlPanel, BorderLayout.NORTH);
		panel.add(canvas, BorderLayout.CENTER);

		contentPane.add(panel);
	}
}
class Canvas extends JPanel {
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		Dimension size = getSize();
		g.setColor(Color.black);
		g.drawLine(50,50,size.width,size.height);
		g.drawArc(20,40,25,25,0,290);
		g.drawString("A JPanel Used as a Canvas", 20, 20);
	}
}
