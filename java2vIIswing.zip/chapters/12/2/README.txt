This applet works as advertised, but if the window looses
focus, the button is placed in front of the glass pane,
which is a bug.
