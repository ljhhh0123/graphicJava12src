import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JToolBar toolbar = new JToolBar();

		toolbar.add(new NewAction());
		toolbar.add(new OpenAction());
		toolbar.addSeparator();
		toolbar.add(new CutAction());
		toolbar.add(new CopyAction());
		toolbar.add(new PasteAction());

		toolbar.putClientProperty("JToolBar.isRollover", 
									Boolean.TRUE);

		contentPane.add(toolbar, BorderLayout.NORTH);
	}
	class NewAction extends AbstractAction {
		public NewAction() {
			putValue(Action.SMALL_ICON, 
						new ImageIcon("new.gif"));
		}
		public void actionPerformed(ActionEvent event) {
			showStatus("new");
		}
	}
	class OpenAction extends AbstractAction {
		public OpenAction() {
			putValue(Action.SMALL_ICON, 
						new ImageIcon("open.gif"));
		}
		public void actionPerformed(ActionEvent event) {
			showStatus("open");
		}
	}
	class CutAction extends AbstractAction {
		public CutAction() {
			putValue(Action.SMALL_ICON, new ImageIcon("cut.gif"));
		}
		public void actionPerformed(ActionEvent event) {
			showStatus("cut");
		}
	}
	class CopyAction extends AbstractAction {
		public CopyAction() {
			putValue(Action.SMALL_ICON, 
						new ImageIcon("copy.gif"));
		}
		public void actionPerformed(ActionEvent event) {
			showStatus("copy");
		}
	}
	class PasteAction extends AbstractAction {
		public PasteAction() {
			putValue(Action.SMALL_ICON, 
						new ImageIcon("paste.gif"));
		}
		public void actionPerformed(ActionEvent event) {
			showStatus("paste");
		}
	}
}
