import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();

		JMenuBar mb = new JMenuBar();
		JMenu checkBoxMenu = new JMenu("Endangered Species");

		ImageIcon crabIcon = new ImageIcon("crab.gif");
		ImageIcon eagleIcon = new ImageIcon("eagle.gif");

		JMenuItem 
			crabItem = new JCheckBoxMenuItem(crabIcon),
			eagleItem = new JCheckBoxMenuItem("eagle", 
												eagleIcon, true),
			ladybugItem = new JCheckBoxMenuItem("ladybug");

		checkBoxMenu.add(crabItem);
		checkBoxMenu.add(eagleItem);
		checkBoxMenu.add(ladybugItem);

		ladybugItem.setMnemonic('l');

		mb.add(checkBoxMenu);
		setJMenuBar(mb);
	}
}
