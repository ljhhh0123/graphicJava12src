import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;

public class Test extends JApplet {
	public void init() {
		final Container contentPane = getContentPane();
		final JPopupMenu popup = new JPopupMenu();
		
		popup.add(new JMenuItem("item one"));
		popup.add(new JMenuItem("item two"));
		popup.add(new JMenuItem("item three"));
		popup.add(new JMenuItem("item four"));

		popup.addPopupMenuListener(new PopupMenuListener() {
			public void popupMenuCanceled(PopupMenuEvent e) {
				showStatus("menu canceled");
			}
			public void popupMenuWillBecomeVisible(
											PopupMenuEvent e) {
				showStatus("menu will become visible");
			}
			public void popupMenuWillBecomeInvisible(
											PopupMenuEvent e) {
				showStatus("menu will become invisible");
			}
		});
		addMouseListener(new MouseAdapter() {
			public void mousePressed (MouseEvent e) { 
				popup.show(contentPane, e.getX(), e.getY());
			}
		});
	}
}
