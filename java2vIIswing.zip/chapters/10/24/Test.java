import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JToolBar tb = new JToolBar();
		JComboBox fontCombo = new JComboBox(),
					fontSizeCombo = new JComboBox();

		JButton newButton = new JButton(new ImageIcon("new.gif")),
			openButton = new JButton(new ImageIcon("open.gif")),
			cutButton = new JButton(new ImageIcon("cut.gif")),
			copyButton = new JButton(new ImageIcon("copy.gif")),
			pasteButton = new JButton(new ImageIcon("paste.gif"));

		fontCombo.addItem("Helvetica");
		fontCombo.addItem("Palatino");
		fontCombo.addItem("Courier");
		fontCombo.addItem("Times");
		fontCombo.addItem("Times-Roman");

		fontSizeCombo.addItem("10");
		fontSizeCombo.addItem("12");
		fontSizeCombo.addItem("14");
		fontSizeCombo.addItem("16");
		fontSizeCombo.addItem("18");

		tb.add(newButton);
		tb.add(openButton);

		tb.addSeparator();

		tb.add(cutButton);
		tb.add(copyButton);
		tb.add(pasteButton);

		tb.addSeparator();

		tb.add(fontCombo);
		tb.add(fontSizeCombo);

		newButton.setAlignmentY(0.5f);
		openButton.setAlignmentY(0.5f);
		cutButton.setAlignmentY(0.5f);
		copyButton.setAlignmentY(0.5f);
		pasteButton.setAlignmentY(0.5f);

		newButton.setAlignmentX(0.5f);
		openButton.setAlignmentX(0.5f);
		cutButton.setAlignmentX(0.5f);
		copyButton.setAlignmentX(0.5f);
		pasteButton.setAlignmentX(0.5f);

		fontCombo.setMaximumSize(fontCombo.getPreferredSize());
		fontSizeCombo.setMaximumSize(
						fontSizeCombo.getPreferredSize());

		contentPane.setLayout(new BorderLayout());
		contentPane.add(tb, BorderLayout.NORTH);
	}
}
