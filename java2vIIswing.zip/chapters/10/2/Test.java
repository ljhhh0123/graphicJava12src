import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		JMenuBar mb = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenu pullRightMenu = new JMenu("pull right");

		fileMenu.add("New ...");
		fileMenu.add("Open ...");
		fileMenu.add("Save");
		fileMenu.add("Save As ..");
		fileMenu.addSeparator();
		fileMenu.add(pullRightMenu);
		fileMenu.add("Exit");

		pullRightMenu.add(new JCheckBoxMenuItem("Bush"));
		pullRightMenu.add(new JCheckBoxMenuItem("Tonic"));
		pullRightMenu.add(new JCheckBoxMenuItem("Radio Head"));
		pullRightMenu.add(new JCheckBoxMenuItem("Marcy Playground"));
		pullRightMenu.add(new JCheckBoxMenuItem("Silver Chair"));

		mb.add(fileMenu);
		setJMenuBar(mb);
	}
}
