import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private ImageIcon crabIcon = new ImageIcon("crab.gif", 	
												"Crab");
	private ImageIcon eagleIcon = new ImageIcon("eagle.gif", 
													"Eagle");
	private JMenuItem 
			crabItem = new JRadioButtonMenuItem(crabIcon),
			eagleItem = new JRadioButtonMenuItem("eagle", 
												 eagleIcon),
			ladybugItem = new JRadioButtonMenuItem("ladybug");

	public void init() {
		Container contentPane = getContentPane();

		JMenuBar mb = new JMenuBar();
		JMenu radioMenu = new JMenu("Favorite Animal");

		AnItemListener itemListener = new AnItemListener();
		AnActionListener actionListener = new AnActionListener();
		AChangeListener changeListener = new AChangeListener();

		radioMenu.add(crabItem);
		radioMenu.add(eagleItem);
		radioMenu.add(ladybugItem);

		ButtonGroup group = new ButtonGroup();
		group.add(crabItem);
		group.add(eagleItem);
		group.add(ladybugItem);

		mb.add(radioMenu);
		setJMenuBar(mb);

		crabItem.addItemListener(itemListener);
		eagleItem.addItemListener(itemListener);
		ladybugItem.addItemListener(itemListener);

		crabItem.addActionListener(actionListener);
		eagleItem.addActionListener(actionListener);
		ladybugItem.addActionListener(actionListener);

		crabItem.addChangeListener(changeListener);
		eagleItem.addChangeListener(changeListener);
		ladybugItem.addChangeListener(changeListener);
	}
	private String getItemDescription(JMenuItem item) {
		String s;
		ImageIcon icon = (ImageIcon)item.getIcon();

		if(icon != null) return icon.getDescription();
		else 			 return item.getText();
	}

	// Inner class event handlers follow ...

	class AnActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JMenuItem item = (JMenuItem) e.getSource();
			String s = getItemDescription(item);
			showStatus(s + " activated");

			System.out.println("action event fired");
		}
	};
	class AChangeListener implements ChangeListener { 
		public void stateChanged(ChangeEvent e) {
			Object[] selectedObjs = 
						ladybugItem.getSelectedObjects();

			if(selectedObjs == null)
				System.out.println("selected objs is null");
			else
				System.out.println(selectedObjs[0] + "selected");

			 JMenuItem item = (JMenuItem)e.getSource();

			if(item.isArmed()) {
				String s = getItemDescription(item);
				showStatus(s + " armed");
			}
			System.out.println("change event fired");
		}
	};
	class AnItemListener implements ItemListener { 
		public void itemStateChanged(ItemEvent e) {
			 JMenuItem item = (JMenuItem) e.getSource();
			String s = getItemDescription(item);

			if(e.getStateChange() == ItemEvent.SELECTED)
				s += " selected";
			else
				s += " deselected";

			showStatus(s);
			System.out.println("item event fired");
		}
	};
}
