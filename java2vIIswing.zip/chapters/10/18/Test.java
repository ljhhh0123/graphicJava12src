import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	JComboBox combobox = new JComboBox();
	JPopupMenu popup  = new JPopupMenu();
	ColoredCanvas popupRelativeToMe;
	ColoredCanvas blueCanvas, redCanvas, yellowCanvas;

	public void init() {
		Container contentPane = getContentPane();
		blueCanvas        = new ColoredCanvas(Color.blue);
		redCanvas         = new ColoredCanvas(Color.red);
		yellowCanvas      = new ColoredCanvas(Color.yellow);
		popupRelativeToMe = blueCanvas;

		popup.add(new JMenuItem("item one"));
		popup.add(new JMenuItem("item two"));
		popup.add(new JMenuItem("item three"));
		popup.add(new JMenuItem("item four"));

		contentPane.setLayout(new FlowLayout());
		contentPane.add(new JLabel("Popup Over:"));
		contentPane.add(combobox);       
		contentPane.add(blueCanvas);
		contentPane.add(redCanvas);
		contentPane.add(yellowCanvas);

		combobox.addItem("Blue Canvas");
		combobox.addItem("Yellow Canvas");
		combobox.addItem("Red Canvas");

		combobox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent event) {
				if(event.getStateChange() == ItemEvent.SELECTED) {
					JComboBox c = (JComboBox)event.getSource();
					String label = (String)c.getSelectedItem();

					if(label.equals("Blue Canvas"))
						popupRelativeToMe = blueCanvas;
					else if(label.equals("Red Canvas"))
						popupRelativeToMe = redCanvas;
					else if(label.equals("Yellow Canvas"))
						popupRelativeToMe = yellowCanvas;

					popup.show(popupRelativeToMe, 5, 5);
				}
			}
		});
	}
}
class ColoredCanvas extends JPanel {
	private Color color;

	public ColoredCanvas(Color color) {
		this.color = color;
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		Dimension size = getSize();
		g.setColor  (color);
		g.fill3DRect(0,0,size.width-1,size.height-1,true);
	}
	public Dimension getPreferredSize() {
		return new Dimension(100,100);
	}
}
