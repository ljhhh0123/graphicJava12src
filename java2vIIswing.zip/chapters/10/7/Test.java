import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private ImageIcon crabIcon = new ImageIcon("crab.gif");
	private ImageIcon eagleIcon = new ImageIcon("eagle.gif");

	private JCheckBoxMenuItem 
		crabItem = new JCheckBoxMenuItem(crabIcon),
		eagleItem = new JCheckBoxMenuItem("eagle", eagleIcon),
		ladybugItem = new JCheckBoxMenuItem("ladybug");

	public void init() {
		Container contentPane = getContentPane();

		JMenuBar mb = new JMenuBar();
		JMenu checkBoxMenu = new JMenu("Endangered Species");
		Listener listener = new Listener();

		checkBoxMenu.add(crabItem);
		checkBoxMenu.add(eagleItem);
		checkBoxMenu.add(ladybugItem);

		crabItem.addActionListener(listener);
		eagleItem.addActionListener(listener);
		ladybugItem.addActionListener(listener);

		mb.add(checkBoxMenu);
		setJMenuBar(mb);
	}
	class Listener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			showStatus("crab:  " + crabItem.getState() + ", " +
						"eagle:  " + eagleItem.getState() + ", " +
						"ladybug:  " + ladybugItem.getState());
		}
	}
}
