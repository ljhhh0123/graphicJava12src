import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		JMenuBar mb = new JMenuBar();
		JMenu fileMenu = new JMenu("File");

		fileMenu.add("New ...");
		fileMenu.add("Open ...");
		fileMenu.add("Save");
		fileMenu.add("Save As ..");
		fileMenu.addSeparator();
		fileMenu.add("Exit");

		mb.add(fileMenu);
		setJMenuBar(mb);

		fileMenu.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent e) {
				System.out.println("menu canceled");
			}
			public void menuSelected(MenuEvent e) {
				System.out.println("menu selected");
			}
			public void menuDeselected(MenuEvent e) {
				System.out.println("menu deselected");
			}
		});
	}
}
