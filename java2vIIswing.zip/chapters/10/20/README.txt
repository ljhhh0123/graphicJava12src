This applet also exhibits a bug: the popup cannot be dismissed
by clicking on a menu item.
