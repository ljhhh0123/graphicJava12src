import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private JPopupMenu popup = new JPopupMenu();

	public void init() {
		Container contentPane = getContentPane();
		JLabel label = new JLabel("Click To Show Popup");

		popup.add(new JMenuItem("item one"));
		popup.add(new JMenuItem("item two"));
		popup.add(new JMenuItem("item three"));
		popup.add(new JMenuItem("item four"));

		label.setHorizontalAlignment(JLabel.CENTER);
		contentPane.add(label, BorderLayout.CENTER);

		label.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				//if(e.isPopupTrigger()) {
					popup.setVisible(true);
				//}
			}
		});
	}
}
