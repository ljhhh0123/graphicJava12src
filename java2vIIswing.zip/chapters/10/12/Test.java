import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {

	public void init() {
		JMenuBar menuBar = new JMenuBar();
		createMenus(menuBar);
		setJMenuBar(menuBar);
	}
    public void createMenus(JMenuBar mbar) {
        mbar.add(createFileMenu());
        mbar.add(createCascadingMenu());
    }
    private JMenu createFileMenu() {
 		JMenu fileMenu = new JMenu("File"); 
 		JMenuItem quitItem = new JMenuItem("Quit");

 		fileMenu.add(quitItem);

		quitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				System.exit(0);
			}
		});
		return fileMenu;
    }
    private JMenu createCascadingMenu() {
        JMenu cascading  = new JMenu("Cascading", true);
        JMenu submenu    = new JMenu("pull right menu 1", true);
        JMenu subsubmenu = new JMenu("pull right menu 2", true);

        submenu.add("submenu item 1");
        submenu.add("submenu item 2");
        submenu.add("submenu item 3");
        submenu.add("submenu item 4");
        submenu.add("submenu item 5");

        subsubmenu.add("subsubmenu item 1");
        subsubmenu.add("subsubmenu item 2");
        subsubmenu.add("subsubmenu item 3");
        subsubmenu.add("subsubmenu item 4");
        subsubmenu.add("subsubmenu item 5");

        submenu.add(subsubmenu);
        cascading.add(submenu);

        return cascading;
    }
}
