import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		Icon newIcon = new ImageIcon("new.gif", 
									 "Create a new document");
		Icon openIcon = new ImageIcon("open.gif",
									 "Open an existing document");

		JMenuBar mb = new JMenuBar();
		JMenu fileMenu = new JMenu("File");

		JMenuItem newItem = new JMenuItem(newIcon);
		JMenuItem openItem = new JMenuItem("Open ...", openIcon);
		JMenuItem saveItem = new JMenuItem("Save");
		JMenuItem saveAsItem = new JMenuItem("Save As ...");
		JMenuItem exitItem = new JMenuItem("Exit", 'x');

		fileMenu.add(newItem);
		fileMenu.add(openItem);
		fileMenu.add(saveItem);
		fileMenu.add(saveAsItem);
		fileMenu.addSeparator();
		fileMenu.add(exitItem);

		MenuItemListener listener = new MenuItemListener(this);

		newItem.addActionListener(listener);
		openItem.addActionListener(listener);
		saveItem.addActionListener(listener);
		saveAsItem.addActionListener(listener);

		exitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		mb.add(fileMenu);
		setJMenuBar(mb);
	}
}
class MenuItemListener implements ActionListener {
	private JApplet applet;

	public MenuItemListener(JApplet applet) {
		this.applet = applet;
	}
	public void actionPerformed(ActionEvent e) {
		JMenuItem item = (JMenuItem)e.getSource();
		ImageIcon icon = (ImageIcon)item.getIcon();

		if(icon != null)
			System.out.println(icon.getDescription());
		else
			System.out.println(item.getText());
	}
}
