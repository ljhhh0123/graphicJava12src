When the book was written, this applet worked fine, but now
the popup is only shown if it is a heavyweight popup, ie.
if you click in the applet so that part of the popup extends
past the bounds of the window, the popup will show; otherwise,
it will not.

