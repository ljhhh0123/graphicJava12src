import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private JPopupMenu popup = new JPopupMenu();

	public void init() {
		Container contentPane = getContentPane();

		popup.add(new JMenuItem("item one"));
		popup.add(new JMenuItem("item two"));
		popup.add(new JMenuItem("item three"));
		popup.add(new JMenuItem("item four"));

		contentPane.addMouseListener(new MouseAdapter() {
			public void mousePressed (MouseEvent e) { 
				showPopup(e); 
			}
			public void mouseClicked (MouseEvent e) { 
				showPopup(e); 
			}
			public void mouseReleased(MouseEvent e) { 
				showPopup(e); 
			}
		});
	}
	void showPopup(MouseEvent e) {
		if(e.isPopupTrigger())
			popup.show(this, e.getX(), e.getY());
	}
}
