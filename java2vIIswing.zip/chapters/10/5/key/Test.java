import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		JMenuBar mb = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenuItem newItem = new JMenuItem("New ..."),
					openItem = new JMenuItem("Open ..."),
					saveItem = new JMenuItem("Save"),
					saveAsItem = new JMenuItem("Save As ..."),
					exitItem = new JMenuItem("Exit");
		Listener listener = new Listener(this);

		fileMenu.add(newItem);
		fileMenu.add(openItem);
		fileMenu.add(saveItem);
		fileMenu.add(saveAsItem);
		fileMenu.addSeparator();
		fileMenu.add(exitItem);

		newItem.addMenuKeyListener(listener);
		openItem.addMenuKeyListener(listener);
		saveItem.addMenuKeyListener(listener);
		saveAsItem.addMenuKeyListener(listener);
		exitItem.addMenuKeyListener(listener);

		saveItem.setMnemonic(KeyEvent.VK_S);

		mb.add(fileMenu);
		setJMenuBar(mb);

		exitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
	}
}
class Listener implements MenuKeyListener {
	private JApplet applet;

	public Listener(JApplet applet) {
		this.applet = applet;
	}
	public void menuKeyPressed(MenuKeyEvent e) {
		reportKeyEvent(e);
	}
	public void menuKeyReleased(MenuKeyEvent e) {
		reportKeyEvent(e);
	}
	public void menuKeyTyped(MenuKeyEvent e) {
		reportKeyEvent(e);
	}
	private void reportKeyEvent(MenuKeyEvent e) {
		MenuElement[] path = e.getPath();
		MenuElement lastPathElement = path[path.length-1];
		JMenuItem menuItem = (JMenuItem)lastPathElement.getComponent();

		System.out.println("key pressed: " +
						  menuItem.getActionCommand());
	}
}
