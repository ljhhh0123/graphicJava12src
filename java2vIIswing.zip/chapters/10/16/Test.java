import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		final JLabel label = new JLabel("Click here for popup");
		final JPopupMenu popup = new JPopupMenu();
		final JSlider slider = new JSlider();

		popup.add(new JMenuItem("Copy", 
								 new ImageIcon("copy.gif")));
		popup.add(new CutAction());
		popup.addSeparator();
		popup.add(slider);

		label.addMouseListener(new MouseAdapter() {
			public void mousePressed (MouseEvent e) { 
				popup.show(label, e.getX(), e.getY());
			}
		});
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if( ! slider.getValueIsAdjusting())
					popup.setVisible(false);
			}
		});

		label.setHorizontalAlignment(JLabel.CENTER);
		contentPane.add(label, BorderLayout.CENTER);
	}
	class CutAction extends AbstractAction {
		public CutAction() {
			super("Cut", new ImageIcon("cut.gif"));
		}
		public void actionPerformed(ActionEvent e) {
			System.out.println("cut");
		}
	}
}
