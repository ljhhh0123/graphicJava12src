Due to a bug in the 1.2 JDK, the slider does not show up in
the popup. The applet works under 1.1.7.
