import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JFrame {
	public Test() {
		final JMenuBar mb = new JMenuBar();
		final JMenu fileMenu = new JMenu("File");
		JMenuItem exitItem = new JMenuItem("Exit");

		fileMenu.add("New ...");
		fileMenu.add("Open ...");
		fileMenu.add("Save");
		fileMenu.add("Save As ..");
		fileMenu.addSeparator();
		fileMenu.add(exitItem);

		mb.add(new JLabel(
					new ImageIcon("smiley_face_small.gif")));

		mb.add(fileMenu);

		// Either one of the following two lines will 
		// attach the menu bar to the application
		//setJMenuBar(mb);
		getRootPane().setJMenuBar(mb);

		exitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				System.exit(0);
			}
		});
		System.out.println("component count:  " + 
						   mb.getComponentCount());
		System.out.println("first component: " + 
			(mb.getComponentAtIndex(0)).getClass().getName());

		System.out.println("menu count: " + (mb.getMenuCount()));

		JMenu menu = mb.getMenu(0);
		if(menu == null) System.out.println("null menu");
		else 			 System.out.println("got menu");
	}
 	public static void main(String args[]) {
		GJApp.launch(new Test(), 
					"A Menu Bar",300,300,300,250); 
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
