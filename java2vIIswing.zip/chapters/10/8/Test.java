import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();

		JMenuBar mb = new JMenuBar();
		JMenu radioMenu = new JMenu("Favorite Animal");

		ImageIcon crabIcon = new ImageIcon("crab.gif");
		ImageIcon eagleIcon = new ImageIcon("eagle.gif");

		final JMenuItem 
			crabItem = new JRadioButtonMenuItem(crabIcon),
			eagleItem = new JRadioButtonMenuItem("eagle", 
												 eagleIcon),
			ladybugItem = new JRadioButtonMenuItem("ladybug");

		radioMenu.add(crabItem);
		radioMenu.add(eagleItem);
		radioMenu.add(ladybugItem);

		mb.add(radioMenu);
		setJMenuBar(mb);
	}
}
