import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class Test extends JApplet {
    private SelfModifyingMenu selfModifyingMenu;

	public void init() {
		JMenuBar menuBar = new JMenuBar();
		createMenus(menuBar);
		setJMenuBar(menuBar);
	}
    public void createMenus(JMenuBar mbar) {
        mbar.add(createFileMenu());
        mbar.add(selfModifyingMenu = new SelfModifyingMenu());
    }
    private JMenu createFileMenu() {
		JMenu fileMenu = new JMenu("File"); 
		JMenuItem quitItem = new JMenuItem("Quit");

		fileMenu.add(quitItem);

		quitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				System.exit(0);
			}
		});
		return fileMenu;
	}
}
class SelfModifyingMenu extends JMenu {
	private Vector   newItems = new Vector();
	private Listener menuItemListener = new Listener();
	private JMenuItem toggleItem, enablerItem, 
						addItem, removeItem;

	public SelfModifyingMenu() {
		super("Self Modifying Menu");

		add(enablerItem = new JMenuItem("Disable Item Below"));
		add(toggleItem  = new JMenuItem("Enable/Disable Me"));
		addSeparator();

		add(addItem    = new JMenuItem("Add a JMenuItem ..."));
		add(removeItem = new JMenuItem(
									"Remove last JMenuItem ..."));
		addItem.setFont(new Font("Helvetica", Font.BOLD, 18));
		addSeparator();

		enablerItem.addActionListener(menuItemListener);
		toggleItem.addActionListener(menuItemListener);
		addItem.addActionListener(menuItemListener);
		removeItem.addActionListener(menuItemListener);
	}
	public void addItem() {
		JMenuItem newItem = 
				new JMenuItem("Extra Item #" + newItems.size());
        
		add(newItem);
		newItems.addElement(newItem);
	}
	public void removeLastItem() {
		if(newItems.size() == 0)
			System.out.println("Nothing to remove!");
		else {
			JMenuItem removeMe = 
							(JMenuItem)newItems.lastElement();

			remove(removeMe);
			newItems.removeElement(removeMe);
		}
	}
	public void toggleItem() {
		if(toggleItem.isEnabled()) toggleItem.setEnabled(false);
		else                       toggleItem.setEnabled(true);
	}
	class Listener implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			JMenuItem item = (JMenuItem)event.getSource();

			if(item == enablerItem) {
				toggleItem();

				if(toggleItem.isEnabled()) 
					enablerItem.setText("Disable Item Below");
				else
					enablerItem.setText("Enable Item Below");
			}
			else if(item == addItem)    addItem();
			else if(item == removeItem) removeLastItem();
		}
	}
}
