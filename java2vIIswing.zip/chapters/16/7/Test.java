import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import java.beans.*;

public class Test extends JFrame {
	JFileChooser chooser = new JFileChooser();
	JButton button = new JButton("show file chooser ...");

	public Test() {
		super("Simple File Chooser Application");
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);		

		chooser.setMultiSelectionEnabled(true);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int state = chooser.showOpenDialog(null);
				File[] files = chooser.getSelectedFiles();
				String[] filenames = getFilenames(files);

				if(filenames != null &&
				   state == JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(null,filenames);
				}
				else if(state == JFileChooser.CANCEL_OPTION) {
					JOptionPane.showMessageDialog(
											null, "Canceled");
				}
				else if(state == JFileChooser.ERROR_OPTION) {
					JOptionPane.showMessageDialog(
											null, "Error!");
				}
			}
		});
	}
	private String[] getFilenames(File[] files) {
		String[] filenames = null;
		int numFiles = files.length;

System.out.println(numFiles);

		if(files.length > 0) {
 			filenames = new String[numFiles];

			for(int i=0; i < numFiles; ++i) {
				filenames[i] = files[i].getPath();
				System.out.println(filenames[i]);
			}
		}
		return filenames;
	}
	public static void main(String args[]) {
		JFrame f = new Test();
		f.setBounds(300,300,350,100);
		f.setVisible(true);

		f.setDefaultCloseOperation(
			WindowConstants.DISPOSE_ON_CLOSE);
	
		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);	
			}
		});
	}
}
