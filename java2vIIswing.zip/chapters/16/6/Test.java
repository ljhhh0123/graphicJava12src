import javax.swing.*;
import javax.swing.filechooser.FileView;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Test extends JFrame {
	JFileChooser chooser = new JFileChooser();
	JButton button = new JButton("show file chooser ...");

	public Test() {
		super("Custom File View Example");
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);		

		chooser.setFileView(new CustomFileView());

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int state = chooser.showSaveDialog(null);
				File file = chooser.getSelectedFile();
				String s = "CANCELED";

				if(state == JFileChooser.APPROVE_OPTION) 
					s = "File: " + file.getPath();

				JOptionPane.showMessageDialog(null, s);
			}
		});
	}
	public static void main(String args[]) {
		JFrame f = new Test();
		f.setBounds(300,300,350,100);
		f.setVisible(true);

		f.setDefaultCloseOperation(
								WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);	
			}
		});
	}
}
class CustomFileView extends FileView {
	private Icon fileIcon = new ImageIcon("file.gif"), 
				 directoryIcon = new ImageIcon("folder.gif"),
				 imageIcon = new ImageIcon("photo.jpg");

	public String getName(File f) { return null; }
	public String getDescription(File f) { return null; }
	public String getTypeDescription(File f) { return null; }

	public Icon getIcon(File f) {
		Icon icon = null;

		if(isImage(f)) 			 icon = imageIcon;
		else if(f.isDirectory()) icon = directoryIcon;
		else 					 icon = fileIcon;

		return icon;
	}
	public Boolean isTraversable(File f) {
		Boolean b = null;

		if(f.getPath().equals("D:\\file.txt")) {
			b = new Boolean(false);
		}
		else if(f.getPath().equals("D:\\books")) {
			b = new Boolean(false);
		}
		return b == null ? new Boolean(true) : b;
	}
	private boolean isImage(File f) {
		String suffix = getSuffix(f);
		boolean isImage = false;

		if(suffix != null) {
			isImage = suffix.equals("gif") || 
					  suffix.equals("bmp") ||
			   		  suffix.equals("jpg");
		}
		return isImage;
	}
	private String getSuffix(File file) {
		String filestr = file.getPath(), suffix = null;
		int i = filestr.lastIndexOf('.');

		if(i > 0 && i < filestr.length()) {
			suffix = filestr.substring(i+1).toLowerCase();	
		}
		return suffix;
	}
}
