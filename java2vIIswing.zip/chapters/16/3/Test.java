import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;

public class Test extends JFrame {
	JFileChooser chooser = new JFileChooser();
	ImagePreviewer previewer = new ImagePreviewer();


	public Test() {
		super("Accessory Components");
		
		Container contentPane = getContentPane();
		JButton	button = new JButton("Select A File");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);		

		setAccessoryComponent();

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chooser.showOpenDialog(null);
			}
		});
	}
	private void setAccessoryComponent() {
		JPanel previewPanel = new JPanel();

		previewPanel.setLayout(new BorderLayout());
		previewPanel.add(new JLabel("Image Previewer", 
									SwingConstants.CENTER),
							 		BorderLayout.NORTH);

		previewPanel.add(previewer, BorderLayout.CENTER);

		previewer.setPreferredSize(new Dimension(200,0));
		previewer.setBorder(BorderFactory.createEtchedBorder());

		chooser.setAccessory(previewPanel);

		new ImagePreviewerAccessoryAdapter(chooser, previewer);
	}
	public static void main(String a[]) {
		JFrame f = new Test();
		f.setBounds(300, 300, 300, 75);
		f.setVisible(true);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
class ImagePreviewerAccessoryAdapter extends Object {
	public ImagePreviewerAccessoryAdapter(
								JFileChooser chooser,
								final ImagePreviewer previewer) {
		chooser.addPropertyChangeListener(
									new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent e) {
				if(e.getPropertyName().equals(
				   JFileChooser.SELECTED_FILE_CHANGED_PROPERTY)) {
					previewer.update((File)e.getNewValue());
				}
			}
		});
	}
}
class ImagePreviewer extends JComponent {
	private ImageIcon icon;

	public void update(File file) {
		Dimension size = getSize();
		Insets insets = getInsets();

		icon = new ImageIcon(file.getPath());
		
		icon.setImage(icon.getImage().getScaledInstance(
						size.width - insets.left - insets.right, 
						size.height - insets.top - insets.bottom, 
						Image.SCALE_SMOOTH));

		if(isShowing()) {
			repaint();
		}
	}
	public void paintComponent(Graphics g) {
		Insets insets = getInsets();

		super.paintComponent(g);

		if(icon != null)
			icon.paintIcon(this, g, insets.left, insets.top);
	}
}
