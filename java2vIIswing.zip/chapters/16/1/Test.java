import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import javax.swing.filechooser.*;
import java.beans.*;

public class Test extends JFrame {
	JFileChooser chooser = new JFileChooser();
	JButton button = new JButton("show file chooser ...");


	public Test() {
		super("Simple File Chooser Application");
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);		

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int state = chooser.showOpenDialog(null);
				File file = chooser.getSelectedFile();

				if(file != null &&
				   state == JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(
											null, file.getPath());
				}
				else if(state == JFileChooser.CANCEL_OPTION) {
					JOptionPane.showMessageDialog(
											null, "Canceled");
				}
				else if(state == JFileChooser.ERROR_OPTION) {
					JOptionPane.showMessageDialog(
											null, "Error!");
				}
			}
		});
	}
	public static void main(String args[]) {
		JFrame f = new Test();
		f.setBounds(300,300,350,100);
		f.setVisible(true);

		f.setDefaultCloseOperation(
			WindowConstants.DISPOSE_ON_CLOSE);
	
		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);	
			}
		});
	}
}
