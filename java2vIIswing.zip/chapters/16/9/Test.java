import javax.swing.*;
import javax.swing.colorchooser.*;
import javax.swing.event.*;
import java.awt.*;

public class Test extends JApplet {
	JColorChooser chooser = new JColorChooser();
	ColorSelectionModel model = chooser.getSelectionModel();

	public void init() {
		getContentPane().add(chooser, BorderLayout.CENTER);

		model.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				showStatus("Color:  " + chooser.getColor());
			}
		});
	}
}
