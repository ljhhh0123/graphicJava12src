import javax.swing.*;
import javax.swing.event.*;
import javax.swing.colorchooser.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private JColorChooser chooser = new JColorChooser();
	private AbstractColorChooserPanel colorPanels[] =
			new AbstractColorChooserPanel[] {
				new ListPanel(),
			};
	private JButton button = new JButton("Show Color Chooser");
	private JDialog dialog;

	public void init() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button, BorderLayout.CENTER);

		chooser.setChooserPanels(colorPanels);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(dialog == null) 
					dialog	= JColorChooser.createDialog(
							    Test.this,  // parent comp
								"Pick A Color",   // dialog title
								false, 			  // modality
								chooser,		  
								null, null);

				dialog.setVisible(true);
			}
		});
	}
}
class ListPanel extends AbstractColorChooserPanel 
			    implements ListSelectionListener {
	private JPanel labelPanel = new JPanel(),
				   listPanel = new JPanel();

	private JList redList = new JList(), blueList = new JList(), 
				  greenList = new JList();

	private DefaultListModel redModel = new DefaultListModel(),
							 blueModel = new DefaultListModel(),
							 greenModel = new DefaultListModel();

	private boolean isAdjusting = false;

	public void updateChooser() {
		if( ! isAdjusting) {
			isAdjusting = true;

			Color color = getColorFromModel();
			int r = color.getRed(), g = color.getGreen(), 
				b = color.getBlue();

			redList.setSelectedIndex(r);
			redList.ensureIndexIsVisible(r);

			blueList.setSelectedIndex(b);
			blueList.ensureIndexIsVisible(b);

			greenList.setSelectedIndex(g);
			greenList.ensureIndexIsVisible(g);

			isAdjusting = false;
		}
	}
    protected void buildChooser() {
		redList.setFixedCellWidth(50);
		greenList.setFixedCellWidth(50);
		blueList.setFixedCellWidth(50);

		for(int i=0; i < 256; ++i) {
			redModel.addElement(Integer.toString(i));
			greenModel.addElement(Integer.toString(i));
			blueModel.addElement(Integer.toString(i));
		}

		redList.setModel(redModel);
		greenList.setModel(greenModel);
		blueList.setModel(blueModel);

		listPanel.setLayout(new GridLayout(0,3,10,0));

		listPanel.add(new JScrollPane(redList));
		listPanel.add(new JScrollPane(blueList));
		listPanel.add(new JScrollPane(greenList));

		labelPanel.setLayout(new GridLayout(0,3,10,0));

		labelPanel.add(new JLabel("Red"));
		labelPanel.add(new JLabel("Blue"));
		labelPanel.add(new JLabel("Green"));

		setLayout(new BorderLayout());
		add(labelPanel, BorderLayout.NORTH);
		add(listPanel, BorderLayout.CENTER);

		redList.addListSelectionListener(this);
		greenList.addListSelectionListener(this);
		blueList.addListSelectionListener(this);
	}
	public void valueChanged(ListSelectionEvent e) {
		int r = redList.getSelectedIndex(),
			b = blueList.getSelectedIndex(),
			g = greenList.getSelectedIndex();

		if(r != -1 && g != -1 && b != -1)
			getColorSelectionModel().setSelectedColor(
											new Color(r,g,b));
	}
    public String getDisplayName() {
		return "display name";
	}
    public Icon getSmallDisplayIcon() {
		return null;
	}
    public Icon getLargeDisplayIcon() {
		return null;
	}
}
