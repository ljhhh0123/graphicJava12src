import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.*;
import java.util.*;
import java.net.*;

public class Test extends JFrame {
	JFileChooser chooser = new JFileChooser();
	TextPreviewer previewer = new TextPreviewer();
	JPanel previewPanel = new PreviewPanel();

	class PreviewPanel extends JPanel {
		public PreviewPanel() {
			JLabel label = new JLabel("Text Previewer",
									   SwingConstants.CENTER);
			setPreferredSize(new Dimension(250,0));
			setBorder(BorderFactory.createEtchedBorder());

			setLayout(new BorderLayout());

			label.setBorder(BorderFactory.createEtchedBorder());
			add(label, BorderLayout.NORTH);
			add(previewer, BorderLayout.CENTER);
		}
	}
	public Test() {
		super("Accessory Components");
		
		Container contentPane = getContentPane();
		JButton	button = new JButton("Select A File");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);		

		chooser.setAccessory(previewPanel);
		chooser.addPropertyChangeListener(
									new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent e) {
				if(e.getPropertyName().equals(
					JFileChooser.SELECTED_FILE_CHANGED_PROPERTY))
					previewer.update((File)e.getNewValue());
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chooser.showOpenDialog(null);
			}
		});
	}
	public static void main(String a[]) {
		JFrame f = new Test();
		f.setBounds(300, 300, 300, 75);
		f.setVisible(true);

		f.setDefaultCloseOperation(
								WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
class TextPreviewer extends JComponent {
	private ImageIcon icon;
	private JTextArea textArea = new JTextArea();

	public TextPreviewer() {
		setBorder(BorderFactory.createEtchedBorder());
		setLayout(new BorderLayout());
		add(new JScrollPane(textArea), BorderLayout.CENTER);
	}
	public void update(File file) {
		textArea.setText(contentsOfFile(file));

		if(isShowing()) {
			textArea.revalidate();
		}
	}
	static String contentsOfFile(File file) {
		String s = new String();
		char[] buff = new char[50000];
		InputStream is;
		InputStreamReader reader;
		URL url;

		try {
			reader = new FileReader(file);

			int nch;

			while ((
				nch = reader.read(buff, 0, buff.length)) != -1) {
				s = s + new String(buff, 0, nch);
			}
		} 
		catch (java.io.IOException ex) {
			s = "Could not load file";
		}
		return s;
	}
}
