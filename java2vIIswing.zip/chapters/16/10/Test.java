import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		getContentPane().add(new Palette(), BorderLayout.CENTER);
	}
}
class Palette extends JPanel {
	private Color[] defaultColors = new Color[] {
		Color.blue, Color.red, Color.yellow, Color.green,
		Color.magenta, Color.darkGray, Color.white, Color.orange,
		Color.pink, Color.cyan, Color.lightGray, Color.gray,
	};

	public Palette() {
		int columns = 3;

		setBorder(
			BorderFactory.createTitledBorder("Color Palette"));

		setLayout(new GridLayout(columns,0,1,1));

		for(int i=0; i < defaultColors.length; ++i)
			add(new ColorPatch(defaultColors[i]));
	}	
}
class ColorPatch extends JPanel {
	JApplet applet;
	Color selectedColor;

	public ColorPatch(Color color) {
		setBorder(BorderFactory.createEtchedBorder());
		setBackground(color);

		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				selectedColor = JColorChooser.showDialog(
							    ColorPatch.this,  // parent comp
								"Pick A Color",   // dialog title
								getBackground()); // initial color

				if(selectedColor == null) {
					JOptionPane.showMessageDialog(ColorPatch.this,
						"ColorChooser Canceled");
				}
				else {
					setBackground(selectedColor);
					repaint();

					JOptionPane.showMessageDialog(ColorPatch.this,
						"Color Selected: " + selectedColor);
				}
			}
		});
	}
}
