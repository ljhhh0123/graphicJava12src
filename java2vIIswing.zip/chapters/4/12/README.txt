The applet listed in the book throws an exception with 
Swing 1.1 FCS / JDK 1.2.  Therefore, an application version
is contained in this directory that works.

The applet worked under 1.1.7, but now throws an exception.
