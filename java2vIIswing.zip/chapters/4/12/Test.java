import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Test extends JFrame {
	AnimationPane p = new AnimationPane();

	public Test() {
		super("Swing Double Buffering");
		getContentPane().add(p, "Center");

		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(p.isRunning()) 	p.stop();
				else				p.start();
			}
		});
	}
	public static void main(String args[]) {
		final Frame f = new Test();
		f.setBounds(100,100,300,300);
		f.setVisible(true);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent event) {
				f.dispose();
				System.exit(0);
			}
		});
	}
}
class AnimationPane extends JPanel implements ActionListener {
	Icon[]		icons		= new Icon[4];
	int			iconIndex	= 0;
	Point 		ulhc 		= new Point(0,0);
	Point		moveVector 	= new Point(1,1);
	Timer 		moveTimer 	= new Timer(5, this);
	Timer 		spinTimer 	= new Timer(125, this);
	Dimension 	imsz;

	public AnimationPane() {
		setDoubleBuffered(true);
		setOpaque(true);

		icons[0] = new ImageIcon("baseball.gif");
		icons[1] = new ImageIcon("baseball_90.gif");
		icons[2] = new ImageIcon("baseball_180.gif");
		icons[3] = new ImageIcon("baseball_270.gif");

		imsz = new Dimension(icons[0].getIconWidth(),
							icons[1].getIconHeight());
		start();
	}
	synchronized public void paint(Graphics g) {
		Dimension 		size = getSize();
		RepaintManager 	rm = RepaintManager.currentManager(this);
		Image 			off = rm.getOffscreenBuffer(this, 
													size.width,
													size.height);
		Graphics og = off.getGraphics();
		Rectangle cr = (Rectangle)g.getClip();

		if(cr.width != size.width || cr.height != size.height) {
			g.drawImage(off,0,0,this);
			return;
		}
		try {
			Rectangle oldr = 
						new Rectangle(ulhc.x,ulhc.y,
									imsz.width,imsz.height);
			og.setColor(getBackground());
			og.fillRect(ulhc.x, ulhc.y, imsz.width, imsz.height);

			checkForEdgeCollision(size);
			ulhc.x += moveVector.x;
			ulhc.y += moveVector.y;

			icons[iconIndex].paintIcon(this, og, ulhc.x, ulhc.y);
		
			Rectangle union, newr = new Rectangle(ulhc.x,ulhc.y,
										imsz.width,imsz.height);

			union = oldr.union(newr);
			og.setColor(getBackground());

			g.setClip(union.x,union.y,union.width,union.height);
			g.drawImage(off,0,0,this);
		}
		finally {
			og.dispose();
		}
	}
	public void actionPerformed(ActionEvent event) {
		Timer t = (Timer)event.getSource();

		if(t == spinTimer)
			iconIndex = iconIndex == icons.length-1 ? 
											0 : iconIndex+1;
		repaint();
	}
	public void stop() {
		moveTimer.stop();
		spinTimer.stop();
	}
	public void start() {
		moveTimer.start();
		spinTimer.start();
	}
	public boolean isRunning() {
		return moveTimer.isRunning() && spinTimer.isRunning();
	}
	public void update(Graphics g) {
		paint(g);
	}
	private void checkForEdgeCollision(Dimension size) {
		if(ulhc.x + imsz.width + moveVector.x > size.width ||
								 ulhc.x + moveVector.x < 0)
			moveVector.x -= moveVector.x*2;
		if(ulhc.y + imsz.height + moveVector.y > size.height ||
								  ulhc.y + moveVector.y < 0)
			moveVector.y -= moveVector.y*2;
	}
}
