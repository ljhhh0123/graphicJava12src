import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private JButton button_1 = new NotFocusTraversableButton(),
		button_2 = new ButtonThatManagesFocus(),
		button_3 = new JButton("regular button"),
		button_4 = new JButton("regular button"),
		button_5 = new JButton("request focus disabled"),
		button_6 = new JButton(
		"next focusable component set to Manages Focus button");

	public void init() {
		Container contentPane = getContentPane();
		FocusCycleRootPanel panel = new FocusCycleRootPanel();

		button_5.setRequestFocusEnabled(false);
		button_6.setNextFocusableComponent(button_2);

		panel.add(button_3);
		panel.add(button_4);
		panel.add(button_5);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button_1);
		contentPane.add(button_2);
		contentPane.add(panel);
		contentPane.add(button_6);
	}
}
class ButtonThatManagesFocus extends JButton {
	public ButtonThatManagesFocus() {
		super("Manages Focus");	
	}
	public boolean isManagingFocus() {
		return true;
	}
	public void processComponentKeyEvent(KeyEvent e) {
		System.out.println(e);
	}
}
class NotFocusTraversableButton extends JButton {
	public NotFocusTraversableButton() {
		super("Not Focus Traversable");	
	}
	public boolean isFocusTraversable() {
		return false;
	}
}
class FocusCycleRootPanel extends JPanel {
	public FocusCycleRootPanel() {
		setBorder(BorderFactory.createTitledBorder(
					"FocusCycleRoot Panel"));
	}
	public boolean isFocusCycleRoot() {
		return true;
	}
}
