import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	JComboBox sizeCombo = new JComboBox(new Object[] {
							"null",
							"100 x 100"
						});
	JList list = new JList(new Object[] {
							"item 1",
							"item 2",
							"item 3",
							"item 4",
							"item 5",
						});
	public void init() {
		final Container contentPane = getContentPane();

		list.setBorder(
			BorderFactory.createLineBorder(Color.black));

		sizeCombo.setSelectedIndex(0);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(list);
		contentPane.add(new JLabel("preferred size for list:"));
		contentPane.add(sizeCombo);

		sizeCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index = sizeCombo.getSelectedIndex();

				if(index == 0)
					list.setPreferredSize(null);
				else
					list.setPreferredSize(
							new Dimension(100, 100));
				list.revalidate();
			}
		});
	}
}
