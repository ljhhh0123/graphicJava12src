import javax.swing.*;
import java.awt.*;

public class ButtonAsContainer extends JApplet {
	public void init() {
		JButton b = new JButton("Swing Buttons Are Containers");

		b.setLayout(new FlowLayout());
		b.add(new Button("AWT Button"));
		b.add(new JButton("Swing Button"));

		getContentPane().add(b);
	}
}
