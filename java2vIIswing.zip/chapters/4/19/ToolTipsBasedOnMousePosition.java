import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ToolTipsBasedOnMousePosition extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		ImageMap map = new ImageMap("tiger.gif");
		contentPane.setLayout(new FlowLayout());
		contentPane.add(map);
	}
}
class ImageMap extends JLabel {
	private Rectangle 	teeth= new Rectangle(62,203,80,55),
						nose = new Rectangle(37,164,130,30),
						ear	= new Rectangle(228,10,65,55),
						rEye = new Rectangle(137,103,20,17),
						lEye = new Rectangle(65,97,16,15);

	public ImageMap(String imageName) {
		super(new ImageIcon(imageName));
		setToolTipText("tiger!");
	}
	public String getToolTipText(MouseEvent e) {
		Point 	p = e.getPoint();
		String	s = null;

		if(teeth.contains(p)) 		s = "ooooh, big teeth!";
		else if(nose.contains(p))	s = "keen sense of smell";
		else if(ear.contains(p))	s = "acute hearing";
		else if(rEye.contains(p) || lEye.contains(p)) 
			s = "excellent vision";

		return s == null ? getToolTipText() : s;
	}
}
