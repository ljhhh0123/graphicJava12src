import javax.swing.*;

public class AutoscrollTest extends JApplet {
	public AutoscrollTest() {
		JLabel label = new JLabel(new ImageIcon("pic.gif"));
		JViewport vp = new AutoscrollViewport(label, 3);

		getContentPane().add(vp, "Center");
	}
}
