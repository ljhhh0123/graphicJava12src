import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ToolTipTest extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JButton button = new JButton("I've got a tooltip");

		button.setMnemonic(KeyEvent.VK_G);

		button.setToolTipText(
			"rather lengthy tooltip text for button");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);
	}
}
