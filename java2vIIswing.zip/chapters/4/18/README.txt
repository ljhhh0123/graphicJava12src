For Swing1.1 FCS, tooltips no longer extend past the edge of
the window in which they reside.
