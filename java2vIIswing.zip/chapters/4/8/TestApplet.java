import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TestApplet extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		final JPanel panel = new JPanel();
		JButton button = new JButton("repaint");

		panel.setBackground(Color.blue);
		panel.setPreferredSize(new Dimension(100,100));

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);
		contentPane.add(panel);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Color c = panel.getBackground();
				Dimension sz = panel.getSize();

				panel.setBackground(
					c == Color.blue ? Color.red : Color.blue);

				panel.paintImmediately(
								0,0,sz.width,sz.height);

				// for illustrative purposes only
				try {
					Thread.currentThread().sleep(5000);
				}
				catch(InterruptedException ex) {
					ex.printStackTrace();
				}
			}
		});
	}
}
