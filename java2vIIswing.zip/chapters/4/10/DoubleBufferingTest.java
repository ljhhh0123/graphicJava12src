import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DoubleBufferingTest extends JApplet {
	public void init() {
		final Container contentPane = getContentPane();

		JSlider slider = new JSlider(JSlider.HORIZONTAL,0,100,50);
		JCheckBox dbcheckBox = new JCheckBox("double buffered");
		JPanel controlPanel = new JPanel();

		dbcheckBox.setSelected(true);
		controlPanel.add(dbcheckBox);

		slider.setPaintTicks(true);
		slider.setMinorTickSpacing(5);
		slider.setMajorTickSpacing(15);

		contentPane.add(controlPanel, "North");
		contentPane.add(slider, "Center");

		dbcheckBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent event) {
				JComponent cp = (JComponent)getContentPane();
				JComponent rp = (JComponent)getRootPane();

				if(event.getStateChange() == ItemEvent.SELECTED) {
					rp.setDoubleBuffered(true);
					cp.setDoubleBuffered(true);
				}
				else {
					rp.setDoubleBuffered(false);
					cp.setDoubleBuffered(false);
				}
			}
		});
	}
}
