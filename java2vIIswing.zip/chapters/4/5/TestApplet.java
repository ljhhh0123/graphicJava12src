import javax.swing.*;
import java.awt.*;

public class TestApplet extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		ImageCanvas imagePanel = new ImageCanvas(
									"sphere.gif",
									"a blue sphere");
		imagePanel.setBorder(
			BorderFactory.createTitledBorder("ImageCanvas"));

		contentPane.setLayout(new FlowLayout());
		contentPane.add(imagePanel);
	}
}
class ImageCanvas extends JPanel {
	ImageIcon icon;

	public ImageCanvas(String imageName, String description) {
		icon = new ImageIcon(imageName, description);
	}
	public void paintComponent(Graphics g) {
		Insets insets = getInsets();
		super.paintComponent(g);
		icon.paintIcon(this, g, insets.left, insets.top);
	}
	public Dimension getPreferredSize() {
		Insets insets = getInsets();
		return new Dimension(
			icon.getIconWidth() + insets.left + insets.right, 
			icon.getIconHeight() + insets.top + insets.bottom);
	}
}
