import javax.swing.*;
import javax.accessibility.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container 	contentPane = getContentPane();
		JLabel 		label 		= new JLabel("First Name:");
		JButton 	showButton 	= new JButton(
								  "show accessible information");

		final JTextField field 	= new JTextField(15);

		AccessibleContext fieldContext = 
							field.getAccessibleContext();

		fieldContext.setAccessibleName("First Name");
		fieldContext.setAccessibleDescription(
									"Enter your first name");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(showButton);
		contentPane.add(label);
		contentPane.add(field);

		showButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AccessibleContext context;
				AccessibleRole role;

				context = field.getAccessibleContext();
				role = context.getAccessibleRole();

				System.out.print("Accessible Role: ");
				System.out.println(
							context.getAccessibleRole());

				System.out.print("Accessible Description: ");
				System.out.println(
							context.getAccessibleDescription());

				System.out.print("Accessible Name: ");
				System.out.println(
							context.getAccessibleName());
					
			}
		});

	}
}
