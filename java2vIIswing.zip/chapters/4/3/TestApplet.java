import java.applet.Applet;
import java.awt.*;

public class TestApplet extends Applet {
	public void init() {
		ImageCanvas imageCanvas = new ImageCanvas("sphere.gif");
		add(imageCanvas);
	}
}
class ImageCanvas extends Canvas {
	Image image;

	public ImageCanvas(String imageName) {
		image = Toolkit.getDefaultToolkit().getImage(imageName);

		MediaTracker mt = new MediaTracker(this);
		try {
			mt.addImage(image, 0);
			mt.waitForID(0);
		}
		catch(InterruptedException ex) {
			ex.printStackTrace();
		}
	}
	public void paint(Graphics g) {
		g.drawImage(image, 0, 0, null);
	}
	public Dimension getPreferredSize() {
		return new Dimension(image.getWidth(null),
							 image.getHeight(null));
	}
}
