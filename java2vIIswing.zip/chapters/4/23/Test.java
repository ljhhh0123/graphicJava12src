import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private JButton button_1 = new JButton("button one"),
				   button_2 = new JButton("button two"),
				   button_3 = new JButton("button three"),
				   button_4 = new JButton("button four"),
				   button_5 = new JButton("button five"),
				   button_6 = new JButton("button six");

	public void init() {
		Container contentPane = getContentPane();

		javax.swing.FocusManager.setCurrentManager(
								 new CustomFocusManager());

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button_1);
		contentPane.add(button_2);
		contentPane.add(button_3);
		contentPane.add(button_4);
		contentPane.add(button_5);
		contentPane.add(button_6);
	}
}
class CustomFocusManager extends DefaultFocusManager {
	public boolean compareTabOrder(Component a, Component b) {
		Point location_a = a.getLocation(),
			  location_b = b.getLocation();

		int ax = location_a.x, ay = location_a.y;
		int bx = location_b.x, by = location_b.y;

	 	if(Math.abs(ay - by) < 10) {
            return (bx < ax);
        }
        return (ay > by);	
	}
}
