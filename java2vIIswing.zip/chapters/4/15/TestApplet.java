import javax.swing.*;
import java.awt.*;

public class TestApplet extends JApplet {
	public void init() {
		String[] items = { 	"one", "two", "three", 
							"four", "five", "six" };

		Container contentPane = getContentPane();
		JList list = new JList(items);

		list.setVisibleRowCount(3);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(new JScrollPane(list));
	}
}
