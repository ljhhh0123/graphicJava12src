import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DoubleBufferingTest extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JCheckBox dbcheckBox = new JCheckBox("double buffered");
		JPanel controlPanel = new JPanel();
		final JSlider slider = 
						new JSlider(JSlider.HORIZONTAL,0,100,50);

		dbcheckBox.setSelected(true);
		controlPanel.add(dbcheckBox);

		slider.setPaintTicks(true);
		slider.setMinorTickSpacing(5);
		slider.setMajorTickSpacing(15);

		contentPane.add(controlPanel, "North");
		contentPane.add(slider, "Center");

		dbcheckBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent event) {
				RepaintManager rm =
					RepaintManager.currentManager(slider);

				if(event.getStateChange() == ItemEvent.SELECTED) {
					rm.setDoubleBufferingEnabled(true);
				}
				else {
					rm.setDoubleBufferingEnabled(false);
				}
			}
		});
	}
}
