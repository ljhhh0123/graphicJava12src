import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DoubleBufferingTest extends JApplet {
	public void init() {
		final JSlider slider = 
						new JSlider(JSlider.HORIZONTAL,0,100,50);

		final Container contentPane = getContentPane();
		JCheckBox dbcheckBox = new JCheckBox("double buffered");
		JPanel controlPanel = new JPanel();

		dbcheckBox.setSelected(true);
		controlPanel.add(dbcheckBox);

		slider.setPaintTicks(true);
		slider.setMinorTickSpacing(5);
		slider.setMajorTickSpacing(15);

		contentPane.add(controlPanel, "North");
		contentPane.add(slider, "Center");

		dbcheckBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent event) {

				if(event.getStateChange() == ItemEvent.SELECTED) {
					slider.setDoubleBuffered(true);
				}
				else {
					slider.setDoubleBuffered(false);
				}
			}
		});
	}
}
