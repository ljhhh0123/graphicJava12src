import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class DebugGraphicsTest extends JApplet {
	private JSlider slider = new JSlider();
	boolean logIsOn = false, flashIsOn = false;

	public void init() {
		Container 		cp = getContentPane();
		RepaintManager 	rm = 
						RepaintManager.currentManager(slider);

		rm.setDoubleBufferingEnabled(false);

		cp.setLayout(new BoxLayout(cp, BoxLayout.Y_AXIS));
		cp.add(slider);
		cp.add(makeControlPanel());

		slider.setEnabled(false);
	}
	private JPanel makeControlPanel() {
		JPanel 		controls 		= new JPanel(),
					checkBoxes 		= new JPanel();
		JCheckBox 	logCheckBox 	= new JCheckBox("Log"),
					flashCheckBox 	= new JCheckBox("Flash");
		JButton 	repaintButton 	= new JButton("repaint");

		final JSlider flashTimeSlider = 
						new JSlider(JSlider.HORIZONTAL,0,250,100);

		flashTimeSlider.setPaintTicks(true);
		flashTimeSlider.setMajorTickSpacing(10);
		flashTimeSlider.setMinorTickSpacing(5);

		controls.setLayout(new BoxLayout(controls, 
							BoxLayout.X_AXIS));
		checkBoxes.setLayout(new BoxLayout(checkBoxes, 
							BoxLayout.Y_AXIS));

		flashTimeSlider.setBorder(
			BorderFactory.createTitledBorder("Flash Time"));
		controls.setBorder(
			BorderFactory.createTitledBorder("Controls"));

		checkBoxes.add(logCheckBox);
		checkBoxes.add(flashCheckBox);

		controls.add(repaintButton);
		controls.add(flashTimeSlider);
		controls.add(checkBoxes);

		repaintButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int opts = 0;

				if(logIsOn) 	opts |= DebugGraphics.LOG_OPTION;
				if(flashIsOn)	opts |= DebugGraphics.FLASH_OPTION;

				slider.setDebugGraphicsOptions(opts);
				repaint();
			}
		});

		flashTimeSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				DebugGraphics.setFlashTime(
								flashTimeSlider.getValue());
			}
		});

		flashCheckBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				AbstractButton b = (AbstractButton)e.getSource();

				if(b.isSelected()) 	flashIsOn = true;
				else 				flashIsOn = false;
			}
		});
		logCheckBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				AbstractButton b = (AbstractButton)e.getSource();

				if(b.isSelected()) 	logIsOn = true;
				else				logIsOn = false;
			}
		});

		return controls;
	}
	public static void main(String args[]) {
		final JFrame f = new JFrame();
		JApplet applet = new DebugGraphicsTest();

		applet.init();
		f.setContentPane(applet.getContentPane());

		f.setBounds(100,100,300,175);
		f.setTitle("DebugGraphicsTest");
		f.setVisible(true);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent event) {
				f.dispose();
				System.exit(0);
			}
		});
	}
}
