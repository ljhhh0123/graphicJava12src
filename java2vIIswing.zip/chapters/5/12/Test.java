import java.awt.*;
import javax.swing.*;

public class Test extends JApplet {
	ImageIcon icon = new ImageIcon("coffeeCup.jpg");

	public void paint(Graphics g) {
		icon.paintIcon(this, g, 20, 15);
	}
}
