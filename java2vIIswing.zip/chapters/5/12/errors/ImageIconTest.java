import com.sun.java.swing.*;
import java.awt.*;

public class ImageIconTest extends JApplet {
	ImageIcon icon = new ImageIcon("coffeeCup.jpg");

	public void paint(Graphics g) {
		icon.paintIcon(this, g, 20, 15);

		System.out.println("w: " + icon.getIconWidth());
		System.out.println("h: " + icon.getIconHeight()); 
	}
}
