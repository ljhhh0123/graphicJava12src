import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();

		JPanel[] panels = { new JPanel(), 
							new JPanel(), new JPanel() };

		Border[] borders = { new HandleBorder(),
							new HandleBorder(Color.red, 8),
							new HandleBorder(Color.blue, 10) };

		contentPane.setLayout(
					new FlowLayout(FlowLayout.CENTER,20,20));

		for(int i=0; i < panels.length; ++i) {
			panels[i].setPreferredSize(new Dimension(100,100));
			panels[i].setBorder(borders[i]);
			contentPane.add(panels[i]);
		}
	}
}
