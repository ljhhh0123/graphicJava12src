import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;

public class Test extends JApplet
					implements PropertyChangeListener {
	JPanel jp = new JPanel();
	JPanel cp = new JPanel();  // cp = checkbox panel

	JCheckBox jc = new JCheckBox("action enabled");
	JMenuBar mb = new JMenuBar(); 
	JToolBar tb = new JToolBar();

	Action saveAction = new SaveAction();
	Action exitAction = new ExitAction();

	public void init() {
		JMenu fileMenu = new JMenu("File");

		fileMenu.add(saveAction);
		fileMenu.add(exitAction);
		tb.add(saveAction);

		JCheckBoxMenuItem checkBoxItem = 
						  new JCheckBoxMenuItem("saved");

		associateActionAndCheckBoxItem(saveAction, checkBoxItem);
		fileMenu.add(checkBoxItem);

		mb.add(fileMenu);

		saveAction.addPropertyChangeListener(this);

		jp.setLayout(new BorderLayout(2,2));
		jp.add(tb, "North");  // toolbar
		jp.add(cp, "Center"); // checkbox panel

		cp.setLayout(new FlowLayout());
		cp.add(jc);

		Container contentPane = getContentPane();

		contentPane.setLayout(new BorderLayout());
		getRootPane().setJMenuBar(mb);
		contentPane.add(jp, "Center");

		jc.setSelected(saveAction.isEnabled());

		jc.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent event) {
				saveAction.setEnabled(!saveAction.isEnabled());
			}
		});
	}
	public void propertyChange(PropertyChangeEvent e) {
		boolean b = ((Boolean)e.getNewValue()).booleanValue();
		showStatus("save action " + (b ? "enabled" : "disabled"));
	}
	private void associateActionAndCheckBoxItem(
								final Action action,
								final JCheckBoxMenuItem item) {
		item.setHorizontalTextPosition(JButton.LEFT);
		item.setVerticalTextPosition(JButton.CENTER);
		item.setEnabled(action.isEnabled());
		item.addActionListener(action);
		action.addPropertyChangeListener(
									new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent e) {
				String name = e.getPropertyName();

				if(name.equals(Action.NAME)) {
					item.setText((String)e.getNewValue());
					item.revalidate();
				}
				else if(name.equals("enabled")) {
					item.setEnabled(
						((Boolean)e.getNewValue()).booleanValue());
					item.repaint();
				}
				else if(name.equals(Action.SMALL_ICON)) {
					item.setIcon((Icon)e.getNewValue());
					item.revalidate();
				}
			}
		});
	}
}
class SaveAction extends AbstractAction {
	public SaveAction() {
		super("save", new ImageIcon("save.gif"));
		setEnabled(false);
	}
	public void actionPerformed(ActionEvent event) {
		String s = new String();
		Object o = event.getSource();

		if(o instanceof JButton) 		s += "ToolBar:  ";
		else if(o instanceof JMenuItem) s += "MenuBar:  ";

		System.out.println(s + " save");
	}
}
class ExitAction extends AbstractAction {
	public ExitAction() {
		super("exit");
	}
	public void actionPerformed(ActionEvent event) {
		System.exit(0);
	}
}
