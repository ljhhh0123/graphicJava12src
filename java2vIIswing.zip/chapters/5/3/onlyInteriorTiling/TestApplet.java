// Copyright 1998, Sabreware Inc.

import com.sun.java.swing.*;
import com.sun.java.swing.border.*;
import java.awt.*;

public class TestApplet extends JApplet {
	JPanel jpanel = new RainPanel();
	TitledBorder border = new TitledBorder("JPanel Border");

	public void init() {
		jpanel.setBorder(border);
		getContentPane().add(jpanel, BorderLayout.CENTER);

		System.out.println("opaque = " + border.isBorderOpaque());
		System.out.println(
				"insets = " + border.getBorderInsets(jpanel));
	}
}
class RainPanel extends JPanel {
	public void paintComponent(Graphics g) {
		Icon icon = new ImageIcon("rain.gif");
		Dimension size = getSize();
		Rectangle interior = AbstractBorder.getInteriorRectangle(
								this, getBorder(), 0, 0, size.width,
								size.height);

        int patchW = icon.getIconWidth(),
        	patchH = icon.getIconHeight();

        for(int r=interior.x; r < interior.width; r += patchW) {
            for(int c=interior.y; c < interior.height; c += patchH)
				icon.paintIcon(this, g, r, c);
        }
    }
}
