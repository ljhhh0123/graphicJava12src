import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class Test extends JApplet {
	JPanel panel = new RainPanel();
	TitledBorder border = new TitledBorder("JPanel Border");

	public void init() {
		panel.setBorder(border);
		getContentPane().add(panel, BorderLayout.CENTER);

		System.out.println("opaque = " + border.isBorderOpaque());
		System.out.println(
				"insets = " + border.getBorderInsets(panel));
	}
}
class RainPanel extends JPanel {
	public void paintComponent(Graphics g) {
		Icon icon = new ImageIcon("rain.gif");
		Dimension size = getSize();

        int patchW = icon.getIconWidth(),
        	patchH = icon.getIconHeight();

        for(int r=0; r < size.width; r += patchW) {
            for(int c=0; c < size.height; c += patchH)
				icon.paintIcon(this, g, r, c);
        }
    }
}
