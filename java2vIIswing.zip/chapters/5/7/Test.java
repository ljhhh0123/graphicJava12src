import java.awt.*;
import javax.swing.*;

public class Test extends JApplet {
	ColorIcon 	redIcon = new ColorIcon(Color.red, 50, 50),
				blueIcon = new ColorIcon(Color.blue, 60, 60),
				yellowIcon = new ColorIcon(Color.yellow, 70, 70);

	public void paint(Graphics g) {
		redIcon.paintIcon(this, g, 0, 0);

		blueIcon.paintIcon(this, g,
							redIcon.getIconWidth() + 10, 0);

		yellowIcon.paintIcon(this, g,
							redIcon.getIconWidth() + 10 +
							blueIcon.getIconWidth() + 10, 0);
	}
}
