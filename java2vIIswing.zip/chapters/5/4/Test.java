import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JPanel panel 	= new JPanel();
		JPanel panel2 	= new JPanel();

		Border border 	= BorderFactory.createRaisedBevelBorder();
		Border border2 	= BorderFactory.createRaisedBevelBorder();

		panel.setBorder(border);
		panel2.setBorder(border2);

		contentPane.add(panel, BorderLayout.NORTH);
		contentPane.add(panel2, BorderLayout.SOUTH);

		if(border == border2)
			System.out.println("bevel borders are shared");
		else
			System.out.println("bevel borders are NOT shared");
	}
}
