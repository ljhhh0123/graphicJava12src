import java.awt.BorderLayout;
import javax.swing.*;
import javax.swing.border.*;

public class Test extends JApplet {
	public void init() {
		JPanel panel = new JPanel();

		panel.setBorder(new TitledBorder("JPanel Border"));
		getContentPane().add(panel, BorderLayout.CENTER);
	}
}
