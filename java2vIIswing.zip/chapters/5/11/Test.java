import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private ColorIcon colorIcon = new ColorIcon(40, 15);
	private JPopupMenu popup = new JPopupMenu();
	private JButton button = new JButton("select a color ...", 
											colorIcon);
	public void init() {
		addPopupMenuItems();

		button.putClientProperty("fill color", Color.red);

		Container contentPane = getContentPane();
		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dimension buttonsz = button.getSize();
				popup.show(button,buttonsz.width,
									buttonsz.height);
			}
		});
	}
	private void addPopupMenuItems() {
		JMenuItem 	redItem = new JMenuItem(colorIcon),
					blueItem = new JMenuItem(colorIcon),
					grayItem = new JMenuItem(colorIcon),
					yellowItem = new JMenuItem(colorIcon),
					blackItem = new JMenuItem(colorIcon),
					whiteItem = new JMenuItem(colorIcon),
					orangeItem = new JMenuItem(colorIcon);

		MenuItemListener listener = new MenuItemListener();

		redItem.putClientProperty("fill color", Color.red);
		redItem.addActionListener(listener);
		popup.add(redItem);

		blueItem.putClientProperty("fill color", Color.blue);
		blueItem.addActionListener(listener);
		popup.add(blueItem);

		grayItem.putClientProperty("fill color", Color.gray);
		grayItem.addActionListener(listener);
		popup.add(grayItem);

		yellowItem.putClientProperty("fill color", Color.yellow);
		yellowItem.addActionListener(listener);
		popup.add(yellowItem);

		blackItem.putClientProperty("fill color", Color.black);
		blackItem.addActionListener(listener);
		popup.add(blackItem);

		whiteItem.putClientProperty("fill color", Color.white);
		whiteItem.addActionListener(listener);
		popup.add(whiteItem);

		orangeItem.putClientProperty("fill color", Color.orange);
		orangeItem.addActionListener(listener);
		popup.add(orangeItem);
	}
	class MenuItemListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JComponent jc = (JComponent)e.getSource();

			button.putClientProperty("fill color",
							jc.getClientProperty("fill color"));

			button.repaint();
		}
	}
}
