import java.awt.*;
import javax.swing.*;

public class ColorIcon implements Icon {
	private int w, h;

	public ColorIcon(int w, int h) {
		this.w = w;
		this.h = h;
	}
	public void paintIcon(Component c, Graphics g, int x, int y) {
		Color fillColor = Color.lightGray;

		g.setColor(Color.black);
		g.drawRect(x, y, w-1, h-1);

		if(c instanceof JComponent) {
			JComponent jc = (JComponent)c;
			fillColor = (Color)jc.getClientProperty("fill color");
		}
		g.setColor(fillColor);
		g.fillRect(x+1, y+1, w-2, h-2);
	}
	public int getIconWidth() {
		return w;
	}
	public int getIconHeight() {
		return h;
	}
}
