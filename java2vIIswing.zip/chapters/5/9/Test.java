import java.awt.*;
import javax.swing.*;

public class Test extends JApplet {
	ColorIcon 	redIcon = new ColorIcon(Color.red, 40, 15),
				blueIcon = new ColorIcon(Color.blue, 40, 15),
				yellowIcon = new ColorIcon(Color.yellow, 40, 15);

	public void init() {
		JMenuBar mb = new JMenuBar();
		JMenu colors = new JMenu("Colors");

		colors.add(new JMenuItem(redIcon));
		colors.add(new JMenuItem(blueIcon));
		colors.add(new JMenuItem(yellowIcon));

		mb.add(colors);
		setJMenuBar(mb);
	}
}
