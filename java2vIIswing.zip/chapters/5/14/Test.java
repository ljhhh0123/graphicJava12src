import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		JMenuBar mb = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		JMenuItem exitItem = new JMenuItem("exit");

		exitItem.addActionListener(new ExitListener());

		fileMenu.add(exitItem);
		mb.add(fileMenu);
		setJMenuBar(mb);
	}
}
class ExitListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		System.exit(0);
	}
}
