import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		JMenuBar mb = new JMenuBar();
		JMenu fileMenu = new JMenu("File");

		fileMenu.add(new ExitAction());
		mb.add(fileMenu);
		setJMenuBar(mb);
	}
}
class ExitAction extends AbstractAction {
	public ExitAction() {
		super("exit");
	}
	public void actionPerformed(ActionEvent e) {
		System.exit(0);
	}
}
