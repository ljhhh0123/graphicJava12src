import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		CustomAction action = new CustomAction();
		CustomButton button = new CustomButton(action);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);
	}
}
class CustomButton extends JButton {
	public CustomButton(Action action) {
		super((String)action.getValue(Action.NAME),
			  (Icon)action.getValue(Action.SMALL_ICON));

		String shortDescription = (String)action.getValue(
									Action.SHORT_DESCRIPTION);

		setToolTipText(shortDescription);
		addActionListener(action);
	}
}
class CustomAction extends AbstractAction {
	public CustomAction() {
		super("doit", new ImageIcon("skelly.gif"));
		putValue(Action.SHORT_DESCRIPTION, "a short description");
	}
	public void actionPerformed(ActionEvent e) {
		System.out.println("Custom action performed");
	}
}
