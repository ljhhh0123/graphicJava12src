import java.awt.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		JPanel panel = new MyJPanel();
		getContentPane().add(panel, "Center");
	}
}
class MyJPanel extends JPanel {
	ImageIcon animatedIcon = new ImageIcon("globe.gif");

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		animatedIcon.paintIcon(this, g, 20, 20);
	}
}
