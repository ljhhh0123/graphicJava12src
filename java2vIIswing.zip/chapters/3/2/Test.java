import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	public void init() {
		JSlider slider = new JSlider(0,100,50);

		getContentPane().add(slider, BorderLayout.CENTER);

		 slider.addChangeListener(new ChangeListener() {
		 	public void stateChanged(ChangeEvent e) {
				JSlider s = (JSlider)e.getSource();
				showStatus(Integer.toString(s.getValue()));
			}
		 });
	}
}
