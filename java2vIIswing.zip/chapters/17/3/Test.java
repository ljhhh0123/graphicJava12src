import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class Test extends JApplet {
	private String[] names = new String[] {
		"baseball player", "basketball player",
		"beach player", 	"chef",
		"hockey player",	"software developer",
		"construction worker", 	"martial artist",
		"soccer", 			"movie star"
	};
	private String[] pics = new String[] {
		"baseball.gif", "basketball.gif",
		"beach_umbrella.gif", "dining.gif",
		"hockey.gif", "mad_hacker.gif",
		"men_at_work.gif", 	"punch.gif",
		"soccer.gif", "filmstrip.gif" 
	};

	public void init() {
		Container contentPane = getContentPane();
		ListModel model = 
						 new NameAndPictureListModel(names, pics);

		ListCellRenderer renderer = 
						 new NameAndPictureListCellRenderer();

		JList list = new JList(model);

		list.setCellRenderer(renderer);
		list.setVisibleRowCount(5);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(new JScrollPane(list));
	}
}
class NameAndPictureListModel extends DefaultListModel {
	public NameAndPictureListModel(String[] names,String[] pics) {
		for(int i=0; i < names.length; ++i) {
			addElement(new Object[] { 
							names[i], new ImageIcon(pics[i]) } );
		}
	}
	public String getName(Object object) {
		Object[] array = (Object[])object;
		return (String)array[0];
	}
	public Icon getIcon(Object object) {
		Object[] array = (Object[])object;
		return (Icon)array[1];
	}
}
class NameAndPictureListCellRenderer extends JLabel 
								implements ListCellRenderer {
	private Border 
		lineBorder = BorderFactory.createLineBorder(Color.red, 2),
		emptyBorder = BorderFactory.createEmptyBorder(2,2,2,2);

	public NameAndPictureListCellRenderer() {
		setOpaque(true);
	}
	public Component getListCellRendererComponent(
									JList list,
									Object value,
									int index,
									boolean isSelected,
									boolean cellHasFocus) {
		NameAndPictureListModel model = 
						(NameAndPictureListModel)list.getModel();

		setText(model.getName(value));
		setIcon(model.getIcon(value));

		if(isSelected) {
			setForeground(list.getSelectionForeground());
			setBackground(list.getSelectionBackground());
		}
		else {
			setForeground(list.getForeground());
			setBackground(list.getBackground());
		}

		if(cellHasFocus) setBorder(lineBorder);
		else 			 setBorder(emptyBorder);

		return this;
	}
}
