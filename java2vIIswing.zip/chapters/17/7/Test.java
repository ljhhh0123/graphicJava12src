import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();

		String[] items = { "item one", "item two", "item three", 
						"item four", "item five", "item six",
						"item seven", "item eight", 
						"item nine", "item ten" };

		JList list = new JList(items);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(new JScrollPane(list));

		list.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				JList theList = (JList)e.getSource();
				ListModel model = theList.getModel();

				int index = theList.locationToIndex(e.getPoint());
				String itemString = 
								(String)model.getElementAt(index);

				String s = new String(" for " + 
							model.getElementAt(index));

				switch(e.getClickCount()) {
					case 1:
						showStatus("Single Click" + s);
						break;
					case 2:
						showStatus("Double Click" + s);
						break;
					case 3:
						showStatus("Triple Click" + s);
						break;
				}
			}
		});
	}
}
