import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		Object[] items = { "item one", "item two", "item three", 
						"item four", "item five", "item six",
						"item seven", "item eight", 
						"item nine", "item ten" };

		JList list = new JList(items);
		JScrollPane sp = new JScrollPane(list);

		list.setVisibleRowCount(7);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(sp);
	}
}
