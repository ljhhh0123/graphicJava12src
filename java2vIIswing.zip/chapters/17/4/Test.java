import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();

		String[] items = { "item[0]", "item[1]", "item[2]", 
						"item[3]", "item[4]", "item[5]",
						"item[6]", "item[7]", 
						"item[8]", "item[9]" };

		JList list = new JList(items);

		contentPane.add(new JScrollPane(list), 
						BorderLayout.CENTER);

		list.addListSelectionListener(
									new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				String s;

				if(e.getValueIsAdjusting()) {
					s = "adjusting selection ...";
				}
				else {
					s = "selection from " + e.getFirstIndex() + 
					 " to " + e.getLastIndex();
				}
				showStatus(s);
			}
		});
	}
}
