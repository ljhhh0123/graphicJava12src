import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	private JList list = new JList();

	private String[] items = { 
						"item one", "item two", "item three", 
						"item four", "item five", "item six",
						"item seven", "item eight", 
						"item nine", "item ten" 
	};

	public void init() {
		Container contentPane = getContentPane();

		JPanel controlPanel = new ControlPanel(this, list);

		contentPane.add(controlPanel, BorderLayout.NORTH);
		contentPane.add(new JScrollPane(list), 
											BorderLayout.CENTER);
		populateList();
	}
	public void populateList() {
		final DefaultListModel model = new DefaultListModel();

		for(int i=0; i < items.length; ++i)
			model.addElement(items[i]);

		list.setModel(model);

		if(list.isShowing())
			list.revalidate();

		model.addListDataListener(new ListDataListener() {
			public void contentsChanged(ListDataEvent e) {
				showStatus("contents changed");
			}
			public void intervalRemoved(ListDataEvent e) {
				Object[] message = new Object[] {
					"Removed item at index " + e.getIndex0(),
					" ",
					"There are now " + model.getSize() + " items"
				};
				JOptionPane.showMessageDialog(Test.this,
					message,
					"Items Removed", // title
					JOptionPane.INFORMATION_MESSAGE); // type
			}
			public void intervalAdded(ListDataEvent e) {
				showStatus("interval added");
			}
		});
	}
}
class ControlPanel extends JPanel {
	JButton remove = new JButton("remove selected items");
	JButton repopulate = new JButton("repopulate");

	public ControlPanel(final Test applet, final JList list) {
		add(remove);
		add(repopulate);

		remove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] selected = list.getSelectedIndices();
				DefaultListModel model =
							(DefaultListModel)list.getModel();

				for(int i=0; i < selected.length; ++i) {
					model.removeElementAt(selected[i] - i);
				}
			}
		});
		repopulate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				applet.populateList();
			}
		});
	}
}
