import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	private ControlPanel controlPanel;

	public void init() {
		Container contentPane = getContentPane();
		JPanel listPanel = new JPanel();

		String[] items = { "item[0]", "item[1]", "item[2]", 
						"item[3]", "item[4]", "item[5]",
						"item[6]", "item[7]", 
						"item[8]", "item[9]" };

		JList list = new JList(items);

		list.setPrototypeCellValue("MMMMMMM");

		controlPanel = new ControlPanel(list);
		controlPanel.update();

		listPanel.setBorder(BorderFactory.createEtchedBorder());
		listPanel.add(new JScrollPane(list));

		contentPane.add(controlPanel, BorderLayout.NORTH);
		contentPane.add(listPanel, BorderLayout.CENTER);

		list.addListSelectionListener(
									new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				controlPanel.update();
			}
		});
	}
}
class ControlPanel extends JPanel {
	private JComboBox mode = new JComboBox();
	private JButton clear = new JButton("clear selection");

	private String single = "SINGLE_SELECTION",
				singleInterval = "SINGLE_INTERVAL_SELECTION",
				multipleInterval = "MULTIPLE_INTERVAL_SELECTION";

	private JLabel  leadLabel = new JLabel(),
					anchorLabel = new JLabel(),
					minLabel = new JLabel(),
					maxLabel = new JLabel(),
					selIndicesLabel = new JLabel();

	private JList list;

	public ControlPanel(JList l) {
		JPanel top = new JPanel(), 
			   mid = new JPanel(),
			   bottom = new JPanel();

		this.list = l;

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); 
		setBorder(BorderFactory.createEtchedBorder());

		top.add(mode);
		top.add(clear);

		mid.add(new JLabel("Lead:")); 		mid.add(leadLabel);
		mid.add(new JLabel("Anchor:")); 	mid.add(anchorLabel);
		mid.add(new JLabel("Minimum:")); 	mid.add(minLabel);
		mid.add(new JLabel("Maximum:")); 	mid.add(maxLabel);

		add(top);
		add(mid);
		add(bottom);

		mode.addItem(single);
		mode.addItem(singleInterval);
		mode.addItem(multipleInterval);
		initializeSelectionMode();

		bottom.add(new JLabel("Selected Indices:"));
		bottom.add(selIndicesLabel);

		mode.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED)
					setSelectionMode((String)e.getItem());
			}
		});
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list.clearSelection();
			}
		});
	}
	public void update() {
		int lead = list.getLeadSelectionIndex(),
			min = list.getMinSelectionIndex(),
			max = list.getMaxSelectionIndex(),
			anchor = list.getAnchorSelectionIndex();

		leadLabel.setText(Integer.toString(lead) + " / ");
		anchorLabel.setText(Integer.toString(anchor) + " / ");
		minLabel.setText(Integer.toString(min) + " / ");
		maxLabel.setText(Integer.toString(max) + " / ");

		int[] selected = list.getSelectedIndices();
		String s = new String();

		for(int i = 0; i < selected.length; ++i) {
			s += Integer.toString(selected[i]);

			if(i < selected.length-1)
				s += ",";
		}
		selIndicesLabel.setText(s);
		validate();
	}
	private void initializeSelectionMode() {
		int m = list.getSelectionMode();

		switch(m) {
			case ListSelectionModel.SINGLE_SELECTION:
				mode.setSelectedItem(single);
				break;
			case ListSelectionModel.SINGLE_INTERVAL_SELECTION:
				mode.setSelectedItem(singleInterval);
				break;
			case ListSelectionModel.MULTIPLE_INTERVAL_SELECTION:
				mode.setSelectedItem(multipleInterval);
				break;
		}
	}
	private void setSelectionMode(String s) {
		if(s.equals("SINGLE_SELECTION")) {
			list.setSelectionMode(
				ListSelectionModel.SINGLE_SELECTION);
		}
		else if(s.equals("SINGLE_INTERVAL_SELECTION")) {
			list.setSelectionMode(
				ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		}
		else if(s.equals("MULTIPLE_INTERVAL_SELECTION")) {
			list.setSelectionMode(
				ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		}
	}
}
