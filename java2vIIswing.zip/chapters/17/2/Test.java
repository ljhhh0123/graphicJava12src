import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	private JList list = new JList();

	String[] items = { "item[0]", "item[1]", "item[2]", 
						"item[3]", "item[4]", "item[5]",
						"item[6]", "item[7]", 
						"item[8]", "item[9]" };

	public void init() {
		Container contentPane = getContentPane();
		JPanel controlPanel = new ControlPanel(list);

		contentPane.add(controlPanel, BorderLayout.NORTH);
		contentPane.add(new JScrollPane(list), 
											BorderLayout.CENTER);
		populateList();
	}
	public void populateList() {
		DefaultListModel model = new DefaultListModel();

		for(int i=0; i < items.length; ++i)
			model.addElement(items[i]);

		list.setModel(model);
	}
}
class ControlPanel extends JPanel {
	JButton remove = new JButton("remove selected items");
	JButton add = new JButton("add item");

	public ControlPanel(final JList list) {
		add(remove);
		add(add);

		remove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] selected = list.getSelectedIndices();
				DefaultListModel model =
							(DefaultListModel)list.getModel();

				for(int i=0; i < selected.length; ++i) {
					model.removeElementAt(selected[i] - i);
				}
			}
		});
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final DefaultListModel model = 
								(DefaultListModel)list.getModel();

				String s = JOptionPane.showInputDialog(
								list,
								"Enter item text:");

				model.addElement(s);

				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						list.ensureIndexIsVisible(
											model.getSize()-1);
					}
				});
			}
		});
	}
}
