import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JFrame {
	public Test() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(new JTable(10,10)); 
		contentPane.add(new JScrollPane(new JTable(10,10)));
	}
	public static void main(String args[]) {
		GraphicJavaWindowHandler.launch(new Test(),
					  "Tables and Scrollpanes",100,100,850,700);
	}
}
class GraphicJavaWindowHandler extends WindowAdapter {
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
