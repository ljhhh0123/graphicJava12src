import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.util.*;

public class Test extends JFrame {
	Object[] columnNames = {"Name", "Cost/Lb.", "Picture"};

	Object[][] rowData = {
		{ "cake", "$1.29", new ImageIcon("cake.gif") },
		{ "pear", "$1.29", new ImageIcon("pear.gif") },
		{ "pineapple", "$1.29", new ImageIcon("pineapple.gif") },
		{ "apple", "$1.29", new ImageIcon("apple.gif") },
		{ "bread", "$1.29", new ImageIcon("bread.gif") },
	};
	class RowSizingModel extends DefaultTableModel {
		public RowSizingModel(Object[][] data, 
							  Object[] colNames) {
			super(data, colNames);
		}
		public Class getColumnClass(int c) {
			if(c == 2) return ImageIcon.class;
			else 	   return super.getColumnClass(c);
		}
	}
	JTable table = new JTable(new RowSizingModel(rowData, 
												 columnNames));

	public Test() {
		table.setRowHeight(getMaxRowHeight());
		getContentPane().add(new JScrollPane(table), 
							 	 BorderLayout.CENTER);
	}
	public int getMaxRowHeight() {
		int columnCount = table.getColumnCount(), h=0, maxh=0;

		for(int i=0; i < columnCount; ++i) {
			TableColumn column = 
						table.getColumnModel().getColumn(i);

			h = getMaxRowHeightForColumn(column);
			maxh = Math.max(h,maxh);
		}
		return maxh;
	}
	public int getMaxRowHeightForColumn(TableColumn column) {
		int height = 0, maxh = 0, c = column.getModelIndex();

		for(int r=0; r < table.getRowCount(); ++r) {
			TableCellRenderer renderer = 
							table.getCellRenderer(r,c);	
			Component 
			  comp = renderer.getTableCellRendererComponent(
						  	table, table.getValueAt(r,c), 
						  	false, false, r, c);

			height = comp.getMaximumSize().height;
			maxh = height > maxh ? height : maxh;
		}
		return maxh;
	}
	public static void main(String args[]) {
		GJApp.launch(
			new Test(), "Sizing Rows", 300,300,450,300);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
