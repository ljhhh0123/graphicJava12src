import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JFrame {
	Object[] selectionModes = new Object[] {
		"SINGLE_SELECTION",
		"SINGLE_INTERVAL_SELECTION",
		"MULTIPLE_INTERVAL_SELECTION",
	};
	int[] selectionConstants = {
		ListSelectionModel.SINGLE_SELECTION,
		ListSelectionModel.SINGLE_INTERVAL_SELECTION,
		ListSelectionModel.MULTIPLE_INTERVAL_SELECTION,
	};

	JTable table = new JTable(10,10);

	public Test() {
		Container contentPane = getContentPane();
		contentPane.add(new ControlPanel(), BorderLayout.NORTH);
		contentPane.add(new JScrollPane(table), 
						BorderLayout.CENTER);

	}
	class ControlPanel extends JPanel {
		JComboBox combo = new JComboBox(selectionModes);

		public ControlPanel() {
			setBorder(BorderFactory.createTitledBorder(
											  "Selection Modes"));
			add(combo);
			initializeCombo();

			combo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int index = combo.getSelectedIndex();

					table.setSelectionMode(
									selectionConstants[index]);
				}
			});
		}	
		private void initializeCombo() {
			int mode = 
				table.getSelectionModel().getSelectionMode();

			if(mode == ListSelectionModel.SINGLE_SELECTION) { 
				combo.setSelectedIndex(0);
			}
			else if(mode == 
				ListSelectionModel.SINGLE_INTERVAL_SELECTION) {
				combo.setSelectedIndex(1);
			}
			else if(mode == 
				ListSelectionModel.MULTIPLE_INTERVAL_SELECTION) {
				combo.setSelectedIndex(2);
			}
		}
	}
	public static void main(String args[]) {
		GraphicJavaApplication.launch(
			new Test(),"JTable Selection Modes",300,300,450,300);
	}
}
class GraphicJavaApplication extends WindowAdapter {
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
