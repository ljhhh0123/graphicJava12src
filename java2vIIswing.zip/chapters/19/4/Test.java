import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;

public class Test extends JFrame {
	String[] columnNames = {
			"Name", "Check-In Date", "Check-Out Date", "Smoking",
			"Fax", "Laptop", "Room Rate", "Photo",
	};

	Date dayOne = (new GregorianCalendar(2000, 10, 5)).getTime();
	Date dayTwo = (new GregorianCalendar(2000, 10, 7)).getTime();

	Object[][] data = {
			{ "Andrews", dayOne, dayTwo,
			   new Boolean(true), new Boolean(true), 
			   new Boolean(true), new Double(79.99),
			   new ImageIcon("tenchi.jpg")},

			{ "Anthony", dayOne, dayTwo, 
			   new Boolean(false), new Boolean(false),  
			   new Boolean(false), new Double(69.99),
			   new ImageIcon("washu.jpg")},

			{ "Woodard", dayOne, dayTwo, 
			   new Boolean(true), new Boolean(false),  
			   new Boolean(false), new Double(99.99),
			   new ImageIcon("sasami.jpg")},

			{ "Thomas", dayOne, dayTwo, 
			   new Boolean(false), new Boolean(true),  
			   new Boolean(true), new Double(79.99),
			   new ImageIcon("aeka.jpg")},
	
			{ "Reed", dayOne, dayTwo, 
			   new Boolean(true), new Boolean(true), 
			   new Boolean(true), new Double(79.99),
			   new ImageIcon("tenchi.jpg")},

			{ "Crenshaw", dayOne, dayTwo, 
			   new Boolean(false), new Boolean(false),  
			   new Boolean(false), new Double(69.99),
			   new ImageIcon("washu.jpg")},

			{ "Royal", dayOne, dayTwo, 
			   new Boolean(true), new Boolean(false),  
			   new Boolean(false), new Double(99.99),
			   new ImageIcon("sasami.jpg")},

			{ "Moore", dayOne, dayTwo, 
			   new Boolean(false), new Boolean(true),  
			   new Boolean(true), new Double(79.99),
			   new ImageIcon("aeka.jpg")},
			};
	
	JTable table = new JTable(new CustomModel(data, columnNames));
	public Test() {
		getContentPane().add(new JScrollPane(table),
							 BorderLayout.CENTER);
	}
	public static void main(String args[]) {
		GJApp.launch(
			new Test(), 
			"A Custom Table Model That Specifies Column Classes",
			300,300,650,182);
	}
}
class CustomModel extends DefaultTableModel {
	public CustomModel(Object[][] data, Object[] columnNames) {
		super(data, columnNames);
	}
	public Class getColumnClass(int col) {
		// dataVector is a protected member of DefaultTableModel
		
		Vector v = (Vector)dataVector.elementAt(0);
		return v.elementAt(col).getClass();
	}
	public boolean isCellEditable(int row, int col) {
		Class columnClass = getColumnClass(col);
		return columnClass != ImageIcon.class && 
								  columnClass != Date.class;
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
