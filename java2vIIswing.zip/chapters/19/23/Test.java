import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JFrame {
	JTable table = new JTable(10,10);

	public Test() {
		Container contentPane = getContentPane();

		contentPane.add(new JScrollPane(table),
						BorderLayout.CENTER);

		table.getModel().addTableModelListener(
								new TableModelListener() {
			public void tableChanged(TableModelEvent e) {
				int firstRow = e.getFirstRow(),
					column = e.getColumn();

				String properties = " source=" + e.getSource() +  
            		" firstRow= " + 
						(firstRow == TableModelEvent.HEADER_ROW ?
									"HEADER_ROW" : 
									Integer.toString(firstRow)) +

            		" lastRow= " + e.getLastRow() + 

            		" column= " + 
					  (firstRow == TableModelEvent.ALL_COLUMNS ?
									"ALL_COLUMNS" : 
									Integer.toString(column));

				String typeString = new String();
				int type = e.getType();

				switch(type) {
					case TableModelEvent.DELETE:
						 typeString = "DELETE"; break;
					case TableModelEvent.INSERT:
						 typeString = "INSERT"; break;
					case TableModelEvent.UPDATE:
						 typeString = "UPDATE"; break;
				}
				properties += " type=" + typeString;

   				JOptionPane.showMessageDialog(Test.this, 
				 			e.getClass().getName() + 
							"[" + properties + "]");
			}
		});
	}
	public static void main(String args[]) {
		GraphicJavaApplication.launch(new Test(),
				"Handling Table Model Events",300,300,450,220);
	}
}
class GraphicJavaApplication extends WindowAdapter {
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
