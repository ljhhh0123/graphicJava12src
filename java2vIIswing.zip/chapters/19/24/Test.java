import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	JTable table = new JTable(
		new AbstractTableModel() {
			int rows = 10, cols = 10;

			public int getRowCount() { return rows; }
			public int getColumnCount() { return cols; }

			public Object getValueAt(int row, int col) {
				return "(" + Integer.toString(row) + "," +
							 Integer.toString(col) + ")";
			}
		}
	);	

	public void init() {
		Container contentPane = getContentPane();

		contentPane.add(new JScrollPane(table),
						BorderLayout.CENTER);

		table.getColumnModel().addColumnModelListener(
								new TableColumnModelListener() {
			public void columnAdded(TableColumnModelEvent e) { }
			public void columnMarginChanged(ChangeEvent e) { }
			public void columnRemoved(TableColumnModelEvent e) { }
			public void columnSelectionChanged(
										ListSelectionEvent e) { }

			public void columnMoved(TableColumnModelEvent e) { 
				String s = "Column Moved From " + 
							e.getFromIndex() + " To " +
							e.getToIndex();

				showStatus(s);
			}
		});
	}
}
