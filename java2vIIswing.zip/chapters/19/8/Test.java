import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JFrame {
	JTable table = new JTable(
		new Object[][] {
			{"Mouse", "Mighty", "M." },
			{"Mouse", "Polly", "A." },
			{"Doright", "Dudley", "L." }
		},
		new Object[] {
			"Last Name", "First Name", "Middle Initial" 
		}
	);
	public Test() {
		Container cp = getContentPane();

		cp.add(new JScrollPane(table), BorderLayout.CENTER);
		cp.add(new ControlPanel(), BorderLayout.NORTH);
	}
	class ControlPanel extends JPanel {
		private JCheckBox checkBox = new JCheckBox(
								 "First Name Column Showing");
		public ControlPanel() {
			final TableColumnModel tcm = table.getColumnModel();
			final TableColumn firstNameColumn = 
									table.getColumn("First Name");

			checkBox.setSelected(true);
			add(checkBox);

			checkBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent event) {
					if(checkBox.isSelected()) {
						tcm.addColumn(firstNameColumn);
						tcm.moveColumn(2,1);
					}
					else {
						tcm.removeColumn(firstNameColumn);
					}
					table.sizeColumnsToFit(-1);
				}
			});
		}
	}
	public static void main(String args[]) {
		GJApp.launch(
			new Test(), "Showing/Hiding Columns",300,300,450,175);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
