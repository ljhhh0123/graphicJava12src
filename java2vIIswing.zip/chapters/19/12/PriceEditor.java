import javax.swing.*;
import java.util.EventObject;

class PriceEditor extends DefaultCellEditor {
	public PriceEditor(JComboBox combo) {
		super(combo);
	}
	public boolean isCellEditable(EventObject e) {
		JPanel messagePanel = new JPanel();
		JPasswordField pwf = new JPasswordField(10);

System.out.println(e);
		messagePanel.add(new JLabel("Password:"));
		messagePanel.add(pwf);

		JOptionPane.showMessageDialog(null, 
					messagePanel, "Password Required",
					JOptionPane.INFORMATION_MESSAGE);

		if(pwf.getText().equals("dolby")) {
			return true;
		}
		else {
			JOptionPane.showMessageDialog(null, 
				"Wrong Password!", "Access Failed", 
				JOptionPane.INFORMATION_MESSAGE);
			return false;
		}
	}
}
