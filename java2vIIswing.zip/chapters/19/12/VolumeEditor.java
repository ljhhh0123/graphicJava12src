import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.EventObject;

class VolumeEditor extends AbstractCellEditor {
	VolumeRenderer renderer = new VolumeRenderer();

	public VolumeEditor() {
		renderer.getLabel().addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(e.getClickCount() == 2)
					cancelCellEditing();	
			}
		});
	}
	public Component getTableCellEditorComponent(
								JTable table, Object value,
								boolean isSelected,
								int row, int column) {
		JSlider slider = renderer.getSlider();
		slider.setValue(((Integer)value).intValue());
		return renderer;
	}
	public boolean stopCellEditing() {
		JSlider slider = renderer.getSlider();

		setCellEditorValue(new Integer(slider.getValue()));

		return super.stopCellEditing();
	}
}
