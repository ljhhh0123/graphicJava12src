import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

class BulbRenderer extends DefaultTableCellRenderer {
	private ImageIcon darkBulb = new ImageIcon("button.jpg"),
			         brightBulb = new ImageIcon("button_lit.jpg");

	public BulbRenderer() {
		setHorizontalAlignment(JLabel.CENTER);
	}
	public Component getTableCellRendererComponent(
								JTable table, Object value,
								boolean isSelected,
								boolean hasFocus,
								int row, int col) {
		Boolean b = (Boolean)value;
		setIcon(b.booleanValue() ? brightBulb : darkBulb);
		return this;
	}
}
