import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

class TableCellVolumeRenderer extends JPanel
 				 		  implements TableCellRenderer {
	private JSlider slider = new JSlider();
	private JLabel label = new JLabel("value");

	public TableCellVolumeRenderer() {
		slider.setOrientation(SwingConstants.HORIZONTAL);
		slider.setPreferredSize(new Dimension(200,30));
		slider.putClientProperty("JSlider.isFilled",Boolean.TRUE);

		label.setHorizontalAlignment(JLabel.CENTER);
		label.setHorizontalTextPosition(JLabel.CENTER);

		setLayout(new BorderLayout());
		add(label, BorderLayout.NORTH);
		add(slider, BorderLayout.CENTER);

		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				label.setText(
							Integer.toString(slider.getValue()));
			}
		});
	}
	public Component getTableCellRendererComponent(
								JTable table, Object value,
								boolean isSelected,
								boolean hasFocus,
								int row, int col) {
		Integer v = (Integer)value;

		slider.setValue(v.intValue());
		label.setText(v.toString());

		slider.setEnabled(isSelected);
		label.setEnabled(isSelected);

		return this;
	}
	public JSlider getSlider() {
		return slider;
	}
	public JLabel getLabel() {
		return label;
	}
}
