import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

public class Test extends JFrame {
	JTable table = new JTable(new StereoDeckModel());

	public Test() {
		initializeInUseColumn();
		initializePriceColumn();
		initializeVolumeColumn();
		sizeColumns();

		TableColumnModel tcm = table.getColumnModel();
		TableCellEditor ce;

		table.setSelectionMode(
						ListSelectionModel.SINGLE_SELECTION);

		table.getSelectionModel().addListSelectionListener(
									new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				StereoDeckModel model = 
							(StereoDeckModel)table.getModel();	

				if(!e.getValueIsAdjusting()) {
					model.updateBulbs(table.getSelectedRow());
					table.repaint();
				}
			}
		});
		/*
		for(int col=0; col < tcm.getColumnCount(); ++col) {
			TableCellEditor editor = table.getCellEditor(0,col);
			TableColumn column = tcm.getColumn(col);

			column.setCellEditor(
						new NoSelectionEditorDecorator(editor));
		}
*/
		getContentPane().add(new JScrollPane(table),
							 BorderLayout.CENTER);
	}
	private void initializeInUseColumn() {
		TableColumn inUseColumn = table.getColumn("In Use");
		
		inUseColumn.setCellRenderer(new TableCellBulbRenderer());
		inUseColumn.setCellEditor(new TableCellBulbEditor());
	}
	private void initializePriceColumn() {
		TableColumn priceColumn = table.getColumn("Price");
		JComboBox combo = new JComboBox();

		// Combo box items are Numbers ...
		combo.addItem(new Double(159.99));
		combo.addItem(new Double(169.99));
		combo.addItem(new Double(229.99));
		combo.addItem(new Double(449.99));
		combo.addItem(new Double(699.99));

		combo.setRenderer(new ListCellCurrencyRenderer());

		priceColumn.setCellRenderer(
								new TableCellCurrencyRenderer());

		priceColumn.setCellEditor(new PriceCellEditor(combo));
	}
	private void initializeVolumeColumn() {
		TableColumn volumeColumn = table.getColumn("Volume");

		TableCellRenderer renderer = 
						  new TableCellVolumeRenderer();

		TableCellEditor editor = 
						new TableCellVolumeEditor(renderer);

		volumeColumn.setCellRenderer(renderer);
		volumeColumn.setCellEditor(editor);

		Dimension ps = ((JComponent)renderer).getPreferredSize();
		table.setRowHeight(ps.height);
	}
	public static void main(String args[]) {
		final JFrame f = new Test();

		f.setBounds(300,300,559,368);
		f.setTitle("Car Stereo Deck");
		f.setVisible(true);

		f.setDefaultCloseOperation(
			WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	private void sizeColumns() {
		TableColumnModel tcm = table.getColumnModel();

		for(int i=0; i < tcm.getColumnCount(); ++i) {
			TableColumn column = tcm.getColumn(i);
			int w = getPreferredWidthForColumn(column);

			column.setMinWidth(w);
			column.setMaxWidth(w);
		}
	}
	public int getPreferredWidthForColumn(TableColumn col) {
		int hw = columnHeaderWidth(col),   // hw = header width
			cw = widestCellInColumn(col);  // cw = column width

		return hw > cw ? hw+10 : cw+10;
	}
	private int columnHeaderWidth(TableColumn col) {
		TableCellRenderer renderer = col.getHeaderRenderer();

		Component comp = renderer.getTableCellRendererComponent(
						  			table, col.getHeaderValue(), 
						  			false, false, 0, 0);

		return comp.getPreferredSize().width;
	}
	private int widestCellInColumn(TableColumn col) {
		int c = col.getModelIndex(), width=0, maxw=0;

		for(int r=0; r < table.getRowCount(); ++r) {
			TableCellRenderer renderer = 
							  table.getCellRenderer(r,c);

			Component comp = 
				renderer.getTableCellRendererComponent(
						  			table, table.getValueAt(r,c), 
						  			false, false, r, c);

			width = comp.getPreferredSize().width;
			maxw = width > maxw ? width : maxw;
		}
		return maxw;
	}
}
class NoSelectionEditorDecorator implements TableCellEditor {
	private TableCellEditor realThing;

	public NoSelectionEditorDecorator(TableCellEditor realThing) {
		this.realThing = realThing;
	}
	public Component getTableCellEditorComponent(
								JTable table, Object value,
								boolean isSelected,
								int row, int column) {
		return realThing.getTableCellEditorComponent(table,
					value, isSelected, row, column);
	}
	public boolean stopCellEditing() {
		return realThing.stopCellEditing();
	}
	public void cancelCellEditing() {
		realThing.cancelCellEditing();
	}
	public void addCellEditorListener(CellEditorListener l) {
		realThing.addCellEditorListener(l);
	}
	public void removeCellEditorListener(CellEditorListener l) {
		realThing.removeCellEditorListener(l);
	}
	public boolean isCellEditable(EventObject e) {
		return realThing.isCellEditable(e);
	}
	public boolean shouldSelectCell(EventObject e) {
		return false;
	}
	public Object getCellEditorValue() {
		return realThing.getCellEditorValue();
	}
}
class ListCellCurrencyRenderer extends DefaultListCellRenderer {
	public Component getListCellRendererComponent(
									JList list,
									Object value,
									int index,
									boolean isSelected,
									boolean hasFocus) {
		JLabel c = (JLabel)
					super.getListCellRendererComponent(
									list, value, index,
									isSelected, hasFocus);

		Format format = NumberFormat.getCurrencyInstance();
		c.setText(value == null ? "" : format.format(value));
		return c;
	}
}
class TableCellCurrencyRenderer extends DefaultTableCellRenderer {
	public void setValue(Object value) {
		Format format = NumberFormat.getCurrencyInstance();
		setText(value == null ? "" : format.format(value));
	}
}
