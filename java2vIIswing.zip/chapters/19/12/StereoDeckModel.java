import javax.swing.*;
import javax.swing.table.*;

class StereoDeckModel extends AbstractTableModel {
	String[] columnNames = {
		"In Use", "Manufacturer", "Model", "Price", "Dolby",
		"Bass", "Volume"
	};
	Object[][] data = {
			{ Boolean.FALSE, "Sony", "1501A", 
			  new Double(129.99), Boolean.TRUE,
			  Boolean.TRUE, new Integer(50) }, 

			{ Boolean.FALSE, "Phillips", "86A4", 
			  new Double(159.99), Boolean.TRUE,
			  Boolean.FALSE, new Integer(35) }, 

			{ Boolean.TRUE, "Kenwood", "33-801-A", 
			  new Double(199.99), Boolean.FALSE,
			  Boolean.TRUE, new Integer(77) }, 

			{ Boolean.FALSE, "Blaupunkt", "7622A", 
			  new Double(229.99), Boolean.TRUE,
			  Boolean.FALSE, new Integer(19) }, 

			{ Boolean.FALSE, "Akai", "9733", 
			  new Double(259.99), Boolean.TRUE,
			  Boolean.FALSE, new Integer(68) }, 

			{ Boolean.FALSE, "Sony", "1520B", 
			  new Double(349.99), Boolean.FALSE,
			  Boolean.FALSE, new Integer(94) }, 

			{ Boolean.FALSE, "Kenwood", "2289B", 
			  new Double(499.99), Boolean.FALSE,
			  Boolean.FALSE, new Integer(44) }, 
	};
	public Object getValueAt(int row, int col) {
		return data[row][col];
	}
	public int getRowCount() { 
		return data.length; 
	}
	public int getColumnCount() { 
		return columnNames.length;
	}
	public String getColumnName(int col) {
		return columnNames[col];
	}
	public Class getColumnClass(int col) {
		return data[0][col].getClass();
	}
	public void setValueAt(Object value, int row, int col) {
		data[row][col] = value;
		fireTableCellUpdated(row, col);
	}
	public boolean isCellEditable(int row, int col) {
		Class cls = getColumnClass(col);
		String name = getColumnName(col);

		return (cls == Boolean.class && !name.equals("Dolby")) ||
				cls == Integer.class || cls == Double.class;
	}
	public void updateBulbs(int selectedRow) {
		for(int r=0; r < getRowCount(); ++r) {
			data[r][0] = new Boolean(r == selectedRow);
		}
	}
}
