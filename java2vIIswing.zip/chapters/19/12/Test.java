import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

public class Test extends JFrame {
	JTable table = new JTable(new StereoDeckModel());

	public Test() {
		initializeInUseColumn();
		initializePriceColumn();
		initializeVolumeColumn();
		sizeColumns();

		table.setSelectionMode(
						ListSelectionModel.SINGLE_SELECTION);

		table.getSelectionModel().addListSelectionListener(
									new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				StereoDeckModel model = 
							(StereoDeckModel)table.getModel();	

				if(!e.getValueIsAdjusting()) {
					model.updateBulbs(table.getSelectedRow());
				}
			}
		});
		getContentPane().add(new JScrollPane(table),
							 BorderLayout.CENTER);
	}
	private void initializeInUseColumn() {
		TableColumn inUseColumn = table.getColumn("In Use");
		
		inUseColumn.setCellRenderer(new BulbRenderer());
		inUseColumn.setCellEditor(new BulbEditor());
	}
	private void initializePriceColumn() {
		TableColumn priceColumn = table.getColumn("Price");
		JComboBox combo = new JComboBox();

		// Combo box items are Numbers ...
		combo.addItem(new Double(159.99));
		combo.addItem(new Double(169.99));
		combo.addItem(new Double(229.99));
		combo.addItem(new Double(449.99));
		combo.addItem(new Double(699.99));

		combo.setRenderer(new ListCellCurrencyRenderer());

		priceColumn.setCellRenderer(
								new TableCellCurrencyRenderer());

		priceColumn.setCellEditor(new PriceEditor(combo));
	}
	private void initializeVolumeColumn() {
		TableColumn volumeColumn = table.getColumn("Volume");
		TableCellRenderer renderer = new VolumeRenderer();
		TableCellEditor editor = new VolumeEditor();

		volumeColumn.setCellRenderer(renderer);
		volumeColumn.setCellEditor(editor);

		Dimension ps = ((JPanel)renderer).getPreferredSize();
		table.setRowHeight(ps.height);
	}
	public static void main(String args[]) {
		GraphicJavaApplication.launch(
			new Test(), "Car Stereo Deck", 300,300,559,368);
	}
	private void sizeColumns() {
		TableColumnModel tcm = table.getColumnModel();

		for(int i=0; i < tcm.getColumnCount(); ++i) {
			TableColumn column = tcm.getColumn(i);
			int w = getPreferredWidthForColumn(column);

			column.setMinWidth(w);
			column.setMaxWidth(w);
		}
	}
	public int getPreferredWidthForColumn(TableColumn col) {
		int hw = columnHeaderWidth(col),   // hw = header width
			cw = widestCellInColumn(col);  // cw = column width

		return hw > cw ? hw+10 : cw+10;
	}
	private int columnHeaderWidth(TableColumn col) {
		TableCellRenderer renderer = col.getHeaderRenderer();

		Component comp = renderer.getTableCellRendererComponent(
						  			table, col.getHeaderValue(), 
						  			false, false, 0, 0);

		return comp.getPreferredSize().width;
	}
	private int widestCellInColumn(TableColumn col) {
		int c = col.getModelIndex(), width=0, maxw=0;

		for(int r=0; r < table.getRowCount(); ++r) {
			TableCellRenderer renderer = 
							  table.getCellRenderer(r,c);

			Component comp = 
				renderer.getTableCellRendererComponent(
						  			table, table.getValueAt(r,c), 
						  			false, false, r, c);

			width = comp.getPreferredSize().width;
			maxw = width > maxw ? width : maxw;
		}
		return maxw;
	}
}
class ListCellCurrencyRenderer extends DefaultListCellRenderer {
	public Component getListCellRendererComponent(
									JList list,
									Object value,
									int index,
									boolean isSelected,
									boolean hasFocus) {
		JLabel c = (JLabel)
					super.getListCellRendererComponent(
									list, value, index,
									isSelected, hasFocus);

		Format format = NumberFormat.getCurrencyInstance();
		c.setText(value == null ? "" : format.format(value));
		return c;
	}
}
class TableCellCurrencyRenderer extends DefaultTableCellRenderer {
	public void setValue(Object value) {
		Format format = NumberFormat.getCurrencyInstance();
		super.setValue(value == null ? "" : format.format(value));
	}
}
class GraphicJavaApplication extends WindowAdapter {
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
