import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

class BulbEditor extends AbstractCellEditor {
	BulbRenderer renderer = new BulbRenderer();

	public BulbEditor() {
		renderer.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						setCellEditorValue(Boolean.TRUE);
						fireEditingStopped();
					}
				});
			}
		});
	}
	public Component getTableCellEditorComponent(
									JTable table, Object value,
									boolean isSelected,
									int row, int col) {
		return renderer.getTableCellRendererComponent(
							  table, value, true, true,
							  row, col);
	}
}	
