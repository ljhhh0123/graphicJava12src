import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;

public class Test extends JFrame {
	private int rows=3, cols=5;
	private Object[] rowData = new Object[cols];

	private DefaultTableModel model = new DefaultTableModel();
	private JTable table = new JTable(model);

	public Test() {
		for(int c=0; c < cols; ++c)
			model.addColumn("Column " + Integer.toString(c));

		for(int r=0; r < rows; ++r) {
			for(int c=0; c < cols; ++c) {
				rowData[c] = "(" + r + "," + c + ")";
			}
			model.addRow(rowData);
		}
		getContentPane().add(new JScrollPane(table),
							 BorderLayout.CENTER);
		getContentPane().add(new ControlPanel(),
							 BorderLayout.NORTH);
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(),
			"Using DefaultTableModel",150,150,600,350); 
	}
	class ControlPanel extends JPanel {
		private JButton rowButton = new JButton("Add Row"),
			    		colButton = new JButton("Add Column");

		public ControlPanel() {
			add(rowButton);
			add(colButton);

			rowButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int rowCount = model.getRowCount();
					int colCount = model.getColumnCount();

					if(colCount > rowData.length)
						rowData = new Object[colCount];

					for(int c=0; c < colCount; ++c) {
						rowData[c] = "(" + rowCount + "," + 
									       c + ")";
					}
					model.addRow(rowData);
				}
			});
			colButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int colCount = model.getColumnCount();
					model.addColumn("Column " + colCount);

					// Bug: the call to sizeColumnsToFit() 
					// should not be necessary
					table.sizeColumnsToFit(-1);
				}
			});
		}
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
