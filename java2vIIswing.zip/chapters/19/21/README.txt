This example is slightly different from what appears in the text. A general TableModelDecorator class is implemented for other types of decorators.
