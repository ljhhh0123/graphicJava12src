import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

public class Test extends JFrame {
	JTable table = new JTable(new Object[][] {
				{"apple", "$.39"}, 		{"mango", "$.49"},
				{"papaya", "$1.19"}, 	{"lemon", "$.19"},
				{"orange", "$.59"}, 	{"watermelon", "$.39"},
				{"tangerine", "$1.09"}, {"cherry", "$.79"},
				{"banana", "$.29"}, 	{"lime", "$.33"},
				{"grapefruit", "$.69"}, {"grapes", "$.49"},
			},
			new Object[] { "Item", "Price/Lb." });	
		
	public Test() {
		final SortDecorator decorator = 
							  new SortDecorator(table.getModel());

		table.setModel(decorator);

		JTableHeader hdr = (JTableHeader)table.getTableHeader();

		hdr.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				TableColumnModel tcm = table.getColumnModel();
				int vc = tcm.getColumnIndexAtX(e.getX());
				int mc = table.convertColumnIndexToModel(vc);

				decorator.sort(mc);
				//table.repaint();
			}
		});
		getContentPane().add(new JScrollPane(table),
							 				BorderLayout.CENTER);
	}
	public static void main(String args[]) {
		GJApp.launch(
			new Test(),"A Sort Decorator",300,300,450,250);
	}
}
class SortDecorator implements TableModel, TableModelListener {
	private  TableModel realModel;
	private int indexes[];

	public SortDecorator(TableModel model) {
		if(model == null)
			throw new IllegalArgumentException(
								"null models are not allowed");
		this.realModel = model;	

		realModel.addTableModelListener(this);
		allocate();
	}
	public Object getValueAt(int row, int column) {
		return realModel.getValueAt(indexes[row], column);
	}
	public void setValueAt(Object aValue, int row, int column) {
		realModel.setValueAt(aValue, indexes[row], column);
	}
	public void tableChanged(TableModelEvent e) {
		allocate();
	}
	public void sort(int column) {
		int rowCount = getRowCount();

		for(int i=0; i < rowCount; i++) {
			for(int j = i+1; j < rowCount; j++) {
				if(compare(indexes[i], indexes[j], column) < 0) {
					swap(i,j);
				}
			}
		}
	}
    public void swap(int i, int j) {
		int tmp = indexes[i];
		indexes[i] = indexes[j];
		indexes[j] = tmp;
	}
	public int compare(int i, int j, int column) {
		Object io = realModel.getValueAt(i,column);
		Object jo = realModel.getValueAt(j,column);

		int c = jo.toString().compareTo(io.toString());
		return (c < 0) ? -1 : ((c > 0) ? 1 : 0);
	}
	private void allocate() {
		indexes = new int[getRowCount()];

		for(int i=0; i < indexes.length; ++i) {
			indexes[i] = i;			
		}
	}

	// TableModel pass-through methods follow ...

	public int getRowCount() {
		return realModel.getRowCount();	
	}
	public int getColumnCount() {
		return realModel.getColumnCount();	
	}
	public String getColumnName(int columnIndex) {
		return realModel.getColumnName(columnIndex);
	}
	public Class getColumnClass(int columnIndex) {
		return realModel.getColumnClass(columnIndex);
	}
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return realModel.isCellEditable(rowIndex, columnIndex);
	}
	public void addTableModelListener(TableModelListener l) {
		realModel.addTableModelListener(l);
	}
	public void removeTableModelListener(TableModelListener l) {
		realModel.removeTableModelListener(l);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
