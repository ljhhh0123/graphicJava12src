import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;

public class Test extends JFrame {
	JTable table = new JTable(
		new AbstractTableModel() {
			int rows = 100, cols = 10;

			public int getRowCount() { return rows; }
			public int getColumnCount() { return cols; }

			public Object getValueAt(int row, int col) {
				return "(" + Integer.toString(row) + "," +
						 	 Integer.toString(col) + ")";
			}
		});

	public Test() {
		TableColumn column;
		int columnCount = table.getColumnCount();

		for(int i=0; i < columnCount; ++i) {
			column = table.getColumn(table.getColumnName(i));

			if(i % 2 == 0)
				column.setCellRenderer(new RowRenderer());
		}
		getContentPane().add(new JScrollPane(table),
							 BorderLayout.CENTER);
	}
	public static void main(String args[]) {
		GraphicJavaApplication.launch(
			new Test(), "Rendering By Columns and Rows",
						 300,300,450,300); 
	}
}
class RowRenderer extends DefaultTableCellRenderer {
	public Component getTableCellRendererComponent(JTable table,
								Object value, boolean isSelected,
								boolean hasFocus,
								int row, int column) {
		if(row % 2 == 0) setForeground(Color.blue);
		else 			 setForeground(Color.orange);

		return super.getTableCellRendererComponent(table,
								value, isSelected, hasFocus,
								row, column);
	}
}
class GraphicJavaApplication extends WindowAdapter {
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
