import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JFrame {
	String longTitle = "Last Name / Maiden Name (if divorced)";
	MultilineHeaderRenderer multilineRenderer = 
						new MultilineHeaderRenderer(longTitle);

	JTable table = new JTable(
		new Object[][] {
			{ "Lynn", "M.", "Seckinger" },
			{ "Carol", "R.", "Seckinger" },
			{ "Roy", "D.", "Martin" },
			{ "Richard", "A.", "Tattersall" },
			{ "Philip", "B.", "Edwards" },
			{ "Moore", "T.", "Moore" },

			// shorten scrollbar grip with these ...

			{ "Lynn", "M.", "Seckinger" },
			{ "Carol", "R.", "Seckinger" },
			{ "Roy", "D.", "Martin" },
			{ "Richard", "A.", "Tattersall" },
			{ "Philip", "B.", "Edwards" },
			{ "Moore", "T.", "Moore" },
		},
		new Object[] {"First Name", "MI", longTitle});

	public Test() {
		TableColumn middleColumn = table.getColumn("MI"),
					lastColumn = table.getColumn(longTitle);

		lastColumn.setHeaderRenderer(multilineRenderer);

		TableCellRenderer hdrRenderer = 
								middleColumn.getHeaderRenderer();

		Component hdrComponent = 
			hdrRenderer.getTableCellRendererComponent(table, 
						"MI", false, false, 0, 0);

		if(hdrComponent instanceof JComponent) {
			JComponent c = (JComponent)hdrComponent;
			c.setToolTipText("Middle Initial");
		}

		table.getTableHeader().setToolTipText("Table Header!");

		getContentPane().add(
				     new JScrollPane(table), BorderLayout.CENTER);
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
			"Multi-Line Column Headers",300,300,300,250);
	}
}
class MultilineHeaderRenderer implements TableCellRenderer {
	MultilineHeader mll;
	JScrollPane scrollPane;

	public MultilineHeaderRenderer(String title) {
		mll = new MultilineHeader(title);
		scrollPane = new JScrollPane(mll);

		scrollPane.setHorizontalScrollBarPolicy(
			JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

		scrollPane.setVerticalScrollBarPolicy(
			JScrollPane.VERTICAL_SCROLLBAR_NEVER);

		scrollPane.setBorder(null);
	}
	public Component getTableCellRendererComponent(JTable table, 
								Object value,
								boolean isSelected,
								boolean hasFocus,
								int row, int col) {
		mll.setText((String)value);
		return scrollPane;
	}
}
class MultilineHeader extends JTextArea {
	public MultilineHeader(String s) {
		super(s);
	}
	public void updateUI() {
		super.updateUI();

		// turn on wrapping and disable editing and highlighting

		setLineWrap(true);
		setWrapStyleWord(true);
		setHighlighter(null);
		setEditable(false);

		// make the text area look like a table header

		LookAndFeel.installColorsAndFont(this,
										"TableHeader.background",
										"TableHeader.foreground",
										"TableHeader.font");

		LookAndFeel.installBorder(this, "TableHeader.cellBorder");
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
