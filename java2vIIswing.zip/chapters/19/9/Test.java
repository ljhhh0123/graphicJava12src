import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

public class Test extends JFrame {
	Object[][] listings = new Object[][] {
		{ "28 Pickelodan", "Mork and Mindy", "Dukes of Hazard", 
		  "I Love Lucy", "Andy Griffith", "Mission Impossible" },

		{ "29 Dizey", "Rulan", "<-- Mulan", "<-- Mulan", 
		  "<-- Mulan", "<-- Mulan" },

		{ "31 NBT", "Nightly News", "40/20", 
		  "<-- 40/20", "LimeTime", "<-- LimeTime" },

		{ "32 AnimalUniverse", "Amazing Animals","Animal Rescues",
		  "Cute Animals", "Killer Animals", 
		  "Big and Small Animals" },

		{ "34 DSPN", "Tuesday Night FootBall", 
		"<--Tuesday Night FootBall", "<--Tuesday Night FootBall", 
		"<--Tuesday Night FootBall", "<--Tuesday Night FootBall"},

		{ "37 TLC", "Mind Mysteries", "Our World", 
		  "Ancient Wonders", "UFOs", "Ancient Inventions" },

		{ "38 THC", "The Civil War", "Stalin", 
		  "Watergate", "Kent State", "WWII" },
	};
	Object[] columnNames = new Object[] {
		"Channel", "7:30", "8:00", "8:30", "9:00", "9:30"
	};
	TableModel sharedModel = new DefaultTableModel(
								 		  listings, columnNames);
	JTable table = new JTable(sharedModel),
		   headerTable = new JTable(sharedModel);

	TableColumnModel tcm = table.getColumnModel();
	TableColumn firstColumn = tcm.getColumn(0);

	public Test() {
		Container cp = getContentPane();

		setActualPreferredColumnWidths(table);
		setActualPreferredColumnWidths(headerTable);

		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		headerTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		headerTable.getTableHeader().setReorderingAllowed(false);

		headerTable.setPreferredScrollableViewportSize(
			new Dimension(
				firstColumn.getPreferredWidth() +
				headerTable.getColumnModel().getColumnMargin(), 
				0));

		cp.add(new ControlPanel(), BorderLayout.NORTH);
		cp.add(new JScrollPane(table), BorderLayout.CENTER);
	}
	class ControlPanel extends JPanel {
		JCheckBox checkBox = new JCheckBox("First Column Locked");

		public ControlPanel() {
			add(checkBox);

			checkBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JScrollPane scrollPane = (JScrollPane)
						SwingUtilities.getAncestorOfClass(
							JScrollPane.class, table);

					if(checkBox.isSelected()) {
						tcm.removeColumn(firstColumn);
						scrollPane.setRowHeaderView(headerTable);
						scrollPane.setCorner(
							JScrollPane.UPPER_LEFT_CORNER,
							headerTable.getTableHeader());
					}
					else {
						tcm.addColumn(firstColumn);

						int numCols = tcm.getColumnCount();
						tcm.moveColumn(numCols-1, 0);
						scrollPane.setRowHeaderView(null);
					}
				}
			});
		}
	}
	public void setActualPreferredColumnWidths(JTable table) {
		int columnCount = table.getColumnCount();

		for(int i=0; i < columnCount; ++i) {
			TableColumn c = table.getColumnModel().getColumn(i);
			int w = getActualPreferredColumnWidth(c);

			c.setPreferredWidth(w);
		}
	}
	public int getActualPreferredColumnWidth(TableColumn col) {
		int hw = columnHeaderWidth(col),   // hw = header width
			cw = widestCellInColumn(col);  // cw = column width

		return hw > cw ? hw : cw;
	}
	private int columnHeaderWidth(TableColumn col) {
		TableCellRenderer renderer = col.getHeaderRenderer();

		Component comp = renderer.getTableCellRendererComponent(
						  			table, col.getHeaderValue(), 
						  			false, false, 0, 0);

		return comp.getPreferredSize().width;
	}
	private int widestCellInColumn(TableColumn col) {
		int c = col.getModelIndex(), width=0, maxw=0;

		for(int r=0; r < table.getRowCount(); ++r) {
			TableCellRenderer renderer = 
							  table.getCellRenderer(r,c);

			Component comp = 
				renderer.getTableCellRendererComponent(
						  			table, table.getValueAt(r,c), 
						  			false, false, r, c);

			width = comp.getPreferredSize().width;
			maxw = width > maxw ? width : maxw;
		}
		return maxw;
	}
	public static void main(String args[]) {
		GraphicJavaApplication.launch(
			new Test(),"Locking the Left-Hand Column",
						300,300,600,210);
	}
}
class GraphicJavaApplication extends WindowAdapter {
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
