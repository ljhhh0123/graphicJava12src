import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JFrame {
	Object[] resizeModes = new Object[] {
			"JTable.AUTO_RESIZE_OFF",
			"JTable.AUTO_RESIZE_NEXT_COLUMN",
			"JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS",
			"JTable.AUTO_RESIZE_LAST_COLUMN",
			"JTable.AUTO_RESIZE_ALL_COLUMNS",
	};
	int[] resizeConstants = {
			JTable.AUTO_RESIZE_OFF,
			JTable.AUTO_RESIZE_NEXT_COLUMN,
			JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS,
			JTable.AUTO_RESIZE_LAST_COLUMN,
			JTable.AUTO_RESIZE_ALL_COLUMNS,
	};
	JTable table = new JTable(6,5);

	public Test() {
		Container contentPane = getContentPane();

		contentPane.add(new ControlPanel(), BorderLayout.NORTH);
		contentPane.add(new JScrollPane(table), 
						BorderLayout.CENTER);

	}
	class ControlPanel extends JPanel {
		JComboBox resizeModeCombo = new JComboBox(resizeModes);

		public ControlPanel() {
			initializeCombo();

			setBorder(BorderFactory.createTitledBorder(
							"Resize Mode"));

			setLayout(new FlowLayout(FlowLayout.LEFT,2,2));
			add(resizeModeCombo);

			resizeModeCombo.addActionListener(
										new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int index = 
						resizeModeCombo.getSelectedIndex();

					table.setAutoResizeMode(
										resizeConstants[index]);
				}
			});
		}
		private void initializeCombo() {
			int resizeMode = table.getAutoResizeMode();

			if(resizeMode == JTable.AUTO_RESIZE_OFF)
				resizeModeCombo.setSelectedIndex(0);
			else if(resizeMode == JTable.AUTO_RESIZE_NEXT_COLUMN)
				resizeModeCombo.setSelectedIndex(1);
			else if(resizeMode == JTable.AUTO_RESIZE_LAST_COLUMN)
				resizeModeCombo.setSelectedIndex(2);
			else if(resizeMode == JTable.AUTO_RESIZE_ALL_COLUMNS)
				resizeModeCombo.setSelectedIndex(3);
			else if(
			  resizeMode == JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS)
				resizeModeCombo.setSelectedIndex(4);
		}
	}
	public static void main(String args[]) {
		GJApp.launch(
			new Test(), "JTable Resize Modes", 300,300,425,210);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
