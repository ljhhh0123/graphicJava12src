import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.util.*;

public class Test extends JFrame {
	JTable table = new JTable(new Object[][] {
				{"apple", "$.39"}, 		{"mango", "$.49"},
				{"papaya", "$1.19"}, 	{"lemon", "$.19"},
				{"orange", "$.59"}, 	{"watermelon", "$.39"},
				{"tangerine", "$1.09"}, {"cherry", "$.79"},
				{"banana", "$.29"}, 	{"lime", "$.33"},
				{"grapefruit", "$.69"}, {"grapes", "$.49"},
			},
			new Object[] { "Item", "Price/Lb." });	
		
	public Test() {
		TableColumn column = table.getColumn("Price/Lb.");
		TableCellRenderer renderer = column.getHeaderRenderer();

		column.setHeaderRenderer(new RendererDecorator(renderer));

		getContentPane().add(new JScrollPane(table),
							 				BorderLayout.CENTER);
	}
	public static void main(String args[]) {
		GJApp.launch(
			new Test(), "A Renderer Decorator", 300,300,450,182);
	}
}
class RendererDecorator implements TableCellRenderer {
	TableCellRenderer realRenderer;	
	JPanel panel;
	JLabel iconLabel = new JLabel(new ImageIcon("money.gif"));

	public RendererDecorator(TableCellRenderer r) {
		realRenderer = r;
		iconLabel.setBorder(BorderFactory.createEtchedBorder());
	}
	public Component getTableCellRendererComponent(
							JTable table, Object value,
							boolean isSelected, boolean hasFocus,
							int row, int col) {
		Component c = realRenderer.getTableCellRendererComponent(
								table, value, isSelected, 
								hasFocus, row, col);
		embellishComponent(c);
		return panel;
	}
	private void embellishComponent(Component c) {
		if(panel == null) {
			panel = new JPanel();

			panel.setLayout(new BorderLayout());
			panel.add(c, BorderLayout.CENTER);
			panel.add(iconLabel, BorderLayout.WEST);
		}
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
