import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public Test()  {
		JTree tree = new JTree();

		getContentPane().add(new JScrollPane(tree));

		tree.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				String s = null;
				JTree t = (JTree)e.getSource();
				int row = t.getRowForLocation(e.getX(), e.getY());

				if(e.getClickCount() == 2)
					s = "double click in row " + row;
				else
					s = "single click in row " + row;

				if(row != -1) {
					TreePath path = t.getPathForRow(row);
					TreeNode node = (TreeNode)
									path.getLastPathComponent(); 

					s += ", node = " + node.toString();
				}
				showStatus(s);
			}
		});
	}
}
