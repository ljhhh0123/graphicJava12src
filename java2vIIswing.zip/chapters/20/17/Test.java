import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JApplet {
	public void init() {
		JTree tree = new JTree();

		getContentPane().add(tree, BorderLayout.CENTER);

		// must invoke setEditable, or the call below to
		// getCellEditor() will return null.

		tree.setEditable(true);

		tree.getCellEditor().addCellEditorListener(
						new CellEditorListener() {
			public void editingCanceled(ChangeEvent e) {
				CellEditor editor = (CellEditor)e.getSource();
				String s = (String)editor.getCellEditorValue();

				showStatus("editing cancelled: " + s);
			}
			public void editingStopped(ChangeEvent e) {
				CellEditor editor = (CellEditor)e.getSource();
				String s = (String)editor.getCellEditorValue();

				showStatus("editing stopped: " + s);
			}
		});
	}
}
