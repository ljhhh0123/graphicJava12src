import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	JTree tree = new JTree();

	TreeSelectionModel selectionModel = tree.getSelectionModel();

	String modes[] = {
		"CONTIGUOUS_TREE_SELECTION",
		"DISCONTIGUOUS_TREE_SELECTION",
		"SINGLE_TREE_SELECTION"
	};
	int modeIds[] = {
		TreeSelectionModel.CONTIGUOUS_TREE_SELECTION,
		TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION,
		TreeSelectionModel.SINGLE_TREE_SELECTION,
	};

	public void init() {
		Container contentPane = getContentPane();

		contentPane.add(new ControlPanel(), BorderLayout.NORTH);
		contentPane.add(new JScrollPane(tree), 
					    BorderLayout.CENTER);
	}
	class ControlPanel extends JPanel {
		JComboBox combo = new JComboBox();
		JButton button = new JButton("clear selection");

		public ControlPanel() {
			for(int i=0; i < modes.length; ++i) {
				combo.addItem(modes[i]);
			}
			add(new JLabel("Selection Mode:"));
			add(combo);
			add(button);

			int initialMode = selectionModel.getSelectionMode();

			if(initialMode == modeIds[0])
				combo.setSelectedIndex(0);
			else if(initialMode == modeIds[1])
				combo.setSelectedIndex(1);
			else if(initialMode == modeIds[2])
				combo.setSelectedIndex(2);

			combo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int index = combo.getSelectedIndex();
					selectionModel.setSelectionMode(
												modeIds[index]);
				}
			});
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					selectionModel.clearSelection();
				}
			});
		}
	}
}
