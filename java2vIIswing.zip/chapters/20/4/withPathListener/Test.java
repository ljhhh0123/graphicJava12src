import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.EventObject;

public class Test extends JFrame {
	public Test() {
		JTree tree = new JTree(createTreeModel());
		JScrollPane scrollPane = new JScrollPane(tree);

		getContentPane().add(scrollPane, BorderLayout.CENTER);
		getContentPane().add(GJApp.getStatusArea(), 
										 BorderLayout.SOUTH);

		tree.getSelectionModel().setSelectionMode(
			TreeSelectionModel.SINGLE_TREE_SELECTION);

		tree.addTreeExpansionListener(new TreeExpansionListener(){
			public void treeCollapsed(TreeExpansionEvent e) {
			}
			public void treeExpanded(TreeExpansionEvent e) {
				UpdateStatus updateThread;
				TreePath path = e.getPath();
				FileNode node = (FileNode)
								   path.getLastPathComponent();

				if( ! node.isExplored()) {
					GJApp.updateStatus("exploring ...");

					UpdateStatus us = new UpdateStatus();
					us.start();

					node.explore();
				}
			}
			class UpdateStatus extends Thread {
				public void run() {
					try { Thread.currentThread().sleep(450); }
					catch(InterruptedException e) { }

					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							GJApp.updateStatus(" ");
						}
					});
				}
			}
		});
		tree.addTreeSelectionListener(
									new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				TreePath path = e.getNewLeadSelectionPath();

				if(path != null)
					GJApp.updateStatus("Path: " + path.toString());
			}
		});
	}
	private DefaultTreeModel createTreeModel() {
		File root = new File("E:/");
		FileNode rootNode = new FileNode(root), node;

		rootNode.explore();
		return new DefaultTreeModel(rootNode);
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(),"TreePaths",300,300,450,400);
	}
}
class FileNode extends DefaultMutableTreeNode {
	private boolean explored = false;

	public FileNode(File file) 	{ 
		setUserObject(file); 
	}
	public boolean getAllowsChildren() { return isDirectory(); }
	public boolean isLeaf() 	{ return !isDirectory(); }
	public File getFile()		{ return (File)getUserObject(); }

	public void explore() 		{ explore(false); }
	public boolean isExplored() { return explored; }

	public boolean isDirectory() {
		File file = (File)getUserObject();
		return file.isDirectory();
	}
	public String toString() {
		File file = (File)getUserObject();
		String filename = file.toString();
		int index = filename.lastIndexOf("\\");

		return (index != -1 && index != filename.length()-1) ? 
									filename.substring(index+1) : 
									filename;
	}
	public void explore(boolean force) {
		if(!isExplored() || force) {
			File file = getFile();
			File[] children = file.listFiles();

			for(int i=0; i < children.length; ++i) 
				add(new FileNode(children[i]));

			explored = true;
		}
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void updateStatus(String s) {
		status.setText(s);
	}
}
