import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;

public class Test extends JApplet {
	public void init() {
		JTree tree = new JTree();
		JScrollPane scrollPane = new JScrollPane(tree);

		DefaultMutableTreeNode root = 
						new DefaultMutableTreeNode("prices");

		root.add(new DefaultMutableTreeNode(new Double(10.99)));
		root.add(new DefaultMutableTreeNode(new Double(8.99)));	
		root.add(new DefaultMutableTreeNode(new Double(6.95)));	
		root.add(new DefaultMutableTreeNode(new Double(8.00)));	
		root.add(new DefaultMutableTreeNode(new Double(7.59)));	
		root.add(new DefaultMutableTreeNode(new Double(2.49)));	

		DefaultTreeModel model = 
						(DefaultTreeModel)tree.getModel();

		model.setRoot(root);

		tree.setCellRenderer(new FormattingRenderer());
		tree.setEditable(true);
		getContentPane().add(scrollPane);
	}
}
class FormattingRenderer extends DefaultTreeCellRenderer {
	public Component getTreeCellRendererComponent(
						JTree tree, Object value, 
						boolean selected, boolean expanded,
						boolean leaf, int row, 
						boolean hasFocus) {
		// initialize renderer component (this) ...

		super.getTreeCellRendererComponent(
							tree, value, selected, expanded, 
							leaf, row, hasFocus);

		// now format label text ...

		DefaultMutableTreeNode n = (DefaultMutableTreeNode)value;
		Object userObject = n.getUserObject();

		if(userObject instanceof Double) { 
			Double d = (Double)userObject;
			Format format = NumberFormat.getCurrencyInstance();

			setText(value == null ? "" : format.format(d));
		}
		return this;
	}
}
