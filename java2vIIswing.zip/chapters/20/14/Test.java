import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JApplet {
	public void init() {
		JTree tree = new JTree();
		JScrollPane scrollPane = new JScrollPane(tree);
		JComboBox combo = new JComboBox();

		combo.addItem("red");
		combo.addItem("blue");
		combo.addItem("green");
		combo.addItem("orange");
		combo.addItem("yellow");
		combo.addItem("magenta");

		tree.setCellEditor(new DefaultTreeCellEditor(
			tree, new DefaultTreeCellRenderer(),
			new ColorEditor(tree, combo)));

		tree.setEditable(true);

		getContentPane().add(scrollPane);
	}
}
class ColorEditor extends DefaultCellEditor {
	private JTree tree;

	public ColorEditor(JTree tree, JComboBox comboBox) {
		super(comboBox);
		this.tree = tree;
	}
	public boolean isCellEditable(EventObject e) {
		boolean rv = false;  // return value

		if(e instanceof MouseEvent) {
			MouseEvent me = (MouseEvent)e;

			if(me.getClickCount() == 3) {
				TreePath path =
					tree.getPathForLocation(me.getX(), me.getY());	

				if(path.getPathCount() == 1) // root node
					return false;

				DefaultMutableTreeNode node = 
					(DefaultMutableTreeNode)
								   path.getLastPathComponent();		
								   
				rv = node.getParent().toString().equals("colors");
			}
		}
		return rv;
	}
}
