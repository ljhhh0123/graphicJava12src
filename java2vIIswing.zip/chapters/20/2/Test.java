import javax.swing.*;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JApplet {
	Hashtable ht = new Hashtable(), ht2 = new Hashtable();
	Vector vector = new Vector();
	Object[] objs = new Object[] {
			"array item 1", "array item 2", "array item 3" 
	};
	public void init() {
		Container contentPane = getContentPane();

		vector.addElement("vector element 1");
		vector.addElement("vector element 2");
		vector.addElement("vector element 3");
		vector.addElement("vector element 4");
		vector.addElement("vector element 5");

		ht.put("another hashtable", ht2);
		ht.put("vector", vector);
		ht.put("Object[]", objs);

		ht2.put("Object[]", objs);
		ht2.put("vector", vector);
		ht2.put("one", new Integer(1));
		ht2.put("two", new Integer(2));
		ht2.put("three", new Integer(3));

		// trees must be created after data is populated

		JTree hashTree = new JTree(ht);
		JTree vectorTree = new JTree(vector);
		JTree objectTree = new JTree(objs);

		JScrollPane objPane = new JScrollPane(objectTree);
		JScrollPane hashPane = new JScrollPane(hashTree);
		JScrollPane vectorPane = new JScrollPane(vectorTree);

		objPane.setPreferredSize(new Dimension(150,150));
		hashPane.setPreferredSize(new Dimension(500,500));
		vectorPane.setPreferredSize(new Dimension(150,150));

		objPane.setBorder(
			BorderFactory.createTitledBorder("Object[]"));

		hashPane.setBorder(
			BorderFactory.createTitledBorder("Hashtable"));

		vectorPane.setBorder(
			BorderFactory.createTitledBorder("Vector"));

		hashTree.expandPath(new TreePath(
							hashTree.getModel().getRoot()));	

		contentPane.setLayout(new FlowLayout());
		contentPane.add(objPane);
		contentPane.add(hashPane);
		contentPane.add(vectorPane);
	}
}
