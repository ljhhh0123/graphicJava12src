import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JTree tree = new JTree();

		contentPane.add(tree);

		tree.addTreeExpansionListener(
									new TreeExpansionListener() {
			public void treeCollapsed(TreeExpansionEvent e) {
				TreePath path = e.getPath();
				TreeNode node = (TreeNode)
								path.getLastPathComponent();

				showStatus("node " + "\"" + node.toString() + 
							"\"" + " collapsed");
			}
			public void treeExpanded(TreeExpansionEvent e) {
				TreePath path = e.getPath();
				TreeNode node = (TreeNode)
								path.getLastPathComponent();

				showStatus("node " + "\"" + node.toString() + 
							"\"" + " expanded");
			}
		});
	}
}
