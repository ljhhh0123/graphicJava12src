import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	static private Icon 
				   openFolder = new ImageIcon("button_lit.jpg"),
				   closedFolder = new ImageIcon("button.jpg"),
				   leafIcon = new ImageIcon("leaf.gif");

	public void init() {
		JTree tree = new JTree();
		JScrollPane scrollPane = new JScrollPane(tree);
		DefaultTreeCellRenderer renderer = 
								new DefaultTreeCellRenderer();

		renderer.setClosedIcon(closedFolder);
		renderer.setOpenIcon(openFolder);
		renderer.setLeafIcon(leafIcon);
		renderer.setFont(new Font("Serif", Font.ITALIC, 12));

		tree.setCellRenderer(renderer);
		tree.setEditable(true);
		getContentPane().add(scrollPane);
	}
}
