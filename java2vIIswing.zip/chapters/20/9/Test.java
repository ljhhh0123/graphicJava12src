import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	static private Icon 
				   openFolder = new ImageIcon("button_lit.jpg"),
				   closedFolder = new ImageIcon("button.jpg"),
				   leafIcon = new ImageIcon("leaf.gif");

	public void init() {
		UIManager.put("Tree.closedIcon", closedFolder);
		UIManager.put("Tree.openIcon", openFolder);
		UIManager.put("Tree.leafIcon", leafIcon);

		JTree tree = new JTree();
		JScrollPane scrollPane = new JScrollPane(tree);

		getContentPane().add(scrollPane);
	}
}
