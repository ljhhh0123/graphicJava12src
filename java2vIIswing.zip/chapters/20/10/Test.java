import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.io.File;

public class Test extends JFrame {
	public Test() {
		final JTree tree = new JTree(createTreeModel());
		JScrollPane scrollPane = new JScrollPane(tree);
		FileNodeRenderer renderer = new FileNodeRenderer();

		tree.setEditable(true);
		tree.setCellRenderer(renderer);

		getContentPane().add(scrollPane, BorderLayout.CENTER);

		tree.addTreeExpansionListener(new TreeExpansionListener(){
			public void treeCollapsed(TreeExpansionEvent e) {
			}
			public void treeExpanded(TreeExpansionEvent e) {
				TreePath path = e.getPath();
				FileNode node = (FileNode)
								   path.getLastPathComponent();

				if( ! node.isExplored()) {
					DefaultTreeModel model = 
							(DefaultTreeModel)tree.getModel();

					node.explore();
					model.nodeStructureChanged(node);
				}
			}
		});
	}
	private DefaultTreeModel createTreeModel() {
		File root = new File("E:/");
		FileNode rootNode = new FileNode(root), node;

		rootNode.explore();
		return new DefaultTreeModel(rootNode);
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(),"JTree File Explorer",
								 300,300,450,400);
	}
}
class FileNode extends DefaultMutableTreeNode {
	private boolean explored = false, selected = false;

	public FileNode(File file) 	{ 
		setUserObject(file); 
	}
	public boolean getAllowsChildren() { return isDirectory(); }
	public boolean isLeaf() 	{ return !isDirectory(); }
	public File getFile()		{ return (File)getUserObject(); }

	public void explore() 		{ explore(false); }
	public boolean isExplored() { return explored; }

	public void setSelected(boolean s) { selected = s; }
	public boolean isSelected()		   { return selected; }

	public boolean isDirectory() {
		File file = (File)getUserObject();
		return file.isDirectory();
	}
	public String toString() {
		File file = (File)getUserObject();
		String filename = file.toString();
		int index = filename.lastIndexOf("\\");

		return (index != -1 && index != filename.length()-1) ? 
									filename.substring(index+1) : 
									filename;
	}
	public void explore(boolean force) {
		if(!isExplored() || force) {
			File file = getFile();
			File[] children = file.listFiles();

			for(int i=0; i < children.length; ++i) 
				add(new FileNode(children[i]));

			explored = true;
		}
	}
}
class FileNodeRenderer extends DefaultTreeCellRenderer {
	protected JCheckBox checkBox = new JCheckBox("backup");
	private Component strut = Box.createHorizontalStrut(5);
	private JPanel panel = new JPanel();

	public FileNodeRenderer() {
		panel.setBackground(
					UIManager.getColor("Tree.textBackground"));
					
		setOpaque(false);
		checkBox.setOpaque(false);
		panel.setOpaque(false);

		panel.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));
		panel.add(this);
		panel.add(strut);
		panel.add(checkBox);

	}	
	public Component getTreeCellRendererComponent(
						JTree tree, Object value, 
						boolean selected, boolean expanded,
						boolean leaf, int row, 
						boolean hasFocus) {
		FileNode node = (FileNode)value;
		String s = tree.convertValueToText(value, selected,
								   expanded, leaf, row, hasFocus);

		super.getTreeCellRendererComponent(
								tree, value, selected, expanded,
								leaf, row, hasFocus);

		checkBox.setVisible(node.isDirectory());
		checkBox.setSelected(node.isSelected());

		return panel;
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void updateStatus(String s) {
		status.setText(s);
	}
}
