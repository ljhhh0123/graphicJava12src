import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import java.util.*;

public class Test extends JApplet {
	private JTree tree = new JTree();
	private JButton button = new JButton("show traversals");

	private DefaultMutableTreeNode root = 
				(DefaultMutableTreeNode)tree.getModel().getRoot();

	public void init() {
		getContentPane().add(new JScrollPane(tree), 
								BorderLayout.CENTER);
		getContentPane().add(button, BorderLayout.NORTH);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Enumeration df = root.depthFirstEnumeration();
				Enumeration bf = root.breadthFirstEnumeration();

				while(df.hasMoreElements()) {
					System.out.println(
									df.nextElement().toString());
				}

				System.out.println("");
				System.out.println("");

				while(bf.hasMoreElements()) {
					System.out.println(
									bf.nextElement().toString());
				}

			}
		});
	}
}
