import java.awt.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		getContentPane().add(new JScrollPane(new JTree()));
	}
}
