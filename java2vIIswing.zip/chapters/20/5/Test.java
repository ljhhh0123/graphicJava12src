import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.awt.*;
//import java.awt.event.*;

public class Test extends JApplet {
	JTree tree = new JTree();
	DefaultTreeModel model = (DefaultTreeModel)tree.getModel();
	TreeSelectionModel selectionModel = tree.getSelectionModel();

	public void init() {
		getContentPane().add(tree, BorderLayout.CENTER);

		tree.addTreeSelectionListener(
									new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				TreePath path = e.getNewLeadSelectionPath();

				if(path == null)
					System.out.println("Selection Cleared");
				else {
					TreePath parentPath = path.getParentPath();
					Object 
					  	lastNode = path.getLastPathComponent(),
						firstNode= path.getPathComponent(0);

					System.out.println("Path: " + path + 
										" has " + 
										path.getPathCount() + 
										" nodes");
					System.out.println("Last Path Component: " +
										lastNode.toString());
					System.out.println("First Path Component: " +
										firstNode.toString());
					System.out.println("Parent Path: " + 
										parentPath);

					// the following if statement is always true 

					if(parentPath.isDescendant(path)) {
						System.out.println(parentPath + 
							" is a descendant of " + path);

					}
					DefaultMutableTreeNode last =
								(DefaultMutableTreeNode)lastNode;
					DefaultMutableTreeNode first =
								(DefaultMutableTreeNode)lastNode;

					if(first.isNodeDescendant(last)) {
						System.out.println(
								"last is descendant of first");
						
					}
					System.out.println("");
				}

			}
		});
	}
}
