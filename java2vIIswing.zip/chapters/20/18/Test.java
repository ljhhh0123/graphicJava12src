import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	JTree tree = new JTree();
	JTextArea textArea = new JTextArea();
	JSplitPane splitPane = new JSplitPane(
								JSplitPane.HORIZONTAL_SPLIT, 
								new JScrollPane(tree), 
								new JScrollPane(textArea));
	public void init() {
		splitPane.setDividerLocation(150);
		textArea.setFont(new Font("Serif", Font.PLAIN, 17));

		getContentPane().add(splitPane, BorderLayout.CENTER);

		tree.addTreeSelectionListener(
									new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				TreePath path = e.getNewLeadSelectionPath();
				String s = new String();

				if(path != null) {
					s += "New lead selection path: " + 
										path.toString() + "\n";
				}
				else 
					s += "selection cleared\n";

				path = e.getOldLeadSelectionPath();

				if(path != null) { 
					s += "Old lead selection path: " + 
										path.toString() + "\n";
				}
				else
					s += "No previous lead selection\n";

				textArea.append(s + "\n");
				printSelectionInformation(e);
			}
			void printSelectionInformation(TreeSelectionEvent e) {
				showPaths(e);
				showRows();

				textArea.append("\n----------------------------");
				textArea.append("----------------------------\n");
			}
			private void showPaths(TreeSelectionEvent e) {
				TreePath[] paths = e.getPaths();
				
				textArea.append("Number of Paths:  " + 
								 paths.length + "\n");

				for(int i=0; i < paths.length; ++i) {
					TreePath path = paths[i];
					boolean wasAdded = e.isAddedPath(path);

					textArea.append("  path " + i + ": ");
					textArea.append(path + 
							(wasAdded ? " added to selection" :
							 " removed from selection") + "\n");
				}
				
			}
			private void showRows() {
				int[] rows = tree.getSelectionRows();

				if(rows != null && rows.length > 0) {
					textArea.append("\nSelected Rows:  ");
					
					for(int i=0; i < rows.length; ++i) {
						textArea.append(
									   Integer.toString(rows[i]));

						if(i != rows.length-1)
							textArea.append(",");
					}
				}
				
			}
		});
	}
}
