import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JButton button = new JButton("show dialog ...");

	private String title = "dialog title";
	private String message = "information";
	private int messageType = JOptionPane.INFORMATION_MESSAGE;
	private String messages[] = {
		"information", "error", "warning", "question", "plain"
	};

	public Test() {
		Container contentPane = getContentPane();
		JPanel controlPanel = new ControlPanel(this);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(controlPanel);
		contentPane.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(
				  button, // parentComponent
				  message, // message
				  title, // title
				  messageType);
			}
		});
	}
	public void setMessageType(int messageType) {
		this.messageType = messageType;

		switch(messageType) {
			case JOptionPane.INFORMATION_MESSAGE:
					message = messages[0]; 
					break;
			case JOptionPane.ERROR_MESSAGE:
					message = messages[1]; 
					break;
			case JOptionPane.WARNING_MESSAGE:
					message = messages[2]; 
					break;
			case JOptionPane.QUESTION_MESSAGE:
					message = messages[3]; 
					break;
			case JOptionPane.PLAIN_MESSAGE:
					message = messages[4]; 
					break;
		}
	}
}
class ControlPanel extends JPanel { 
	private JComboBox messageTypes = new JComboBox();
	private int[] typeValues = {
		JOptionPane.INFORMATION_MESSAGE,
		JOptionPane.ERROR_MESSAGE,
		JOptionPane.WARNING_MESSAGE,
		JOptionPane.QUESTION_MESSAGE,
		JOptionPane.PLAIN_MESSAGE,
	};
	private String[] typeNames = {
		"JOptionPane.INFORMATION_MESSAGE",
		"JOptionPane.ERROR_MESSAGE",
		"JOptionPane.WARNING_MESSAGE",
		"JOptionPane.QUESTION_MESSAGE",
		"JOptionPane.PLAIN_MESSAGE",
	};

	public ControlPanel(final Test applet) {
		add(messageTypes);

		for(int i=0; i < typeNames.length; ++i) {
			messageTypes.addItem(typeNames[i]);
		}
		messageTypes.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String s = (String)messageTypes.getSelectedItem();
				int type;

				for(int i=0; i < typeNames.length; ++i) {
					if(s.equals(typeNames[i]))
						applet.setMessageType(typeValues[i]);
				}
			}
		});
	}
}
