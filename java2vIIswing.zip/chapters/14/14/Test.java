import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		Object[] objects = new Object[] {
				new JLabel("JOptionPane(Object message)",
							new ImageIcon("beach_umbrella.gif"),
							JLabel.LEFT),
				new JCheckBox("check me out"),
				new VerboseObject(),
		};
		Object[] objects2 = new Object[] {
				"JOptionPane(Object message, int messageType)",
				"messageType = JOptionPane.INFORMATION_MESSAGE",
		};
		Object[] objects3 = new Object[] {
				"JOptionPane(Object message, " +
				"int messageType, int optionsType)",
				"messageType = JOptionPane.QUESTION_MESSAGE",
				"optionType = JOptionPane.YES_NO_CANCEL_OPTION",
		};
		Object[] objects4 = new Object[] {
				"JOptionPane(Object message, " +
				"int messageType, int optionsType, Icon icon)",
				"messageType = JOptionPane.WARNING_MESSAGE",
				"optionType = JOptionPane.OK_CANCEL_OPTION",
				"icon = new ImageIcon(\"ballot_box.gif\")",
		};
		Object[] objects5 = new Object[] {
				"JOptionPane(Object message, " +
				"int messageType, int optionsType, Icon icon)",
				"messageType = JOptionPane.ERROR_MESSAGE",
				"optionType = JOptionPane.OK_CANCEL_OPTION",
				"icon = null",
				"options = \"button 1\", \"button 2\", " +
							"new JButton(\"button 3\")",
		};

		JOptionPane defaultPane = new JOptionPane();

		JOptionPane messagePane = new JOptionPane(
				"JOptionPane(Object message)");

		JOptionPane objectPane = new JOptionPane(objects);

		JOptionPane messageTypePane = new JOptionPane(
				objects2, JOptionPane.INFORMATION_MESSAGE);

		JOptionPane messageAndOptionTypePane = new JOptionPane(
				objects3, JOptionPane.QUESTION_MESSAGE,
				JOptionPane.YES_NO_CANCEL_OPTION);

		JOptionPane messageOptionAndIconPane = new JOptionPane(
				objects4, JOptionPane.WARNING_MESSAGE,
				JOptionPane.OK_CANCEL_OPTION,
				new ImageIcon("ballot_box.gif"));

		Object[] options = {
			"button 1", "button 2", new JButton("button 3"),
		};
		JOptionPane messageOptionIconAndOptionsPane = 
												new JOptionPane(
				objects5, JOptionPane.ERROR_MESSAGE,
				JOptionPane.OK_CANCEL_OPTION,
				null,
				options,
				options[2]);

		contentPane.setLayout(new BoxLayout(contentPane, 
											BoxLayout.Y_AXIS));
		contentPane.add(defaultPane);
		contentPane.add(new JSeparator());
		contentPane.add(messagePane);
		contentPane.add(new JSeparator());
		contentPane.add(objectPane);
		contentPane.add(new JSeparator());
		contentPane.add(messageTypePane);
		contentPane.add(new JSeparator());
		contentPane.add(messageAndOptionTypePane);
		contentPane.add(new JSeparator());
		contentPane.add(messageOptionAndIconPane);
		contentPane.add(new JSeparator());
		contentPane.add(messageOptionIconAndOptionsPane);
	}
}
class VerboseObject extends Object { 
	public String toString() {
		return "This is what you'll see in the option pane";
	}
}
