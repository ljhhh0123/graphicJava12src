import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;

public class Test extends JApplet {
	private JButton button = new JButton("show dialog ...");

	private String title = "Update References";
	private JPanel messagePanel = new JPanel();
	private JCheckBox[] checkBoxes = {
		new JCheckBox("All Cross-References"),
		new JCheckBox("Text Insets Marked for Manual Update"),
		new JCheckBox("Text Insets Marked for Automatic Update"),
		new JCheckBox("OLE Links Marked for Manual Update"),
		new JCheckBox("OLE Links Marked for Automatic Update"),
	};

	public Test() {
		Container contentPane = getContentPane();

		messagePanel.setBorder(
			BorderFactory.createTitledBorder("Update:"));

		messagePanel.setLayout(new BoxLayout(messagePanel, 
									BoxLayout.Y_AXIS));

		for(int i=0; i < checkBoxes.length; ++i)
			messagePanel.add(checkBoxes[i]);

		final JOptionPane pane = new JOptionPane(
					messagePanel, // message
					JOptionPane.QUESTION_MESSAGE, // messageType
					JOptionPane.OK_CANCEL_OPTION); // optionType

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JDialog dialog = pane.createDialog(
					Test.this, // parentComponent
					title); // title

				dialog.show();  // blocks

				Integer value = (Integer)pane.getValue();

				if(value.intValue() == JOptionPane.OK_OPTION)
					updateReferences();
				else
					showStatus("dialog canceled");
			}
		});
		pane.addPropertyChangeListener(
									new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent e) {
				String name = e.getPropertyName();

				if(name.equals(JOptionPane.VALUE_PROPERTY))
				System.out.println(name + ":" + e.getNewValue());
			}
		});
	}
	private void updateReferences() {
		showStatus("updating references");
	}
}
