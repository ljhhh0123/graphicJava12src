import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JButton button = new JButton("show dialog ...");

	private String title = "Reminder!";
	private String message = "Dinner time";

	public Test() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(
				  button, // parentComponent
				  message, // message
				  title, // title
				  JOptionPane.INFORMATION_MESSAGE,// messageType
				  new ImageIcon("dining.gif")); // icon 
			}
		});
	}
}
