import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JButton button = new JButton("show dialog ...");

	private String title = "Animal Selection Dialog";
	private String message = "Select your favorite animal:";
	private String[] selectionValues = {
		"dog", "cat", "mouse", "goat", "koala", "rabbit",
	};

	public Test() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = (String)JOptionPane.showInputDialog(
					Test.this, // parentComponent
					message, // message
					title, // title
					JOptionPane.QUESTION_MESSAGE, // messageType
					null, // icon
					selectionValues, // selectionValues
					selectionValues[3]); // initialValue

				if(s == null)
					showStatus("cancel button activated");
				else
					showStatus(s);
			}
		});
	}
}
