import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private ConstraintsPanel cp = new ConstraintsPanel();
	private JPanel buttonsPanel = new JPanel();  

	private JButton showButton = new JButton("show dialog ..."),
					okButton = new JButton("OK"),
					applyButton = new JButton("Apply"),
					cancelButton = new JButton("Cancel");

	private JButton[] buttons = new  JButton[] {
		okButton, applyButton, cancelButton,
	};

	private JDialog dialog = new JDialog(null, // owner
								"Constraints Dialog", // title
								true); // modal

	public Test() {
		Container contentPane = getContentPane();
		Container dialogContentPane = dialog.getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(showButton);

		dialogContentPane.add(cp, BorderLayout.CENTER);
		dialogContentPane.add(buttonsPanel, BorderLayout.SOUTH);
		dialog.pack();

		// setLocationRelativeTo must be called after pack(),
		// because dialog placement is based on dialog size.
		// Because the applet is not yet showing, calling
		// setLocationRelativeTo() here causes the dialog to be
		// shown centered on the screen.
		//
		// If setLocationRelativeTo() is not invoked, the dialog
		// will be located at (0,0) in screen coordinates.
		//dialog.setLocationRelativeTo(this);

		for(int i=0; i < buttons.length; ++i) {
			buttonsPanel.add(buttons[i]);
		}
		addButtonListeners();
	}
	private void addButtonListeners() {
		showButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// calling setLocationRelativeTo() here causes
				// the dialog ito be centered over the applet.
				dialog.setLocationRelativeTo(Test.this);
				dialog.show();
			}
		});
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showStatus("OK button Activated");
				dialog.dispose();
			}
		});
		applyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showStatus("Apply button Activated");
			}
		});
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showStatus("Cancel button Activated");
				dialog.dispose();
			}
		});
	}
}
