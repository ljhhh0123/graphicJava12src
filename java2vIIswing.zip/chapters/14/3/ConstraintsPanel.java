import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

class ConstraintsPanel extends JPanel {
	AnchorFillWeightPanel 	afpanel = new AnchorFillWeightPanel();
	DisplayAreaPanel 		dpanel = new DisplayAreaPanel();
	PaddingPanel 			ppanel = new PaddingPanel();
	InsetsPanel				ipanel = new InsetsPanel();
	String 					dpaneltip = "display area attributes",
							afpaneltip = "component attributes",
							ppaneltip = "padding";

	public ConstraintsPanel() {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		add(dpanel);
		add(Box.createVerticalStrut(15));
		add(afpanel);
		add(Box.createVerticalStrut(15));
		add(ppanel);
		add(Box.createVerticalStrut(15));
		add(ipanel);
		add(Box.createVerticalStrut(15));
	}
	public void setConstraints(GridBagConstraints gbc) {
		afpanel.setAnchor(gbc.anchor);
		afpanel.setFill(gbc.fill);
		afpanel.setWeightx(new Double(gbc.weightx));
		afpanel.setWeighty(new Double(gbc.weighty));

		dpanel.setGridx(gbc.gridx);
		dpanel.setGridy(gbc.gridy);
		dpanel.setGridwidth(gbc.gridwidth);
		dpanel.setGridheight(gbc.gridheight);

		ppanel.setPadx(gbc.ipadx);
		ppanel.setPady(gbc.ipady);

		ipanel.setInsetsConstraints(gbc.insets);
	}
	public GridBagConstraints getConstraints() {
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.anchor = afpanel.getAnchor();
		gbc.fill = afpanel.getFill();

		gbc.gridx = dpanel.getGridx();
		gbc.gridy = dpanel.getGridy();
		gbc.gridwidth = dpanel.getGridwidth();
		gbc.gridheight = dpanel.getGridheight();

		gbc.weightx = (afpanel.getWeightx()).doubleValue();
		gbc.weighty = (afpanel.getWeighty()).doubleValue();

		gbc.ipadx = ppanel.getPadx();
		gbc.ipady = ppanel.getPady();

		gbc.insets = ipanel.getInsetsConstraint();

		return gbc;
	}
}
class PaddingPanel extends JPanel {
	JLabel 	ipadxLabel = new JLabel("ipadx:"),
			ipadyLabel = new JLabel("ipady:");

	JTextField 	ipadxField = new JTextField(3),
				ipadyField = new JTextField(3);

	int padX, padY;

	public PaddingPanel() {
		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();

		setLayout(gbl);
		gbc.anchor = GridBagConstraints.NORTHWEST;

		add(ipadxLabel, gbc);
		add(Box.createHorizontalStrut(10), gbc);
		add(ipadxField, gbc);
		add(Box.createHorizontalStrut(20), gbc);
		add(ipadyLabel, gbc);
		add(Box.createHorizontalStrut(10), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.weightx = 1.0;
		add(ipadyField, gbc);

		setBorder(new CompoundBorder(
			BorderFactory.createTitledBorder("Internal Padding"),
			BorderFactory.createEmptyBorder(10,10,10,10)));
	}
	public void setPadx(int padX) {
		ipadxField.setText(Integer.toString(padX));
		repaint();
	}
	public void setPady(int padY) {
		ipadyField.setText(Integer.toString(padY));
		repaint();
	}
	public int getPadx() {
		return Integer.parseInt(ipadxField.getText());
	}
	public int getPady() {
		return Integer.parseInt(ipadyField.getText());
	}
}
class InsetsPanel extends JPanel {
	JTextField 	topField 	= new JTextField(3),
				leftField 	= new JTextField(3),
				bottomField = new JTextField(3),
				rightField 	= new JTextField(3);

	public InsetsPanel() {
		setLayout(new BorderLayout());
		add(topField, "North");
		add(leftField, "West");
		add(bottomField, "South");
		add(rightField, "East");

		setBorder(new CompoundBorder(
			BorderFactory.createTitledBorder("Insets"),
			BorderFactory.createEmptyBorder(10,10,10,10)));
	}
	public void setInsetsConstraints(Insets insets) {
		topField.setText(Integer.toString(insets.top));
		leftField.setText(Integer.toString(insets.left));
		bottomField.setText(Integer.toString(insets.bottom));
		rightField.setText(Integer.toString(insets.right));
	}
	public Insets getInsetsConstraint() {
		return new Insets(
			Integer.parseInt(topField.getText()),
			Integer.parseInt(leftField.getText()),
			Integer.parseInt(bottomField.getText()),
			Integer.parseInt(rightField.getText()));
	}
	void updateInsets() {
	}
}

class DisplayAreaPanel extends JPanel {
	JLabel	gridxLabel = new JLabel("gridx:"),
			gridyLabel = new JLabel("gridy:"),
			gridwidthLabel = new JLabel("gridwidth:"),
			gridheightLabel = new JLabel("gridheight:");

	JComboBox 	gridxCombo 		= new JComboBox(),
				gridyCombo 		= new JComboBox(),
				gridwidthCombo 	= new JComboBox(),
				gridheightCombo = new JComboBox();

	private void addToolTips() {
		gridxLabel.setToolTipText("grid x"); 
		gridyLabel.setToolTipText("grid y");
		gridwidthLabel.setToolTipText("width in grid cells");
		gridheightLabel.setToolTipText("height in grid cells");

		gridxCombo.setToolTipText("integer value");
		gridyCombo.setToolTipText("integer value");
		gridwidthCombo.setToolTipText("integer value");
		gridheightCombo.setToolTipText("integer value");
	}
	public DisplayAreaPanel() {
		GridBagLayout 		gbl = new GridBagLayout();
		GridBagConstraints 	gbc = new GridBagConstraints();

		setLayout(gbl);

		gbc.anchor = GridBagConstraints.NORTHWEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;

		add(gridxLabel, gbc);
		add(Box.createHorizontalStrut(7), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		add(gridxCombo, gbc);

		gbc.gridwidth = 1;

		add(gridyLabel, gbc);
		add(Box.createHorizontalStrut(7), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		add(gridyCombo, gbc);
		add(Box.createVerticalStrut(10), gbc);

		gbc.gridwidth = 1;

		add(gridwidthLabel, gbc);
		add(Box.createHorizontalStrut(7), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		add(gridwidthCombo, gbc);

		gbc.gridwidth = 1;

		add(gridheightLabel, gbc);
		add(Box.createHorizontalStrut(7), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		add(gridheightCombo, gbc);

		addToolTips();

		setBorder(new CompoundBorder(
			BorderFactory.createTitledBorder("Display Area"),
			BorderFactory.createEmptyBorder(10,10,10,10)));

		gridxCombo.addItem("RELATIVE");
		gridxCombo.addItem("0");
		gridxCombo.addItem("1");
		gridxCombo.addItem("2");
		gridxCombo.addItem("3");
		gridxCombo.addItem("4");
		gridxCombo.addItem("5");
		gridxCombo.addItem("6");
		gridxCombo.addItem("7");
		gridxCombo.addItem("8");
		gridxCombo.addItem("9");
		gridxCombo.addItem("10");

		gridyCombo.addItem("RELATIVE");
		gridyCombo.addItem("0");
		gridyCombo.addItem("1");
		gridyCombo.addItem("2");
		gridyCombo.addItem("3");
		gridyCombo.addItem("4");
		gridyCombo.addItem("5");
		gridyCombo.addItem("6");
		gridyCombo.addItem("7");
		gridyCombo.addItem("8");
		gridyCombo.addItem("9");
		gridyCombo.addItem("10");

		gridwidthCombo.addItem("RELATIVE");
		gridwidthCombo.addItem("REMAINDER");
		gridwidthCombo.addItem("1");
		gridwidthCombo.addItem("2");
		gridwidthCombo.addItem("3");
		gridwidthCombo.addItem("4");
		gridwidthCombo.addItem("5");
		gridwidthCombo.addItem("6");
		gridwidthCombo.addItem("7");
		gridwidthCombo.addItem("8");
		gridwidthCombo.addItem("9");
		gridwidthCombo.addItem("10");

		gridheightCombo.addItem("RELATIVE");
		gridheightCombo.addItem("REMAINDER");
		gridheightCombo.addItem("1");
		gridheightCombo.addItem("2");
		gridheightCombo.addItem("3");
		gridheightCombo.addItem("4");
		gridheightCombo.addItem("5");
		gridheightCombo.addItem("6");
		gridheightCombo.addItem("7");
		gridheightCombo.addItem("8");
		gridheightCombo.addItem("9");
		gridheightCombo.addItem("10");
	}
	public void setGridx(int gridx) {
		if(gridx == GridBagConstraints.RELATIVE)
			gridxCombo.setSelectedItem("RELATIVE");
		else
			gridxCombo.setSelectedIndex(gridx+1);
		repaint();
	}
	public void setGridy(int gridy) {
		if(gridy == GridBagConstraints.RELATIVE)
			gridyCombo.setSelectedItem("RELATIVE");
		else
			gridyCombo.setSelectedIndex(gridy+1);
		repaint();
	}
	public void setGridheight(int gridheight) {
		if(gridheight == GridBagConstraints.RELATIVE)
			gridheightCombo.setSelectedItem("RELATIVE");
		else if(gridheight == GridBagConstraints.REMAINDER)
			gridheightCombo.setSelectedItem("REMAINDER");
		else	
			gridheightCombo.setSelectedIndex(gridheight+1);
	}
	public void setGridwidth(int gridwidth) {
		if(gridwidth == GridBagConstraints.RELATIVE)
			gridwidthCombo.setSelectedItem("RELATIVE");
		else if(gridwidth == GridBagConstraints.REMAINDER)
			gridwidthCombo.setSelectedItem("REMAINDER");
		else	
			gridwidthCombo.setSelectedIndex(gridwidth+1);
	}
	public int getGridx() {
		String x = (String)gridxCombo.getSelectedItem();
		int rv;

		if(x.equals("RELATIVE"))
			rv = GridBagConstraints.RELATIVE;
		else {
			rv = Integer.parseInt(
					(String)gridxCombo.getSelectedItem());
		}
		return rv;
	}
	public int getGridy() {
		String y = (String)gridyCombo.getSelectedItem();
		int rv;

		if(y.equals("RELATIVE"))
			rv = GridBagConstraints.RELATIVE;
		else {
			rv = Integer.parseInt(
					(String)gridyCombo.getSelectedItem());
		}
		return rv;
	}
	public int getGridwidth() {
		String width = (String)gridwidthCombo.getSelectedItem();
		int rv;

		if(width.equals("RELATIVE"))
			rv = GridBagConstraints.RELATIVE;
		else if(width.equals("REMAINDER"))
			rv = GridBagConstraints.REMAINDER;
		else {
			rv = Integer.parseInt(
					(String)gridwidthCombo.getSelectedItem());
		}
		return rv;
	}
	public int getGridheight() {
		String height = (String)gridheightCombo.getSelectedItem();
		int rv;

		if(height.equals("RELATIVE"))
			rv = GridBagConstraints.RELATIVE;
		else if(height.equals("REMAINDER"))
			rv = GridBagConstraints.REMAINDER;
		else {
			rv = Integer.parseInt(
					(String)gridheightCombo.getSelectedItem());
		}
		return rv;
	}
}
class AnchorFillWeightPanel extends JPanel {
	JLabel		anchorLabel = new JLabel("Anchor:"),
				fillLabel 	= new JLabel("Fill:"),
				weightxLabel = new JLabel("weightx:"),
				weightyLabel = new JLabel("weighty:");

	JComboBox  	anchorCombo = new JComboBox(),
				fillCombo 	= new JComboBox();

	JComboBox	weightxCombo = new JComboBox(),
				weightyCombo = new JComboBox();

	public AnchorFillWeightPanel() {
		anchorCombo.addItem("NORTH");
		anchorCombo.addItem("NORTHEAST");
		anchorCombo.addItem("EAST");
		anchorCombo.addItem("SOUTHEAST");
		anchorCombo.addItem("SOUTH");
		anchorCombo.addItem("SOUTHWEST");
		anchorCombo.addItem("WEST");
		anchorCombo.addItem("NORTHWEST");
		anchorCombo.addItem("CENTER");

		weightxCombo.addItem("0.0");
		weightxCombo.addItem("0.1");
		weightxCombo.addItem("0.2");
		weightxCombo.addItem("0.25");
		weightxCombo.addItem("0.3");
		weightxCombo.addItem("0.4");
		weightxCombo.addItem("0.5");
		weightxCombo.addItem("0.6");
		weightxCombo.addItem("0.7");
		weightxCombo.addItem("0.75");
		weightxCombo.addItem("0.8");
		weightxCombo.addItem("0.9");
		weightxCombo.addItem("1.0");

		weightyCombo.addItem("0.0");
		weightyCombo.addItem("0.1");
		weightyCombo.addItem("0.2");
		weightyCombo.addItem("0.25");
		weightyCombo.addItem("0.3");
		weightyCombo.addItem("0.4");
		weightyCombo.addItem("0.5");
		weightyCombo.addItem("0.6");
		weightyCombo.addItem("0.7");
		weightyCombo.addItem("0.75");
		weightyCombo.addItem("0.8");
		weightyCombo.addItem("0.9");
		weightyCombo.addItem("1.0");

		fillCombo.addItem("NONE");
		fillCombo.addItem("HORIZONTAL");
		fillCombo.addItem("VERTICAL");
		fillCombo.addItem("BOTH");

		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();

		setLayout(gbl);
		gbc.anchor = GridBagConstraints.NORTHWEST;

		add(anchorLabel, gbc);
		add(Box.createHorizontalStrut(10), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.weightx = 1.0;
		add(anchorCombo, gbc);
		gbc.weightx = 0;
		add(Box.createVerticalStrut(3), gbc);

		gbc.gridwidth = 1;
		add(fillLabel, gbc);
		add(Box.createHorizontalStrut(10), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.weightx = 1.0;
		add(fillCombo, gbc);
		gbc.weightx = 0;
		add(Box.createVerticalStrut(13), gbc);

		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.WEST;
		add(weightxLabel, gbc);
		add(Box.createHorizontalStrut(10), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.weightx = 1.0;
		add(weightxCombo, gbc);
		gbc.weightx = 0;
		add(Box.createVerticalStrut(3), gbc);

		gbc.gridwidth = 1;
		add(weightyLabel, gbc);
		add(Box.createHorizontalStrut(10), gbc);
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.weightx = 1.0;
		add(weightyCombo, gbc);
		gbc.weightx = 0;
		gbc.gridwidth = 1;

		setBorder(new CompoundBorder(
				BorderFactory.createTitledBorder(
					"Anchor, Fill and Weight"),
				BorderFactory.createEmptyBorder(10,10,10,10)));
	}
	public Double getWeightx() {
		return Double.valueOf(
					(String)weightxCombo.getSelectedItem());
	}
	public Double getWeighty() {
		return Double.valueOf(
					(String)weightyCombo.getSelectedItem());
	}
	public void setWeightx(Double d) {
		weightxCombo.setSelectedItem(d.toString());
	}
	public void setWeighty(Double d) {
		weightyCombo.setSelectedItem(d.toString());
	}
	public int getAnchor() {
		String index = (String)anchorCombo.getSelectedItem();
		int anchor = GridBagConstraints.NORTH;

		if("NORTH".equals(index))
			anchor = GridBagConstraints.NORTH;
		else if("NORTHEAST".equals(index))
			anchor = GridBagConstraints.NORTHEAST;
		else if("NORTHWEST".equals(index))
			anchor = GridBagConstraints.NORTHWEST;
		else if("EAST".equals(index))
			anchor = GridBagConstraints.EAST;
		else if("SOUTHEAST".equals(index))
			anchor = GridBagConstraints.SOUTHEAST;
		else if("SOUTH".equals(index))
			anchor = GridBagConstraints.SOUTH;
		else if("SOUTHWEST".equals(index))
			anchor = GridBagConstraints.SOUTHWEST;
		else if("WEST".equals(index))
			anchor = GridBagConstraints.WEST;
		else if("CENTER".equals(index))
			anchor = GridBagConstraints.CENTER;

		return anchor;
	}
	public int getFill() {
		String index = (String)fillCombo.getSelectedItem();
		int fill = GridBagConstraints.NONE;

		if("NONE".equals(index))
			fill = GridBagConstraints.NONE;
		else if("HORIZONTAL".equals(index))
			fill = GridBagConstraints.HORIZONTAL;
		else if("VERTICAL".equals(index))
			fill = GridBagConstraints.VERTICAL;
		else if("BOTH".equals(index))
			fill = GridBagConstraints.BOTH;

		return fill;
	}
	public void setAnchor(int anchor) {
		if(anchor == GridBagConstraints.NORTH)
			anchorCombo.setSelectedItem("NORTH");
		else if(anchor == GridBagConstraints.NORTHEAST)
			anchorCombo.setSelectedItem("NORTHEAST");
		else if(anchor == GridBagConstraints.NORTHWEST)
			anchorCombo.setSelectedItem("NORTHWEST");
		else if(anchor == GridBagConstraints.SOUTH)
			anchorCombo.setSelectedItem("SOUTH");
		else if(anchor == GridBagConstraints.SOUTHEAST)
			anchorCombo.setSelectedItem("SOUTHEAST");
		else if(anchor == GridBagConstraints.SOUTHWEST)
			anchorCombo.setSelectedItem("SOUTHWEST");
		else if(anchor == GridBagConstraints.EAST)
			anchorCombo.setSelectedItem("EAST");
		else if(anchor == GridBagConstraints.WEST)
			anchorCombo.setSelectedItem("WEST");
		else if(anchor == GridBagConstraints.CENTER)
			anchorCombo.setSelectedItem("CENTER");
	}
	public void setFill(int fill) {
		if(fill == GridBagConstraints.NONE)
			fillCombo.setSelectedItem("NONE");
		else if(fill == GridBagConstraints.HORIZONTAL)
			fillCombo.setSelectedItem("HORIZONTAL");
		else if(fill == GridBagConstraints.VERTICAL)
			fillCombo.setSelectedItem("VERTICAL");
		else if(fill == GridBagConstraints.BOTH)
			fillCombo.setSelectedItem("BOTH");
	}
}
