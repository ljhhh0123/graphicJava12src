import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	JWindow window = new JWindow();
	JMenuBar menuBar = new JMenuBar();
	JMenu fileMenu = new JMenu("File");
	JMenuItem quitItem;

	public Test() {
		final Container contentPane = getContentPane();
		JButton button = new JButton("show window ...");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);

		fileMenu.add("New");
		fileMenu.add("Open ...");
		fileMenu.add("Save");
		fileMenu.add("Save As ...");
		fileMenu.addSeparator();
		fileMenu.add(quitItem = new JMenuItem("Quit"));

		menuBar.add(fileMenu);

		window.getRootPane().setJMenuBar(menuBar);
		window.getRootPane().setBorder(
			BorderFactory.createRaisedBevelBorder());

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Point pt = contentPane.getLocation();

				SwingUtilities.convertPointToScreen(
												pt, contentPane);

				window.setBounds(pt.x + 10, pt.y + 10, 200, 200);
				window.show();

				quitItem.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						window.dispose();
					}
				});
			}
		});
	}
}
