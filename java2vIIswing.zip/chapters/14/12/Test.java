import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JButton button = new JButton("show dialog ...");
	private JButton applyButton = new JButton("Apply");
	private RotatePanel rotatePanel = new RotatePanel();
	private String title = "Rotate";
	private Object[] buttonRowObjects = new Object[] {
		"Ok", 
		applyButton,
		"Cancel",
	};

	public Test() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);

		applyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showStatus(rotatePanel.getSelectedAngle() + 
							" degrees");
			}
		});
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int value = JOptionPane.showOptionDialog(
						button, // parentComponent
						rotatePanel, // message
						title, // title
						JOptionPane.DEFAULT_OPTION, // optionType
						JOptionPane.PLAIN_MESSAGE, // messageType
						null, // icon
						buttonRowObjects, // options
						applyButton); // initialValue 

				switch(value) {
					case JOptionPane.CLOSED_OPTION:
						showStatus(
								"Dialog closed with close box");
						break;
					case JOptionPane.OK_OPTION:
						showStatus("Ok button activated:  " +
								rotatePanel.getSelectedAngle() +
								" degrees");
						break;
					case JOptionPane.CANCEL_OPTION:
						showStatus("Cancel button activated");
						break;
				}
			}
		});
	}
}
class RotatePanel extends JPanel { 
	private ButtonGroup group = new ButtonGroup();

	private JRadioButton[] buttons = {
		new JRadioButton("0"),
		new JRadioButton("90"),
		new JRadioButton("180"),
		new JRadioButton("270"),
	};
	public RotatePanel() {
		setBorder(BorderFactory.createTitledBorder("Angle:"));

		for(int i=0; i < buttons.length; ++i) {
			if(i ==0)
				buttons[i].setSelected(true);

			add(buttons[i]);
			group.add(buttons[i]);
		}
	}
	public String getSelectedAngle() {
		String rv = null;  // rv = return value

		for(int i=0; i < buttons.length; ++i) {
			if(buttons[i].isSelected())
				rv = buttons[i].getText();
		}
		return rv;
	}
}
