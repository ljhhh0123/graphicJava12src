import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JButton topButton = new JButton(
					"show dialog created from option pane");
	private JButton bottomButton = new JButton(
					"show dialog created with static method");

	private String title = "dialog title";
	private String message = "message";

	public Test() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(topButton);
		contentPane.add(bottomButton);

		topButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane optionPane = new JOptionPane(
				  message, // message
				  JOptionPane.INFORMATION_MESSAGE); // messageType

				JDialog dialog = optionPane.createDialog(
				  topButton, // parentComponent
				  title); // title

				dialog.show();
			}
		});
		bottomButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(
				  bottomButton, // parentComponent
				  message, // message
				  title, // title
				  JOptionPane.INFORMATION_MESSAGE); // messageType
			}
		});
	}
}
