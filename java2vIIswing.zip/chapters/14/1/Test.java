import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

// This has been modified from the code in the book
// to display the animated swing.gif in a window in the corner
// of your desktop. A double click closes the window.

public class Test extends JFrame {
	Toolkit toolkit = Toolkit.getDefaultToolkit();
	JWindow window = new JWindow();
	JLabel label = new JLabel(new ImageIcon("swing.gif"));

	static public void main(String[] args) {
		JFrame frame = new Test();
	}
	public Test() {
		//label.setBorder(BorderFactory.createRaisedBevelBorder());
		window.getContentPane().add(label, "Center");
		//centerWindow();
		// change location to suite taste ...
		window.setLocation(75,10);
		window.pack();
		window.show();

		window.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if(e.getClickCount() == 2) {
					window.dispose();
					System.exit(0);
				}
			}
		});
	}
	private void centerWindow() {
		Dimension scrnSize  = toolkit.getScreenSize();
		Dimension labelSize = label.getPreferredSize();
		int       labelWidth  = labelSize.width,
		          labelHeight = labelSize.height;

		window.setLocation(scrnSize.width/2  - (labelWidth/2),
		                   scrnSize.height/2 - (labelHeight/2));
		window.pack();
	}
}
