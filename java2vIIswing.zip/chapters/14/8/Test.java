import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JButton button = new JButton("show dialog ...");

	private String title = "Unsaved Changes";
	private String message[] = {
					"Unsaved Changes in File:  dialog.fm",
					" ",
					"Save before closing?",
					" ",
	};

	public Test() {
		Container contentPane = getContentPane();

		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(
				  button, // parentComponent
				  message, // message
				  title, // title
				  JOptionPane.YES_NO_CANCEL_OPTION, // optionType
				  JOptionPane.WARNING_MESSAGE, // messageType
				  new ImageIcon("punch.gif")); // icon

				switch(result) {
					case JOptionPane.CLOSED_OPTION: 
							showStatus("Dialog Closed");
							break;
					case JOptionPane.YES_OPTION: 
							showStatus("Yes");
							break;
					case JOptionPane.NO_OPTION: 
							showStatus("No");
							break;
					case JOptionPane.CANCEL_OPTION:
							showStatus("Cancel");
							break;
				}
			}
		});
	}
}
