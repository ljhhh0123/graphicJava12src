import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	JTextField tf = new JTextField(DateDocument.initString);

	public Test() {
		Container contentPane = getContentPane();
		JLabel label = new JLabel("Date:");
		Font font = new Font("Dialog", Font.PLAIN, 24);

		tf.setFont(font);
		label.setFont(font);

		tf.setDocument(new DateDocument(tf));

		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER,
											 10,10));	
		contentPane.add(label);
		contentPane.add(tf);
	}
}
class DateDocument extends PlainDocument {
	public static String initString = "XX/XX/XXXX"; // Y10K!
	private static int sep1 = 2, sep2 = 5;
	private JTextComponent textComponent;
	private int newOffset;

	public DateDocument(JTextComponent tc) {
		textComponent = tc;
		try {
			insertString(0, initString, null);
		}
		catch(Exception ex) { ex.printStackTrace(); }
	}
	public void insertString(int offset, String s, 
							AttributeSet attributeSet) 
							throws BadLocationException {
		if(s.equals(initString)) {
			super.insertString(offset, s, attributeSet);
		}
		else {
			try {
				Integer.parseInt(s);
			}
			catch(Exception ex) {
				return;  // only allow integer values
			}

			newOffset = offset;

			if(atSeparator(offset)) {
				newOffset++;	
				textComponent.setCaretPosition(newOffset);
			}
			super.remove(newOffset, 1);
			super.insertString(newOffset, s, attributeSet);
		}
	}
	public void remove(int offset, int length) 
							throws BadLocationException {
		if(atSeparator(offset)) 
			textComponent.setCaretPosition(offset-1);
		else
			textComponent.setCaretPosition(offset);
	}
	private boolean atSeparator(int offset) {
		return offset == sep1 || offset == sep2;
	}
}
