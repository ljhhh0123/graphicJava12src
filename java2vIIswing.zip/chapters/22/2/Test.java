import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	private JTextField textField = new JTextField(
		"12345678901234567890123456789012345678901234567890", 10);

	public void init() {
		Container contentPane = getContentPane();
		JPanel textFieldPanel = new JPanel();

		textFieldPanel.add(textField);

		contentPane.add(new ControlPanel(), BorderLayout.NORTH);
		contentPane.add(textFieldPanel, BorderLayout.CENTER);
	}
	class ControlPanel extends JPanel {
		private JLabel display = new JLabel(" ");
		private JSlider slider = new JSlider(
							textField.getHorizontalVisibility());
		private JComboBox columns = new JComboBox();

		public ControlPanel() {
			columns.addItem(new Integer(0));
			columns.addItem(new Integer(5));
			columns.addItem(new Integer(10));
			columns.addItem(new Integer(15));

			columns.setSelectedIndex(2);

			add(new JLabel("Scroll Offset:"));
			add(slider);
			add(display);
			add(Box.createHorizontalStrut(10));
			add(new JLabel("Columns:"));
			add(columns);

			slider.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					textField.setScrollOffset(slider.getValue());

					Integer i = 
						new Integer(textField.getScrollOffset());
					BoundedRangeModel m =
							textField.getHorizontalVisibility();
						
					display.setText(i.toString());

					showStatus("Visibility -  min: " + 
							   m.getMinimum() + 
							   ", max: " + m.getMaximum() +
							   ", extent: " + m.getExtent() + 
							   ", value: " + m.getValue() +
							   ", isAdj: " + 
							   m.getValueIsAdjusting());
				}
			});
			columns.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Integer c = 
						(Integer)columns.getSelectedItem();

					textField.setColumns(c.intValue());

					// the following call to revalidate()
					// should not be necessary
					revalidate();

					textField.setScrollOffset(0);
				}
			});
		}
	}
}
