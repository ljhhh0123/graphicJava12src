import java.io.File;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.FileReader;

public class Test extends JFrame {
	private JTextPane textPane = new JTextPane();

	private JMenuBar menubar = new JMenuBar();
	private JToolBar toolbar = new JToolBar();

	private Hashtable actionTable = new Hashtable();

	private String[] cutCopyPasteActionNames = new String[] {
		DefaultEditorKit.cutAction, "Cut", "cut.gif",
		DefaultEditorKit.copyAction, "Copy", "copy.gif",
		DefaultEditorKit.pasteAction, "Paste", "paste.gif",
	};

	private String[] familyActionNames = new String[] {
		"font-family-SansSerif", "SanSerif",
		"font-family-Monospaced", "Monospaced",
		"font-family-Serif", "Serif",
	};
	private String[] styleActionNames = new String[] {
		"font-italic", "Italic", "italic.gif",
		"font-bold", "Bold", "bold.gif",
		"font-underline", "Underline", "underline.gif",
	};
	private String[] sizeActionNames = new String[] {
		"font-size-8",  "8",  "font-size-10", "10", 
		"font-size-12", "12", "font-size-14", "14", 
		"font-size-16", "16", "font-size-18", "18", 
		"font-size-24", "24", "font-size-36", "36", 
		"font-size-48", "48", 
	};

	public Test() {
		Container contentPane = getContentPane();
		JScrollPane scrollPane = new JScrollPane(textPane);

		loadActionTable();
		populate();
		readFile();
		setJMenuBar(menubar);

		contentPane.add(toolbar, BorderLayout.NORTH);
		contentPane.add(new JScrollPane(textPane), 
						BorderLayout.CENTER);
	}
	private void readFile() {
		try {
			textPane.getEditorKit().read(
			  new FileReader("text"), textPane.getDocument(), 0);
		}
		catch(Exception ex) { ex.printStackTrace(); }
	}
	private void populate() {
		JMenu editMenu = new JMenu("Edit"),
			  fontMenu = new JMenu("Font"),
			  styleMenu = new JMenu("Style"),
			  sizeMenu = new JMenu("Size"),
			  familyMenu = new JMenu("Family");

		for(int i=0; i < familyActionNames.length; ++i) {
			Action action = getAction(familyActionNames[i]);
			if(action != null) {
				JMenuItem item = familyMenu.add(action);
				item.setText(familyActionNames[++i]);
			}
		}
		for(int i=0; i < sizeActionNames.length; ++i) {
			Action action = getAction(sizeActionNames[i]);
			if(action != null) {
				JMenuItem item = sizeMenu.add(action);
				item.setText(sizeActionNames[++i]);
			}
		}
		for(int i=0; i < cutCopyPasteActionNames.length; ++i) {
			Action action = getAction(cutCopyPasteActionNames[i]);

			if(action != null) {
				JButton button = toolbar.add(action);
				JMenuItem item = editMenu.add(action);

				item.setText(cutCopyPasteActionNames[++i]);

				button.setText(null);
				button.setIcon(new ImageIcon(
								   cutCopyPasteActionNames[++i]));
			}
		}

		editMenu.addSeparator();
		toolbar.addSeparator();

		for(int i=0; i < styleActionNames.length; ++i) {
			Action action = getAction(styleActionNames[i]);

			if(action != null) {
				JButton button = toolbar.add(action);
				JMenuItem item = styleMenu.add(action);
								
				item.setText(styleActionNames[++i]);

				button.setText(null);
				button.setIcon(
							new ImageIcon(styleActionNames[++i]));
			}
		}
		fontMenu.add(familyMenu);
		fontMenu.add(styleMenu);
		fontMenu.add(sizeMenu);

		editMenu.add(fontMenu);
		menubar.add(editMenu);
	}
	private void loadActionTable() {
		Action[] actions = textPane.getActions();

		for(int i=0; i < actions.length; ++i) {
			actionTable.put(actions[i].getValue(Action.NAME),
							actions[i]);
		}
	}
	private Action getAction(String name) {
		return (Action)actionTable.get(name);
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
			"Using JTextPane",300,300,450,300);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	static {
		resources = ResourceBundle.getBundle(
					"GJApp", Locale.getDefault());
	};

	private GJApp() {}
	
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
