import java.applet.Applet;
import java.awt.*;
import javax.swing.*;

public class PurchaseApplet extends JApplet {
	public void init() {
		getContentPane().add(new ButtonPurchaseForm(),
								BorderLayout.CENTER);
	}
}
class ButtonPurchaseForm extends JPanel {
    JSeparator sep = new JSeparator();
    JLabel title   = new JLabel("Order Form");
    JLabel name    = new JLabel("Name:");
    JLabel address = new JLabel("Address:");
    JLabel payment = new JLabel("Purchase Method:");
    JLabel phone   = new JLabel("Phone:");
    JLabel city    = new JLabel("City:");
    JLabel state   = new JLabel("State:");

    JTextField nameField    = new JTextField(25);
    JTextField addressField = new JTextField(25);
    JTextField cityField    = new JTextField(15);
    JTextField stateField   = new JTextField(2);

    JComboBox paymentChoice = new JComboBox();

    JButton paymentButton = new JButton("Purchase");
    JButton cancelButton   = new JButton("Cancel");

    public ButtonPurchaseForm() {
        GridBagLayout      gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();


        setLayout(gbl);

        paymentChoice.addItem("Visa");
        paymentChoice.addItem("MasterCard");
        paymentChoice.addItem("COD");

        title.setFont(new Font("Times-Roman", 
                               Font.BOLD + Font.ITALIC,
                               16));

        gbc.anchor    = GridBagConstraints.NORTHWEST;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        add(title, gbc);

        gbc.anchor    = GridBagConstraints.NORTH;
        gbc.fill      = GridBagConstraints.HORIZONTAL;
        gbc.insets    = new Insets(0,0,10,0);
        add(sep, gbc);

        gbc.anchor    = GridBagConstraints.WEST;
        gbc.gridwidth = 1;
        gbc.insets    = new Insets(0,0,0,0);
        add(name, gbc);

		add(Box.createHorizontalStrut(10));
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        add(nameField, gbc);

        gbc.gridwidth = 1;
        add(address, gbc);

		add(Box.createHorizontalStrut(10));
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        add(addressField, gbc);

        gbc.gridwidth = 1;
        add(city, gbc);

		add(Box.createHorizontalStrut(10));
        add(cityField, gbc);
		add(Box.createHorizontalStrut(10));
        add(state, gbc);
		add(Box.createHorizontalStrut(5));

        gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.fill = GridBagConstraints.NONE;
        add(stateField, gbc);

        gbc.gridwidth = 1;
        add(payment, gbc);

        gbc.insets = new Insets(5,0,5,0);

		add(Box.createHorizontalStrut(10));
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill      = GridBagConstraints.NONE;
        add(paymentChoice, gbc);

        ButtonPanel buttonPanel = new ButtonPanel();

        buttonPanel.add(paymentButton);
        buttonPanel.add(cancelButton);

        gbc.anchor    = GridBagConstraints.SOUTH;
        gbc.insets    = new Insets(15,0,0,0);
        gbc.fill      = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 7;
        add(buttonPanel, gbc);
    }
	class ButtonPanel extends JPanel {
		JPanel  buttonPanel = new JPanel();
	    JSeparator separator = new JSeparator();

	    public ButtonPanel() {
			buttonPanel.setLayout(
							new FlowLayout(FlowLayout.CENTER));

	        setLayout(new BorderLayout(0,5));
	        add(separator, "North");
	        add(buttonPanel, "Center");
	    }
	    public void add(JButton button) {
	        buttonPanel.add(button);
	    }
	}
}
