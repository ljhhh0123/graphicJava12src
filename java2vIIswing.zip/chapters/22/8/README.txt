This application works as advertised, but throws exceptions due
to a bug.
