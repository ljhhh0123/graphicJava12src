import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JApplet {
	private JPanel textFieldPanel = new JPanel();
	private JTextField textField = 
					new JTextField("initial content");

	public void init() {
		Container contentPane = getContentPane();

		textFieldPanel.add(textField);

		contentPane.setLayout(new BorderLayout(0,20));
		contentPane.add(new ControlPanel(), BorderLayout.NORTH);
		contentPane.add(textFieldPanel, BorderLayout.CENTER);
	}
	class ControlPanel extends JPanel {
		private JComboBox alignments = new JComboBox();
		private JComboBox columns = new JComboBox();

		public ControlPanel() {
			columns.addItem(new Integer(0));
			columns.addItem(new Integer(5));
			columns.addItem(new Integer(10));
			columns.addItem(new Integer(15));

			alignments.addItem("LEFT");			
			alignments.addItem("CENTER");			
			alignments.addItem("RIGHT");			

			add(new JLabel("Horizontal Alignment:"));
			add(alignments);
			add(Box.createHorizontalStrut(10));
			add(new JLabel("Columns:"));
			add(columns);

			columns.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Integer c = 
						(Integer)columns.getSelectedItem();

					textField.setColumns(c.intValue());

					// the following call to revalidate()
					// should not be necessary
					revalidate();

					textField.setScrollOffset(0);
				}
			});
			alignments.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int index = alignments.getSelectedIndex();

					if(index == 0)
						textField.setHorizontalAlignment(
											JTextField.LEFT);
					else if(index == 1)
						textField.setHorizontalAlignment(
											JTextField.CENTER);
					else if(index == 2)
						textField.setHorizontalAlignment(
											JTextField.RIGHT);
				}
			});
		}
	}
}
