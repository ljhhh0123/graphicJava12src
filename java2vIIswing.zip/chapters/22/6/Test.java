import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JApplet {
	private String pw = "dol42ce";
	private JPasswordField passwordField = new JPasswordField(8);

	public void init() {
		Container contentPane = getContentPane();
		JPanel panel = new JPanel();

		panel.add(new JLabel("Password:"));
		panel.add(passwordField);

		passwordField.setEchoChar('?');

		contentPane.add(panel, BorderLayout.CENTER);

		passwordField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String password = new String(
								  passwordField.getPassword());

				if(pw.equals(password))
					showStatus("Access Granted");
				else
					showStatus("Wrong password - security " +
							   "has been called");
			}
		});
	}
}
