import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JFrame {
	private JTextField field = new JTextField(10);
	private JButton b = new JButton("Default Button");
	private JCheckBox cb = new JCheckBox(
								"Text field fires action event");
	public Test() {
		Container contentPane = getContentPane();

		SwingUtilities.getRootPane(this).setDefaultButton(b);
		cb.setSelected(true);

		contentPane.setLayout(new FlowLayout(
										FlowLayout.CENTER,10,20));
		contentPane.add(field);
		contentPane.add(b);
		contentPane.add(cb);

		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(Test.this,
					"Button fired action event");
			}
		});
		field.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(Test.this,
					"Textfield fired action event");
			}
		});
		cb.addActionListener(new ActionListener() {
			private Keymap km;
			private KeyStroke ks;
			private Action action;

			public void actionPerformed(ActionEvent e) {
				if(cb.isSelected()) {
					km.addActionForKeyStroke(ks, action);
				}
				else {
					if(ks == null) {
						km = field.getKeymap();
						ks = KeyStroke.getKeyStroke(
										KeyEvent.VK_ENTER, 0);
						action = km.getAction(ks);
					}
					km.removeKeyStrokeBinding(ks);
				}
			}
		});
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
			"Default Buttons",300,300,350,200);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
