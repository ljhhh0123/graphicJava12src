import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test implements ActionListener {
	private int seconds=1;

	public Test() {
		Timer oneSecondTimer = new Timer(1000, this);
		Timer timerWithInitialDelay = new Timer(2000, 
								new TimerWithDelayListener());
		Timer oneTimeTimer = new Timer(10000, 
								new OneTimeListener());

		timerWithInitialDelay.setInitialDelay(5000);
		oneTimeTimer.setRepeats(false);

		oneSecondTimer.start();
		timerWithInitialDelay.start();
		oneTimeTimer.start();
	}
	public void actionPerformed(ActionEvent e) {
		if(seconds == 0)
			System.out.println("Time:  " + seconds + " second");
		else
			System.out.println("Time:  " + seconds + " seconds");

		seconds++;
	}
	public static void main(String args[]) {
		new Test();
		while(true);
	}
}
class TimerWithDelayListener implements ActionListener { 
	public void actionPerformed(ActionEvent e) {
		System.out.println("Timer with Delay Ringing");
	}
}
class OneTimeListener implements ActionListener { 
	public void actionPerformed(ActionEvent e) {
		System.out.println("One Time Timer Ringing");
	}
}
