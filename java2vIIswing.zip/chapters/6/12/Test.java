import javax.swing.*;
import javax.swing.undo.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	private JPanel colorPanel = new JPanel();
	private BackgroundColorEdit undo = new BackgroundColorEdit();
	private Color oldColor;

	public void init() {
		colorPanel.setBorder(
			BorderFactory.createTitledBorder(
				"Change color and subsequently undo " +
				"from the Edit menu"));

		makeMenuBar();
		getContentPane().add(colorPanel, BorderLayout.CENTER);
	}
	private void makeMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenu editMenu = new JMenu("Edit");

		editMenu.add(new SetColorAction());
		editMenu.add(new UndoAction());

		menuBar.add(editMenu);
		setJMenuBar(menuBar);
	}
	class SetColorAction extends AbstractAction {
		public SetColorAction() {
			super("Set color ...");
		}
		public void actionPerformed(ActionEvent e) {
			Color color = JColorChooser.showDialog(
							Test.this, // parent component
							"Pick A Color", // dialog title
							null); // initial color

			if(color != null) { 
				oldColor = colorPanel.getBackground();
				colorPanel.setBackground(color);
			}
		}
	}
	class UndoAction extends AbstractAction {
		public UndoAction() {
			putValue(Action.NAME, undo.getUndoPresentationName());
		}
		public void actionPerformed(ActionEvent e) {
			String name = (String)getValue(Action.NAME);
			boolean isUndo = name.equals(
								  undo.getUndoPresentationName());

			if(isUndo) {
				undo.undo();	
				putValue(Action.NAME,
						 undo.getRedoPresentationName());
			}
			else {
				undo.redo();	
				putValue(Action.NAME,
						 undo.getUndoPresentationName());
			}
		}
	}
	class BackgroundColorEdit extends AbstractUndoableEdit {
		public void undo() throws CannotUndoException {
			super.undo();
			toggleColor();
		}
		public void redo() throws CannotRedoException {
			super.redo();
			toggleColor();
		}
		public String getUndoPresentationName() {
			return "Undo";
		}
		public String getRedoPresentationName() {
			return "Redo";
		}
		private void toggleColor() {
			Color color = colorPanel.getBackground();
			colorPanel.setBackground(oldColor);
			oldColor = color;
		}
	}
}
