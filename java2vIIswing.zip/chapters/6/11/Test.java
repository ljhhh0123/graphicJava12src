import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class Test extends JFrame {
	private ProgressMonitorInputStream in;
	private JButton readButton = new JButton("read file");

	public Test() {
		final Container contentPane = getContentPane();
		final String fileName = "Test.java";

		contentPane.setLayout(new FlowLayout());
		contentPane.add(readButton);

		readButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					in = new ProgressMonitorInputStream(
						contentPane,
						"Reading " + fileName,
						new FileInputStream(fileName));
				}
				catch(FileNotFoundException ex) {
					ex.printStackTrace();
				}

				ReadThread t = new ReadThread();
				readButton.setEnabled(false);
				t.start();
			}
		});
	}
	class ReadThread extends Thread {
		public void run() {
			int i;

			try {
				while((i = in.read()) != -1) {
					System.out.print((char)i);
					try {
						Thread.currentThread().sleep(10);
					}
					catch(Exception ex) {
						ex.printStackTrace();
					}
				}
				in.close();
			}
			catch(IOException ex) {
				JOptionPane.showMessageDialog(
							Test.this,
							"Operation Canceled!",
							"Cancellation",
							JOptionPane.ERROR_MESSAGE);
			}
			readButton.setEnabled(true);
		}
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
					"Using ProgressMonitorInputStream",
					300,300,450,300);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
