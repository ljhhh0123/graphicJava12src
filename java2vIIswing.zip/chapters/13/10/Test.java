import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class Test extends JApplet {
	private JTextArea textArea = new JTextArea();

	public void init() {
		Container contentPane = getContentPane();

		readFile();

		contentPane.add(new ControlPanel(), BorderLayout.NORTH);
		contentPane.add(new JScrollPane(textArea), 
						BorderLayout.CENTER);
	}
	private void readFile() {
		DefaultEditorKit kit = new DefaultEditorKit();

		try {
			kit.read(new FileReader("Test.java"),
					 textArea.getDocument(), 0);
		}
		catch(Exception ex) { ex.printStackTrace(); }
	}
	class ControlPanel extends JPanel { 
		public ControlPanel() {
			final JCheckBox cb = new JCheckBox("wrap");

			add(cb);

			cb.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					if(cb.isSelected())
						textArea.setLineWrap(true);
					else
						textArea.setLineWrap(false);
				}
			});
		}
	}
}
