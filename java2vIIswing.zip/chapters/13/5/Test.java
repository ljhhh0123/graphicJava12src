import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JLabel view = new JLabel(new ImageIcon("cutlery.jpg",
									 "A picture of cutlery"));
		JScrollPane sp = new JScrollPane(view);

		contentPane.add(sp);
	}
}
