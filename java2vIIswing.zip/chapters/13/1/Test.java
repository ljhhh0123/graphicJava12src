import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JViewport viewport = new JViewport();
		JPanel view = new JPanel();

		view.add(new JLabel(
					new ImageIcon("anjinAndMariko.gif")));

		viewport.setView(view);

		contentPane.add(new ControlPanel(viewport), 
						BorderLayout.NORTH);
		contentPane.add(viewport, BorderLayout.CENTER);
	}
}
class ControlPanel extends JPanel { 
	private JViewport viewport;

	private JButton[] buttons = {
		new JButton("up"), new JButton("down"),
		new JButton("left"), new JButton("right")
	};

	public ControlPanel(JViewport vp) {
		viewport = vp;

		for(int i=0; i < buttons.length; ++i) {
			add(buttons[i]);

			buttons[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					scroll(e.getActionCommand());
				}
			});
		}
	}
	private void scroll(String actionCmd) {
		Point vp = viewport.getViewPosition();

		if(actionCmd.equals("up")) vp.y += 5;	
		else if(actionCmd.equals("down")) vp.y -= 5;	
		else if(actionCmd.equals("left")) vp.x += 5;	
		else if(actionCmd.equals("right")) vp.x -= 5;	

		viewport.setViewPosition(vp);
	}
}
