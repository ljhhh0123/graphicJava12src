import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JViewport columnHeaderViewport = new JViewport();
		JViewport rowHeaderViewport = new JViewport();

		JLabel columnHeaderView = new JLabel(
							new ImageIcon("horizontalRuler.jpg"));
		JLabel rowHeaderView = new JLabel(
							new ImageIcon("verticalRuler.jpg"));
		JLabel view = new JLabel(
							new ImageIcon("strawberry.jpg"));

		JScrollPane sp = new JScrollPane(view);

		sp.setToolTipText(
					"Drag the headers to drag the picture!");

		HeaderViewDragListener verticalHeaderListener = 
					new HeaderViewDragListener(sp, 
								SwingConstants.VERTICAL);

		HeaderViewDragListener horizontalHeaderListener = 
					new HeaderViewDragListener(sp, 
								SwingConstants.HORIZONTAL);

		columnHeaderViewport.addMouseListener(
										horizontalHeaderListener);
		columnHeaderViewport.addMouseMotionListener(
										horizontalHeaderListener);

		rowHeaderViewport.addMouseListener(
										verticalHeaderListener);
		rowHeaderViewport.addMouseMotionListener(
										verticalHeaderListener);

		// headers must be set before header views
		sp.setColumnHeader(columnHeaderViewport);
		sp.setRowHeader(rowHeaderViewport);

		sp.setColumnHeaderView(columnHeaderView);
		sp.setRowHeaderView(rowHeaderView);

		contentPane.add(sp);
	}
}
class HeaderViewDragListener extends MouseAdapter
								implements MouseMotionListener,
											SwingConstants {
	private Point last = new Point();
	private JScrollPane scrollpane; 
	private int orientation;

	public HeaderViewDragListener(JScrollPane sp, int orient) {
		scrollpane = sp;
		orientation = orient;
	}
	public void mousePressed(MouseEvent e) {
		last.x = e.getPoint().x;
		last.y = e.getPoint().y;
	}
	public void mouseMoved(MouseEvent e) {
	}
	public void mouseDragged(MouseEvent e) {
		JViewport headerViewport = (JViewport)e.getSource();
		JViewport scrollpaneViewport = scrollpane.getViewport();
		Dimension viewSize = scrollpaneViewport.getViewSize(),
				  extent = scrollpaneViewport.getExtentSize();

		Point drag = e.getPoint();
		Point offset = new Point(drag.x-last.x, drag.y-last.y);
		Point headerPosition = new Point(), viewportPosition;

		viewportPosition = scrollpaneViewport.getViewPosition();

		if(orientation == HORIZONTAL) {
			int nextX = viewportPosition.x - offset.x;
			int rightEdge = extent.width + nextX;

			if(nextX > 0 && rightEdge < viewSize.width) {
				headerPosition.x = nextX;
				viewportPosition.x = nextX;
			}
		}
		if(orientation == VERTICAL)  {	
			int nextY = viewportPosition.y - offset.y;
			int bottomEdge = extent.height + nextY;

			if(nextY > 0 && bottomEdge < viewSize.height) {
				headerPosition.y = nextY;
				viewportPosition.y = nextY;
			}
		}
		headerViewport.setViewPosition(headerPosition);
		scrollpaneViewport.setViewPosition(viewportPosition);

		last.x = drag.x;
		last.y = drag.y;
	}
}
