import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	private JButton buttons[] = {
		new JButton(), new JButton(), new JButton(),
		new JButton(), new JButton(), new JButton(),
		new JButton(), new JButton(), new JButton(),
		new JButton(), new JButton(), new JButton(),
		new JButton(), new JButton(), new JButton(),
		new JButton(), new JButton(), new JButton(),
	};
	public Test() {
		Container contentPane = getContentPane();
		JViewport viewport = new JViewport();
		JPanel view = new JPanel();
		JPanel controlPanel = new ControlPanel(buttons);

		view.setLayout(new GridLayout(0,3));

		for(int i=0; i < buttons.length; ++i) {
			buttons[i].setText("button # " + i);
			buttons[i].setPreferredSize(new Dimension(150,50));
			view.add(buttons[i]);
		}

		viewport.setView(view);

		contentPane.add(controlPanel, BorderLayout.NORTH);
		contentPane.add(viewport, BorderLayout.CENTER);
	}
}
class ControlPanel extends JPanel { 
	private JComboBox combo = new JComboBox();

	public ControlPanel(final JButton[] buttons) {
		add(combo);

		for(int i=0; i < buttons.length; ++i) {
			combo.addItem("button number " + i);
		}
		combo.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				int index = combo.getSelectedIndex();
				JButton button = buttons[index];
				Dimension size = button.getSize();

				buttons[index].scrollRectToVisible(
					new Rectangle(0,0, size.width,size.height));
			}
		});
	}
}
