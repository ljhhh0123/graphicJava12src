import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = new CustomContentPane();
		JLabel view1 = new JLabel(
							new ImageIcon("gjMedium.gif"));
		JLabel view2 = new JLabel(
							new ImageIcon("anjinAndMariko.gif"));

		JScrollPane sp1 = new JScrollPane(view1);
		JScrollPane sp2 = new JScrollPane(view2);

		setContentPane(contentPane);
		sp1.setPreferredSize(new Dimension(250,250));
		sp2.setPreferredSize(new Dimension(250,250));

		contentPane.add(sp1);
		contentPane.add(sp2);
	}
}
class CustomContentPane extends JPanel { 
	private ImageIcon rain = new ImageIcon("rain.gif");

	public CustomContentPane() {
		setLayout(new FlowLayout());
	}	
	public void paintComponent(Graphics g) {
		int rainw = rain.getIconWidth();
		int rainh = rain.getIconHeight();

		Dimension size = getSize();

		for(int row=0; row < size.height; row += rainh)
			for(int col=0; col < size.width; col += rainw)
				rain.paintIcon(this,g,col,row);
	}
}
