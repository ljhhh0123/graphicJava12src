import java.awt.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JLabel columnHeaderView = new JLabel(
							new ImageIcon("horizontalRuler.jpg",
										  "horizontal ruler"));
		JLabel rowHeaderView = new JLabel(
							new ImageIcon("verticalRuler.jpg",
										  "vertical ruler"));
		JLabel view = new JLabel(
							new ImageIcon("grapes.jpg",
										  "grapes"));

		JScrollPane sp = new JScrollPane(view);

		sp.setColumnHeaderView(columnHeaderView);
		sp.setRowHeaderView(rowHeaderView);

		sp.setViewportBorder(
						BorderFactory.createRaisedBevelBorder());

		contentPane.add(sp);
	}
}
