import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JLabel columnHeaderView = new JLabel(
							new ImageIcon("horizontalRuler.jpg"));
		JLabel rowHeaderView = new JLabel(
							new ImageIcon("verticalRuler.jpg"));
		JLabel view = new JLabel(
							new ImageIcon("anjinAndMariko.gif"));

		JScrollPane sp = new JScrollPane(view);

		JPanel corners[] = {
				new JPanel(), new JPanel(),
				new JPanel(), new JPanel()
		};
		String cornerConstants[] = {
			ScrollPaneConstants.UPPER_LEFT_CORNER,
			ScrollPaneConstants.LOWER_LEFT_CORNER,
			ScrollPaneConstants.UPPER_RIGHT_CORNER,
			ScrollPaneConstants.LOWER_RIGHT_CORNER,
		};
		Border border = BorderFactory.createEtchedBorder();

		for(int i=0; i < corners.length; ++i) {
			corners[i].setBorder(border);
			sp.setCorner(cornerConstants[i], corners[i]);
		}

		sp.setColumnHeaderView(columnHeaderView);
		sp.setRowHeaderView(rowHeaderView);
		contentPane.add(sp);
	}
}
