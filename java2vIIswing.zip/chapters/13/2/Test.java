import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JLabel label = new JLabel(new ImageIcon("pic.gif"));
		JViewport vp = new JViewport();
		ViewportDragListener listener = 
						new ViewportDragListener(vp);

		vp.setView(label);
		vp.addMouseListener(listener);
		vp.addMouseMotionListener(listener);

		contentPane.add(vp, BorderLayout.CENTER);
	}
}
class ViewportDragListener extends MouseAdapter
								implements MouseMotionListener {
	private JViewport viewport;
	private Point last = new Point(), scrollTo = new Point();

	public ViewportDragListener(JViewport viewport) {
		this.viewport = viewport;	
	}
	public void mousePressed(MouseEvent e) {
		last.x = e.getPoint().x;
		last.y = e.getPoint().y;
	}
	public void mouseMoved(MouseEvent e) {
	}
	public void mouseDragged(MouseEvent e) {
		Point drag = e.getPoint();
		Point viewPos = viewport.getViewPosition();
		Point offset = new Point(drag.x-last.x, drag.y-last.y);
		last.x = drag.x;
		last.y = drag.y;

		if(viewport.contains(drag)) {
			scrollTo.x = viewPos.x - offset.x;
			scrollTo.y = viewPos.y - offset.y;
			viewport.setViewPosition(scrollTo);
		}
	}
}
