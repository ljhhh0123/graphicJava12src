import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JScrollBar sb = new JScrollBar();

		contentPane.add(sb, BorderLayout.EAST);

		sb.addAdjustmentListener(new AdjustmentListener() {
			public void adjustmentValueChanged(
											AdjustmentEvent e) {
				JScrollBar jsb = (JScrollBar)e.getAdjustable();

				if(jsb.getValueIsAdjusting())
					showStatus("adjusting ...");
				else
					showStatus(Integer.toString(e.getValue()));
			}
		});
	}
}
