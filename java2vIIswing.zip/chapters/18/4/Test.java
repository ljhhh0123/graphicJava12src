import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class Test extends JApplet {
	private ColorKeySelectionManager ksm = 
								   new ColorKeySelectionManager();

	private JComboBox colorCombo = new JComboBox(new Object[] {
			new Item(new Object[] { Color.gray, "gray" }),
			new Item(new Object[] { Color.orange, "orange" }),
			new Item(new Object[] { Color.red, "red" }),
			new Item(new Object[] { Color.blue, "blue" }),
			new Item(new Object[] { Color.yellow, "yellow" }),
			new Item(new Object[] { Color.magenta, "magenta" }),
			new Item(new Object[] { Color.black, "black" }),
			new Item(new Object[] { Color.green, "green" }),
			new Item(new Object[] { Color.lightGray, "lightGray"})
	});
	public void init() {
		final Container contentPane = getContentPane();

		colorCombo.setRenderer(new ColorRenderer());
		colorCombo.setKeySelectionManager(ksm);

		contentPane.setLayout(new FlowLayout());
		contentPane.add(colorCombo);

		colorCombo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Item item = (Item)colorCombo.getSelectedItem();
				String itemString = item.toString();

				showStatus("'" + ksm.getSearchString() +
						   "'" + " is for " + itemString);
			}
		});
	}
}
class Item {
	private Color color;
	private String string;

	public Item(Object[] array) {
		color = (Color)array[0];
		string = (String)array[1];
	}
	public Color getColor() { return color; }
	public String toString() { return string; }
}
class ColorRenderer extends JLabel implements ListCellRenderer {
	private static ColorIcon icon = new ColorIcon();

	private Border 
		redBorder = BorderFactory.createLineBorder(Color.red,2),
		emptyBorder = BorderFactory.createEmptyBorder(2,2,2,2);

	public Component getListCellRendererComponent(
									JList list,
									Object value,
									int index,
									boolean isSelected,
									boolean cellHasFocus) {
		Item item = (Item)value;

		icon.setColor(item.getColor());
		setIcon(icon);
		setText(item.toString());

		if(isSelected) setBorder(redBorder);
		else 		   setBorder(emptyBorder);

		return this;
	}
}
class ColorIcon implements Icon {
	private Color color;
	private int w, h;

	public ColorIcon() {
		this(Color.gray, 50, 15);
	}
	public ColorIcon(Color color, int w, int h) {
		this.color = color;
		this.w = w;
		this.h = h;
	}
	public void paintIcon(Component c, Graphics g, int x, int y) {
		g.setColor(Color.black);
		g.drawRect(x, y, w-1, h-1);
		g.setColor(color);
		g.fillRect(x+1, y+1, w-2, h-2);
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public int getIconWidth() {
		return w;
	}
	public int getIconHeight() {
		return h;
	}
}
class ColorKeySelectionManager 
				implements JComboBox.KeySelectionManager {
	private String searchString = new String();
	private long lastTime;

	public int selectionForKey(char key,ComboBoxModel model) {
		updateSearchString(model, key);

		int start = getIndexAfter(model,getSelectedString(model));
		int selection = search(model, start);

		if(selection == -1 && start != 0)
			selection = search(model, 0);

		return selection;
	}
	public String getSearchString() {
		return searchString;
	}
	private int search(ComboBoxModel model, int start) {
		for(int i=start; i < model.getSize(); ++i) {
			String s = getString(model, i);
			int searchLength = searchString.length();

			if(s.regionMatches(0,searchString,0,searchLength))
				return i;
		}
		return -1;
	}
	private int getIndexAfter(ComboBoxModel model, String find) {
		int size = model.getSize();

		if(find != null) {
			for(int i=0; i < size; ++i) {
				String s = getString(model, i);

				if(s.compareToIgnoreCase(find) == 0) {
					return (i == size-1) ? 0 : i + 1;
				}
			}
		}
		return 0;
	}
	private String getString(ComboBoxModel model, int index) {
		Item item = (Item)model.getElementAt(index);
		return item.toString();
	}
	private String getSelectedString(ComboBoxModel model) {
		Item item = (Item)model.getSelectedItem();
		return item.toString();
	}
	private void updateSearchString(
								ComboBoxModel model, char key) {
		long time = System.currentTimeMillis();

		if(time - lastTime < 500) searchString += key;
		else 	   				  searchString = "" + key;

		lastTime = time;
	}
}
