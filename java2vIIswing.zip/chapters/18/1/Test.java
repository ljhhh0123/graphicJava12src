import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JCheckBox checkBox = new JCheckBox("Editable");
	private JComboBox comboBox = new JComboBox();

	public void init() {
		Container contentPane = getContentPane();

		comboBox.addItem("Top");
		comboBox.addItem("Center");
		comboBox.addItem("Bottom");

		checkBox.setSelected(comboBox.isEditable());

		contentPane.setLayout(new FlowLayout());
		contentPane.add(checkBox);
		contentPane.add(comboBox);

		checkBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comboBox.setEditable(checkBox.isSelected());
			}
		});
		comboBox.getEditor().addActionListener(
											new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			System.out.println("here" + 
								comboBox.getSelectedItem());
			}
		});
	}
	public static void main(String args[]) {
		final JFrame f = new JFrame();
		JApplet applet = new Test();

		applet.init();

		f.setContentPane(applet.getContentPane());
		f.setBounds(100,100,308,199);
		f.setTitle("An Application");
		f.setVisible(true);

		f.setDefaultCloseOperation(
			WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
}
