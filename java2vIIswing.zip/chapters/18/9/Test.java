import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test extends JApplet {
	public void init() {
		Container contentPane = getContentPane();
		JButton button = new JButton("show popup");
		final JComboBox combo = new JComboBox();

		combo.addItem("first item");
		combo.addItem("second item");
		combo.addItem("third item");
		combo.addItem("fourth item");
		combo.addItem("fifth item");

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				combo.showPopup();
			}
		});
		contentPane.setLayout(new FlowLayout());
		contentPane.add(button);
		contentPane.add(combo);
	}
}
