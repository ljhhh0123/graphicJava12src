import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JComboBox comboBox = new JComboBox();
	private ComboBoxEditor editor = comboBox.getEditor();

	public void init() {
		Container contentPane = getContentPane();

		comboBox.setEditable(true);

		comboBox.addItem("Top");
		comboBox.addItem("Center");
		comboBox.addItem("Bottom");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(comboBox);

		editor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = (String)editor.getItem();
				showStatus("Item Edited: " + s);
			}
		});
	}
}
