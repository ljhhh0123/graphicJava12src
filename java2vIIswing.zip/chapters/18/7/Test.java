import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	private JComboBox comboBox = new JComboBox();

	public void init() {
		Container contentPane = getContentPane();

		comboBox.addItem("Top");
		comboBox.addItem("Center");
		comboBox.addItem("Bottom");

		contentPane.setLayout(new FlowLayout());
		contentPane.add(comboBox);

		comboBox.addItemListener(new ItemListener() {		
			public void itemStateChanged(ItemEvent event) {
				int state = event.getStateChange();
				String item = (String)event.getItem(), s;

				if(event.getStateChange() == ItemEvent.SELECTED)
					s = " selected";
				else
					s = " deselected";

				JOptionPane.showMessageDialog(
					comboBox, // parent component
					item + s, // message
					"JComboBox Selection", // title
					JOptionPane.INFORMATION_MESSAGE); // type
			}
		});
	}
}
