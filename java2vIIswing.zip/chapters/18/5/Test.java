import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class Test extends JApplet {
	private JComboBox charsCombo = new JComboBox(new Object[] {
			new Character('g'), new Character('o'), 
			new Character('r'), new Character('b'), 
			new Character('y'), new Character('m'), 
			new Character('g'), new Character('l'),
	});
	private JComboBox colorCombo = new JComboBox(new Object[] {
			new Item(new Object[] { Color.gray, "gray" }),
			new Item(new Object[] { Color.orange, "orange" }),
			new Item(new Object[] { Color.red, "red" }),
			new Item(new Object[] { Color.blue, "blue" }),
			new Item(new Object[] { Color.yellow, "yellow" }),
			new Item(new Object[] { Color.magenta, "magenta" }),
			new Item(new Object[] { Color.black, "black" }),
			new Item(new Object[] { Color.green, "green" }),
			new Item(new Object[] { Color.lightGray, "lightGray"})
	});

	public void init() {
		final Container contentPane = getContentPane();

		colorCombo.setRenderer(new ColorRenderer());

		colorCombo.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Item item = (Item)colorCombo.getSelectedItem();
				Character first = new Character(
									  item.toString().charAt(0));

				showStatus("'" + first.toString() + "'" +
						   " is for " + item);
			}
		});
		charsCombo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final Character c = (Character)
									 charsCombo.getSelectedItem();

				colorCombo.selectWithKeyChar(c.charValue());

				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						Item item = (Item)
									colorCombo.getSelectedItem();

						JOptionPane.showMessageDialog(contentPane,
							"'" + c.toString() + "'" +
							" is for " + item.toString());
					}
				});
			}
		});
		contentPane.setLayout(
					new FlowLayout(FlowLayout.CENTER, 10, 35));

		contentPane.add(new JLabel("Select a Character:"));
		contentPane.add(charsCombo);
		contentPane.add(colorCombo);
	}
}
class Item {
	private Color color;
	private String string;

	public Item(Object[] array) {
		color = (Color)array[0];
		string = (String)array[1];
	}
	public Color getColor() { return color; }
	public String toString() { return string; }
}

class ColorRenderer extends JLabel implements ListCellRenderer {
	private static ColorIcon icon = new ColorIcon();

	private Border 
		redBorder = BorderFactory.createLineBorder(Color.red,2),
		emptyBorder = BorderFactory.createEmptyBorder(2,2,2,2);

	public Component getListCellRendererComponent(
									JList list,
									Object value,
									int index,
									boolean isSelected,
									boolean cellHasFocus) {
		Item item = (Item)value;

		icon.setColor(item.getColor());

		setIcon(icon);
		setText(item.toString());

		if(isSelected) setBorder(redBorder);
		else 		   setBorder(emptyBorder);

		return this;
	}
}
class ColorIcon implements Icon {
	private Color color;
	private int w, h;

	public ColorIcon() {
		this(Color.gray, 50, 15);
	}
	public ColorIcon(Color color, int w, int h) {
		this.color = color;
		this.w = w;
		this.h = h;
	}
	public void paintIcon(Component c, Graphics g, int x, int y) {
		g.setColor(Color.black);
		g.drawRect(x, y, w-1, h-1);
		g.setColor(color);
		g.fillRect(x+1, y+1, w-2, h-2);
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public int getIconWidth() {
		return w;
	}
	public int getIconHeight() {
		return h;
	}
}
