import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	CustomDesktopPane desktopPane = new CustomDesktopPane();
	int frameCount = 1, numFrames = 5, x, y;

	public void init() {
		Container contentPane = getContentPane();

		setJMenuBar(createMenuBar());
		contentPane.add(desktopPane, BorderLayout.CENTER);

		for(int i=0; i < numFrames; ++i) {
			JInternalFrame jif = new JInternalFrame(
				  	"Internal Frame " + frameCount++, // title
				  	true,  // resizable
				  	true,  // closable
				  	true,  // maximizable
				  	true); // iconifiable

			x = (int)(Math.random() * 100);
			y = (int)(Math.random() * 100);

			jif.setBounds(x, y, 250, 100);
			desktopPane.putClientProperty(
							"JDesktopPane.dragMode",
							"outline");

			desktopPane.add(jif);
		}
	}
	private JMenuBar createMenuBar() {
		JMenuBar menubar = new JMenuBar();
		JMenu windowMenu = new JMenu("Window");

		windowMenu.add(new OpenAllAction());
		windowMenu.add(new CloseAllAction());
		windowMenu.add(new CascadeAction());

		menubar.add(windowMenu);
		return menubar;
	}
	class OpenAllAction extends AbstractAction {
		public OpenAllAction() {
			super("open all");
		}
		public void actionPerformed(ActionEvent e) {
			desktopPane.openAll();
		}
	}
	class CloseAllAction extends AbstractAction {
		public CloseAllAction() {
			super("close all");
		}
		public void actionPerformed(ActionEvent e) {
			desktopPane.closeAll();
		}
	}
	class CascadeAction extends AbstractAction {
		public CascadeAction() {
			super("cascade");
		}
		public void actionPerformed(ActionEvent e) {
			desktopPane.cascade();
		}
	}
}
class CustomDesktopPane extends JDesktopPane { 
	private int xoffset = 20, yoffset = 20, w = 250, h = 350;

	public void closeAll() {
		JInternalFrame[] frames = getAllFrames();

		for(int i=0; i < frames.length; ++i) {
			if(!frames[i].isIcon()) {
				try {
					frames[i].setIcon(true);
				}
				catch(java.beans.PropertyVetoException ex) {
					System.out.println("iconification vetoed!");
				}
			}
		}
	}
	public void openAll() {
		JInternalFrame[] frames = getAllFrames();

		for(int i=0; i < frames.length; ++i) {
			if(frames[i].isIcon()) {
				try {
					frames[i].setIcon(false);
				}
				catch(java.beans.PropertyVetoException ex) {
					System.out.println("restoration vetoed!");
				}
			}
		}
	}
	public void cascade() {
		JInternalFrame[] frames = getAllFrames();
		int x = 0, y = 0;

		for(int i=0; i < frames.length; ++i) {
			if( ! frames[i].isIcon()) {
				frames[i].setBounds(x,y,w,h);
				x += xoffset;
				y += yoffset;
			}
		}
	}
}
