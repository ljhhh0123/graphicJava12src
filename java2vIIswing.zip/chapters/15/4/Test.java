import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	JDesktopPane desktopPane = new JDesktopPane();
	JInternalFrame jif = new JInternalFrame(
				  	"Internal Frame", // title
				  	true,  // resizble
				  	true,  // closable
				  	true,  // maximizable
				  	true); // iconifiable

	public void init() {
		Container contentPane = getContentPane();

		contentPane.add(desktopPane, BorderLayout.CENTER);

		jif.setBounds(50, 50, 300, 200);
		jif.setFrameIcon(new ImageIcon("print.gif"));
		desktopPane.add(jif);
	}
}
