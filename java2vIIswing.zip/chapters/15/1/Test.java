import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JApplet {
	JButton b = new JButton("make frame");
	JDesktopPane desktopPane = new JDesktopPane();
	int windowCount = 1;

	public void init() {
		Container contentPane = getContentPane();

		contentPane.add(b, BorderLayout.NORTH);
		contentPane.add(desktopPane, BorderLayout.CENTER);

		desktopPane.setLayout(new FlowLayout());

		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				JInternalFrame jif = new JInternalFrame(
				  	"Internal Frame " + windowCount++, // title
				  	true,  // resizable
				  	true,  // closable
				  	true,  // maximizable
				  	true); // iconifiable

				jif.setPreferredSize(new Dimension(250, 100));
				desktopPane.add(jif);
				desktopPane.revalidate();
			}
		});
	}
}
