import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;
import javax.swing.event.*;

public class Test extends JApplet {
	JDesktopPane desktopPane = new JDesktopPane();

	public void init() {
		Container contentPane = getContentPane();

		contentPane.add(desktopPane, BorderLayout.CENTER);
		desktopPane.setLayout(new FlowLayout());

		JInternalFrame jif = new JInternalFrame(
									"An Internal Frame", // title
				  					false, // resizable
				  					true,  // closable
									true,  // maximizable
									true); // iconifiable

		jif.setPreferredSize(new Dimension(300, 250));
		jif.addInternalFrameListener(new Listener(this));

		desktopPane.add(jif);
	}
}
class Listener implements InternalFrameListener { 
	private JApplet applet;

	public Listener(JApplet applet) {
		this.applet = applet;	
	}
	public void internalFrameActivated(InternalFrameEvent e) {
		applet.showStatus("frame activated");
	}
	public void internalFrameClosed(InternalFrameEvent e) {
		applet.showStatus("frame closed");
	}
	public void internalFrameClosing(InternalFrameEvent e) {
		applet.showStatus("frame closing");
	}
	public void internalFrameDeactivated(InternalFrameEvent e) {
		applet.showStatus("frame deactivated");
	}
	public void internalFrameDeiconified(InternalFrameEvent e) {
		applet.showStatus("frame deiconified");
	}
	public void internalFrameIconified(InternalFrameEvent e) {
		applet.showStatus("frame iconified");
	}
	public void internalFrameOpened(InternalFrameEvent e) {
		applet.showStatus("frame opened");
	}
	private void sleepForABit() {
		try {
			Thread.currentThread().sleep(5000);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
}
