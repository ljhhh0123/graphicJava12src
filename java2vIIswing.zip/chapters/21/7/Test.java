import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JTextArea textArea = new JTextArea();

		textArea.setCaret(new TriangleCaret(8));
		textArea.setFont(new Font("Dialog", Font.ITALIC, 24));
		contentPane.add(textArea, BorderLayout.CENTER);
	}
}
class TriangleCaret extends DefaultCaret {
	private int triangleWidth, left, right, top, bottom, middle;

	public TriangleCaret(int triangleWidth) {
		this.triangleWidth = triangleWidth;
	}
	public void paint(Graphics g) {
		if(isVisible()) {
			try {
				JTextComponent comp = getComponent();
				Rectangle r = comp.modelToView(getDot());

				setLocations(r);
				g.setColor(comp.getCaretColor());

				g.drawLine(left, bottom, middle, top);
				g.drawLine(middle, top, right, bottom);
				g.drawLine(right, bottom, left, bottom);
			}
			catch(BadLocationException ex) {
				ex.printStackTrace();
			}
		}
	}
	protected synchronized void damage(Rectangle r) {
		if(r != null) {
			setLocations(r);
			x = left;
			y = top;
			width = right - left + 1;
			height = bottom - top + 1;
		}
	}
	private void setLocations(Rectangle r) {
		left = r.x - triangleWidth/2; 
		right = r.x + triangleWidth/2;
		bottom = r.y + r.height - 1; 
		top = bottom - triangleWidth;
		middle = r.x;

		repaint();
	}
}
