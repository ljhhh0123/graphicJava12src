import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.util.*;
import java.io.*;

public class Test extends JFrame {
	private JTextArea textArea = new JTextArea();
	private Document document = textArea.getDocument();
	private DefaultEditorKit kit = new DefaultEditorKit();
	private Action saveAction = new AbstractAction() {	
		public void actionPerformed(ActionEvent e) {
					String s = JOptionPane.showInputDialog(
										Test.this,
										"Enter Filename:");
				if(s != null) {
						try {
							kit.write(new FileWriter(s), 
									  document, 0, 
									  document.getLength());
				}
				catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	};

	public Test() {
		Container contentPane = getContentPane();

		try {
			kit.read(new FileReader("Test.java"), document, 0);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}

		final JTextArea status = new JTextArea();
		JPanel p = new JPanel();
		JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, 
									   p, status);
		sp.setDividerLocation(200);

		saveAction.putValue(Action.NAME, "Save ...");
		saveAction.setEnabled(false);

		p.setLayout(new BorderLayout());	
		p.add(new JScrollPane(textArea), BorderLayout.CENTER);

		contentPane.add(sp, BorderLayout.CENTER);

		textArea.getDocument().addDocumentListener(
										new DocumentListener() {
			public void insertUpdate(DocumentEvent e) {
				saveAction.setEnabled(true);
				updateStatus(e);
			}
			public void removeUpdate(DocumentEvent e) {
				saveAction.setEnabled(true);
				updateStatus(e);
			}
			public void changedUpdate(DocumentEvent e) {
				saveAction.setEnabled(true);
				updateStatus(e);
			}
			private void updateStatus(DocumentEvent e) {
				status.append(e.getType().toString());
				status.append(" Offset: " + e.getOffset());
				status.append(" Length: " + e.getLength() + "\n");
			}
		});

		setJMenuBar(createMenuBar());
	}
	private JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenu editMenu = new JMenu("Edit");

		editMenu.add(new DefaultEditorKit.CutAction());
		editMenu.add(new DefaultEditorKit.CopyAction());
		editMenu.add(new DefaultEditorKit.PasteAction());
		editMenu.addSeparator();
		editMenu.add(saveAction);

		menuBar.add(editMenu);
		return menuBar;
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
					"Using Document Listeners",
					300,300,650,500);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		launch(f,title,x,y,w,h,null);	
	}
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h,
							  String propertiesFilename) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		if(propertiesFilename != null) {
			resources = ResourceBundle.getBundle(
						propertiesFilename, Locale.getDefault());
		}

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
