import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JApplet {
	private JTextArea textArea = new JTextArea("initial content");
	private JCheckBox cbox = new JCheckBox("keymap added");
	private Hashtable actionTable = new Hashtable();
	private Keymap originalKeymap, newKeymap;

	public void init() {
		Container contentPane = getContentPane();

		loadActionTable();
		originalKeymap = textArea.getKeymap();
		newKeymap = createKeymap();

		textArea.setFont(new Font("Dialog", Font.PLAIN, 24));

		contentPane.add(new ControlPanel(), BorderLayout.NORTH);
		contentPane.add(textArea, BorderLayout.CENTER);
	}
	private Keymap createKeymap() {
		Keymap map = JTextComponent.addKeymap("applet keymap",
									textArea.getKeymap());

		KeyStroke forwardKeyStroke = 
					KeyStroke.getKeyStroke(KeyEvent.VK_F,
					   					   InputEvent.ALT_MASK),
				  backwardKeyStroke =
					KeyStroke.getKeyStroke(KeyEvent.VK_B,
					   					   InputEvent.ALT_MASK);
		Action forwardAction =
					getAction(DefaultEditorKit.forwardAction),
			   backwardAction =
					getAction(DefaultEditorKit.backwardAction);

		map.addActionForKeyStroke(forwardKeyStroke,
								  forwardAction);
		map.addActionForKeyStroke(backwardKeyStroke,
								  backwardAction);
		return map;
	}
	private void loadActionTable() {
		Action[] actions = textArea.getActions();

		for(int i=0; i < actions.length; ++i) {
			actionTable.put(actions[i].getValue(Action.NAME),
							actions[i]);
		}
	}
	private Action getAction(String name) {
		return (Action)actionTable.get(name);
	}
	class ControlPanel extends JPanel {
		public ControlPanel() {
			add(cbox);

			cbox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					textArea.setKeymap(cbox.isSelected() ?
										newKeymap : 
										originalKeymap);

					textArea.requestFocus();
				}
			});
		}
	}
}
