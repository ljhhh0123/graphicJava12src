This applet works as advertised under 1.1.7, but under 1.2 the
'f' and 'b' keys are sent to the text area as noted in the book.
