import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

public class Test extends JApplet {
	public Test() {
		Container contentPane = getContentPane();
		JTextArea textArea = new JTextArea();

		contentPane.add(textArea, BorderLayout.CENTER);

		textArea.setFont(new Font("Dialog", Font.PLAIN, 24));

		textArea.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				showStatus("Mark: " + e.getMark() +
						   "  /  Dot: " + e.getDot());
			}
		});
	}
}
