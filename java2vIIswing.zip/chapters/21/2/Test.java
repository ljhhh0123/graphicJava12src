import java.awt.*;
import javax.swing.*;
import javax.swing.text.*;
import java.util.*;

public class Test extends JApplet {
	private JTextArea textArea = new JTextArea("some content");
	private Hashtable actionTable = new Hashtable();

	public Test() {
		Container contentPane = getContentPane();

		textArea.setFont(new Font("Dialog", Font.PLAIN, 24));

		loadActionTable();

		setJMenuBar(createMenu());
		contentPane.add(textArea, BorderLayout.CENTER);
	}
	private void loadActionTable() {
		Action[] actions = textArea.getActions();

		for(int i=0; i < actions.length; ++i) {
			actionTable.put(actions[i].getValue(Action.NAME),
							actions[i]);
		}
	}
	private Action getAction(String name) {
		return (Action)actionTable.get(name);
	}
	private JMenuBar createMenu() {
		JMenuBar menuBar = new JMenuBar();
		JMenu editMenu = new JMenu("Edit");

		editMenu.add(getAction(DefaultEditorKit.cutAction));
		editMenu.add(getAction(DefaultEditorKit.copyAction));
		editMenu.add(getAction(DefaultEditorKit.pasteAction));

		menuBar.add(editMenu);
		return menuBar;
	}
}
