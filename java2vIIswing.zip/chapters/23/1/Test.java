import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import java.util.*;
import java.io.FileReader;

public class Test extends JFrame {
	private JTextPane textPane = new JTextPane();
	private StyledDocument document = 
						  (StyledDocument)textPane.getDocument();

	public Test() {
		Container contentPane = getContentPane();
		readFile("text.txt");
		setAttributes();

		textPane.setFont(new Font("Dialog", Font.PLAIN, 18));
		contentPane.add(new JScrollPane(textPane), 
						BorderLayout.CENTER);
	}
	private void setAttributes() {
		SimpleAttributeSet attributes = new SimpleAttributeSet();

		StyleConstants.setForeground(attributes, Color.blue);
		StyleConstants.setUnderline(attributes, true);

		document.setCharacterAttributes(5,9,attributes,false);

		StyleConstants.setForeground(attributes, Color.red);
		StyleConstants.setStrikeThrough(attributes, false);

		document.setCharacterAttributes(15,9,attributes,true);
	}
	private void readFile(String filename) {
		EditorKit kit = textPane.getEditorKit();
		try {
			kit.read(new FileReader(filename), document, 0);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
					"Setting Attributes",300,300,450,300);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	static {
		resources = ResourceBundle.getBundle(
					"GJApp", Locale.getDefault());
	};

	private GJApp() {}
	
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
