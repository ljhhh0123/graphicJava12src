import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Test extends JFrame {
	JEditorPane editorPane = new JEditorPane();
	Vector positions = new Vector();
	Position.Bias bias = Position.Bias.Forward;

	class CustomView extends WrappedPlainView {
		public CustomView(Element elem) {
			super(elem);
		}
		public void paint(Graphics g, Shape a) {
			super.paint(g,a);

			Enumeration e = positions.elements();
			Position p;

			while(e.hasMoreElements()) {
				try {
					p = (Position)e.nextElement();
					int offset = p.getOffset();

					Shape s = modelToView(p.getOffset(), a, bias);
					Rectangle r = s.getBounds();

					// black border
					g.setColor(Color.black);
					g.drawRect(r.x, r.y, 6, 6);

					// red fill
					g.setColor(Color.red);
					g.fillRect(r.x+1, r.y+1, 5, 5);
				}
				catch(BadLocationException ex) {
					ex.printStackTrace();
				}
			}
		}
	};
	class CustomEditorKit extends DefaultEditorKit 
						  implements ViewFactory {
		public ViewFactory getViewFactory() {
			return this;
		}
		public View create(Element elem) {
			return new CustomView(elem);
		}
	};
	public Test() {
		JPanel panel = new JPanel();
		JButton button = new JButton("Insert Position");
		Container contentPane = getContentPane(); 
		panel.add(button);

		editorPane.setEditorKit(new CustomEditorKit());
		editorPane.setFont(new Font("Serif", Font.ITALIC, 36));

		contentPane.add(panel, BorderLayout.NORTH);
		contentPane.add(editorPane, BorderLayout.CENTER);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Document doc = editorPane.getDocument();
					int p = editorPane.getCaretPosition();

					positions.addElement(doc.createPosition(p));
					editorPane.repaint();
				}
				catch(BadLocationException ex) {
					ex.printStackTrace();
				}
			}
		});
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
					"Custom Text Views",300,300,450,300);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");

	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
}
