import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.FileReader;

public class Test extends JFrame {
	private JTextComponent components[] = new JTextComponent[] {
		new JTextField("initial content"), new JTextArea(10,20),
		new JTextPane(), new JEditorPane(),
	};
	private String borderNames[] = new String[] { 
		"JTextField", "JTextArea", "JTextPane", "JEditorPane"
	};
	private JPanel textComponentPanel = new JPanel();
	private ElementTreePanel treePanel = 
							 new ElementTreePanel(components[0]);
	private JSplitPane sp = new JSplitPane( 
							JSplitPane.HORIZONTAL_SPLIT, 
							new JScrollPane(textComponentPanel), 
							new JScrollPane(treePanel));

	public Test() {
		Container contentPane = getContentPane();
		CaretListener listener = new Listener();

		textComponentPanel.setBorder(
			BorderFactory.createTitledBorder("Text Components"));

		for(int i=0; i < components.length; ++i) {
			JTextComponent c = (JTextComponent)components[i];

			c.addCaretListener(listener);
			c.setBorder(
				BorderFactory.createTitledBorder(borderNames[i]));

			if(i != 0) // JTextField
				readFile(c, "text.txt");

			if(i == 3) { // JEditorPane
				JEditorPane 
						editorPane = (JEditorPane)c;

				String url = "file:" + 
							System.getProperty("user.dir") +
			 				System.getProperty("file.separator") +
			 				"java.util.Hashtable.html";

				editorPane.setEditable(false);
				try { 
					editorPane.setPage(url);
				}
				catch(Exception ex) { ex.printStackTrace(); }

				JScrollPane sp = new JScrollPane(c);
				sp.setPreferredSize(new Dimension(450,450));
				panel.add(sp);
			}
			else
				panel.add(c);
		}
		sp.setDividerLocation(600);

		contentPane.add(sp, BorderLayout.CENTER);
	}
	class Listener implements CaretListener {
		public void caretUpdate(CaretEvent e) {
			JTextComponent c = (JTextComponent)e.getSource();

			if(c != treePanel.getEditor()) {
				sp.setRightComponent(treePanel = 
									 new ElementTreePanel(c));
			}
		}
	}
	private void readFile(JTextComponent c, String filename) {
		try {
			c.read(new FileReader(filename), null);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
					"Element Hierarchies",300,300,800,300);
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	private GJApp() {}
	
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
