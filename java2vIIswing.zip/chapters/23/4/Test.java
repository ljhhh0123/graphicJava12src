import java.io.File;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.FileReader;

public class Test extends JFrame {
	private JTextPane textPane = new JTextPane();
	private Hashtable actionTable = new Hashtable();
	private JCheckBoxMenuItem titleItem, bodyItem; 

	public Test() {
		Container contentPane = getContentPane();

		textPane.setEditorKit(new ChapterEditorKit());
		textPane.setFont(new Font("Dialog", Font.PLAIN, 18));

		// must load action table after setting editor kit ...
		loadActionTable();

		readFile("text.txt");

		contentPane.add(new JScrollPane(textPane), 
						BorderLayout.CENTER);
		contentPane.add(GJApp.getStatusArea(),BorderLayout.SOUTH);

		setJMenuBar(createMenuBar());
	}
	private JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenu editMenu = new JMenu("Edit"),
			  styleMenu = new JMenu("Paragraph Styles");

		styleMenu.add(getAction(ChapterStyleContext.titleStyle));
		styleMenu.add(getAction(ChapterStyleContext.bodyStyle));

		editMenu.add(styleMenu);
		menuBar.add(editMenu);
		return menuBar;
	}
	private void readFile(String filename) {
		EditorKit kit = textPane.getEditorKit();
		Document doc = textPane.getDocument();

		try {
			kit.read(new FileReader(filename), doc, 0);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	private void loadActionTable() {
		Action[] actions = textPane.getActions();

		for(int i=0; i < actions.length; ++i) {
			actionTable.put(actions[i].getValue(Action.NAME),
							actions[i]);
		}
	}
	private Action getAction(String name) {
		return (Action)actionTable.get(name);
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
					"Custom EditorKits & Style Contexts",
					300,300,650,275);
	}
}
class ChapterEditorKit extends StyledEditorKit {
	private CaretListener caretListener = new Listener();
	private static ChapterStyleContext context = 
								new ChapterStyleContext();

	private static Action[] defaultActions = new Action[] {
		new ParagraphStyleAction(
				ChapterStyleContext.titleStyle,
				context.getStyle(ChapterStyleContext.titleStyle)),
		new ParagraphStyleAction(
				ChapterStyleContext.bodyStyle,
				context.getStyle(ChapterStyleContext.bodyStyle)),
	};
	public Action[] getActions() {
		return TextAction.augmentList(super.getActions(), 
									  defaultActions);
    }
	public void install(JEditorPane editorPane) {
		editorPane.addCaretListener(caretListener);
	}
	public void deinstall(JEditorPane editorPane) {
		editorPane.removeCaretListener(caretListener);
	}
	static class Listener implements CaretListener {
		public void caretUpdate(CaretEvent e) {
	    	int dot = e.getDot(), mark = e.getMark();

	    	if (dot == mark) {
				JTextComponent c = (JTextComponent) e.getSource();
				StyledDocument document = 
							(StyledDocument) c.getDocument();	
				Element elem = document.getParagraphElement(dot);
				AttributeSet set = elem.getAttributes();
				String name = (String)set.getAttribute(
									StyleConstants.NameAttribute);

				GJApp.showStatus(name);
			}
		}
	}
	static class ParagraphStyleAction 
				 extends StyledEditorKit.StyledTextAction {
		private Style style;

		public ParagraphStyleAction(String nm, Style style) {
	    	super(nm);
			this.style = style;
		}
        public void actionPerformed(ActionEvent e) {
			setParagraphAttributes(getEditor(e), style, false);
			GJApp.showStatus(style.getName());
		}
	}
}
class ChapterStyleContext extends StyleContext {
	public static String titleStyle = "title",
					     bodyStyle = "body";

	public static String[] defaultStyleNames = new String[] {
								new String(titleStyle),
								new String(bodyStyle) };

	public ChapterStyleContext() {
		Style root = getStyle(DEFAULT_STYLE);

		for(int i=0; i < defaultStyleNames.length; ++i) {
			String name = defaultStyleNames[i];
			Style s = addStyle(name, root);

			if(name.equals(titleStyle)) {
				StyleConstants.setFontFamily(s, "Dialog");
				StyleConstants.setFontSize(s, 24);
				StyleConstants.setBold(s, true);
				StyleConstants.setUnderline(s, true);
			}
			else if(name.equals(bodyStyle)) {
				StyleConstants.setFontFamily(s, "Times-Roman");
				StyleConstants.setFontSize(s, 16);
			}
		}
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	static {
		resources = ResourceBundle.getBundle(
					"GJApp", Locale.getDefault());
	};

	private GJApp() {}
	
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
