import java.io.File;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.FileReader;

public class Test extends JFrame {
	private JTextPane textPane = new JTextPane();
	private StyledDocument document = 
						  (StyledDocument)textPane.getDocument();
	private StyledEditorKit kit = 
						(StyledEditorKit)textPane.getEditorKit();
	private JColorChooser chooser = new JColorChooser();
	private int CharacterMode = 0, ParagraphMode = 1;

	public Test() {
		Container contentPane = getContentPane();
		readFile("text.txt");

		textPane.setFont(new Font("Dialog", Font.PLAIN, 18));

		contentPane.add(new JScrollPane(textPane), 
						BorderLayout.CENTER);

		setJMenuBar(createMenuBar());
	}
	private JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenu editMenu = new JMenu("Edit");

		editMenu.add(new ForegroundFromChooserAction(
					"Character Foreground Color ... ",
					CharacterMode));

		editMenu.add(new ForegroundFromChooserAction(
					"Paragraph Foreground Color ... ",
					ParagraphMode));

		menuBar.add(editMenu);
		return menuBar;
	}
	private void readFile(String filename) {
		try {
			kit.read(new FileReader(filename), document, 0);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public static void main(String args[]) {
		GJApp.launch(new Test(), 
					"Custom Actions",300,300,650,275);
	}
	class ForegroundFromChooserAction 
					    extends StyledEditorKit.StyledTextAction {

		protected Color fg;
		protected JColorChooser chooser = new JColorChooser();
		protected int mode;

		public ForegroundFromChooserAction(String nm, int mode) {
	    	super(nm);
			this.mode = mode;
		}
        public void actionPerformed(ActionEvent e) {
	    	JEditorPane editor = getEditor(e);
	    	if (editor != null) {
				AttributeSet attributes = 
							 textPane.getCharacterAttributes();
				Color c = 
						StyleConstants.getForeground(attributes);

				Color fg = chooser.showDialog(Test.this,
								"Choose Color for Text",
								c == null ? Color.black : c);
/*
				if ((e != null) && (e.getSource() == editor)) {
		    		String s = e.getActionCommand();
		    		try {
					fg = Color.decode(s);
		    		} 
					catch(NumberFormatException ex) {
						ex.printStackTrace();
		    		}
				}
				*/
				if (fg != null) {
				    MutableAttributeSet attr = 
									new SimpleAttributeSet();
				    StyleConstants.setForeground(attr, fg);

					if(mode == CharacterMode)
				      setCharacterAttributes(editor, attr, false);
					else
				      setParagraphAttributes(editor, attr, false);

					textPane.setCaretPosition(
							 textPane.getSelectionStart());
				} else {
				    Toolkit.getDefaultToolkit().beep();
				}
	    	}
		}
	}
}
class GJApp extends WindowAdapter {
	static private JPanel statusArea = new JPanel();
	static private JLabel status = new JLabel(" ");
	static private ResourceBundle resources;

	static {
		resources = ResourceBundle.getBundle(
					"GJApp", Locale.getDefault());
	};

	private GJApp() {}
	
	public static void launch(final JFrame f, String title,
							  final int x, final int y, 
							  final int w, int h) {
		f.setTitle(title);
		f.setBounds(x,y,w,h);
		f.setVisible(true);

		statusArea.setBorder(BorderFactory.createEtchedBorder());
		statusArea.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
		statusArea.add(status);
		status.setHorizontalAlignment(JLabel.LEFT);

		f.setDefaultCloseOperation(
							WindowConstants.DISPOSE_ON_CLOSE);

		f.addWindowListener(new WindowAdapter() {
			public void windowClosed(WindowEvent e) {
				System.exit(0);
			}
		});
	}
	static public JPanel getStatusArea() {
		return statusArea;
	}
	static public void showStatus(String s) {
		status.setText(s);
	}
	static Object getResource(String key) {
		if(resources != null) {
			return resources.getString(key);
		}
		return null;
	}
}
