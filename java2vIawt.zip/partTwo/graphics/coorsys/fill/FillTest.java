import java.applet.Applet;
import java.awt.*;

public class FillTest extends Applet {
	public void paint(Graphics g) {
		g.fillRect(2,2,4,4);
	}
}
