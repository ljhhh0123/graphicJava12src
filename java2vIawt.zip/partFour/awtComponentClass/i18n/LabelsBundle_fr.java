import java.util.*;

public class LabelsBundle_fr extends ListResourceBundle {
	static final Object[][] contents = {
		{"Identifier", "GUI en Francais"}
	};
	public Object[][] getContents() {
		return contents;
	}
}
