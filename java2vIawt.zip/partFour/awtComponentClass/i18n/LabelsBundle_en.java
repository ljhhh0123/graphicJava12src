import java.util.*;

public class LabelsBundle_en extends ListResourceBundle {
	static final Object[][] contents = {
		{"Identifier", "English GUI"}
	};
	public Object[][] getContents() {
		return contents;
	}
}
