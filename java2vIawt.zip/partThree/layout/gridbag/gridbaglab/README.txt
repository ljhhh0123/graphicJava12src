GridBagLab uses Swing components, so you must have either the 1.2 
JDK, or a 1.1.X version and the Swing components.
