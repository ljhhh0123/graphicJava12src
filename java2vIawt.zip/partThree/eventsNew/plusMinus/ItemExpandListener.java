import java.util.EventListener;

public interface ItemExpandListener extends EventListener {
    void itemExpandStateChanged(ItemExpandEvent e);
}
