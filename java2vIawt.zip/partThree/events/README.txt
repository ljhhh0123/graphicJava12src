Since the code in this chapter is based on 1.02, you will encounter deprecation 
warnings when compiling the code contained in this directory under the 1.1 JDK.
